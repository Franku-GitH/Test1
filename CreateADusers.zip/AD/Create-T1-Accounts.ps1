﻿##############################################################################
# Create Tier 1 accounts                                                     #
# - after creation, the account is disabled and needs to be enabled manually #
# Input CSV header                                                           #
# FirstName,LastName,UserName,DisplayName                                    #
##############################################################################

# *************** Variables ***********************

$strDomain=(Get-ADDomain).DNSRoot
$strDNDomain=(Get-ADDomain).DistinguishedName
$date= Get-Date -Format "yyyy-MM-dd-HHmmss"

$adUserDNPath = "OU=1 Accounts,OU=T1,OU=Model Administration,DC=XX,DC=xy,DC=yx"
$adUserDescription = "Administrator Tier 1"


# Log paths
$CsvPath = "C:\Install\Accounts\T1_PrivilegedUsers.csv"
$LogPath = "C:\Install\Accounts\AccountsLogs\T1\user_T1_creation_$date.log"

# *************** Script **************************

# Get information who ran the script
$createdBy = $env:USERNAME
$createdComp = $env:COMPUTERNAME 

"Script started by:$createdBy, created on: $createdComp" | Out-File -FilePath $LogPath -Append -Encoding UTF8

# Counters
$CreatedCount = 0
$SkippedCount = 0
$FailedCount = 0

# Import from CSV
$Users = Import-Csv -Path $CsvPath

foreach ($User in $Users) {
    $adUserUPN = ""
    $adUserUPN = "$($User.UserName)@$strDomain"
    
    try {

    # Check if user exists
        $ExistingUser = Get-ADUser -Identity $User.UserName -ErrorAction SilentlyContinue

        if ($ExistingUser) {
            Write-Host "[SKIP] User already exists: $adUserUPN" -ForegroundColor Yellow
            "$($User.DisplayName),$adUserUPN,Skipped (Already Exists)" | Out-File -FilePath $LogPath -Append -Encoding UTF8
            $SkippedCount++
            continue
        }

    }
    catch {
        If ($_.CategoryInfo.Reason -eq "ADIdentityNotFoundException"){
            Write-Host "[CREATE] Creating user: $adUserUPN" -ForegroundColor Cyan
            # Write-host "New-ADUser -DisplayName $($user.DisplayName) -Name $($user.UserName) -Description $adUserDescription -Path $adUserDNPath -SamAccountName $($user.UserName) -UserPrincipalName $adUserUPN"
            # Creating user
            New-ADUser -DisplayName $user.DisplayName -Name $user.UserName -GivenName $user.FirstName -Surname $user.LastName -Description $adUserDescription -Path $adUserDNPath -SamAccountName $user.UserName -UserPrincipalName $adUserUPN
            Set-ADUser -Identity $user.UserName -AccountNotDelegated $true

            Write-Host "[OK] User created: $adUserUPN" -ForegroundColor Green
            "$($User.DisplayName),$adUserUPN" | Out-File -FilePath $LogPath -Append -Encoding UTF8
            $CreatedCount++
        }
        else
        {
            Write-Host "[ERROR] Failed to create user $($adUserUPN): $_" -ForegroundColor Red
            "$($User.DisplayName),$adUserUPN,Failed: $_" | Out-File -FilePath $LogPath -Append -Encoding UTF8
            $FailedCount++
        }
    }
} 

# Results
Write-Host "`n=== SUMMARY ===" -ForegroundColor White
Write-Host "Created: $CreatedCount" -ForegroundColor Green
Write-Host "Skipped: $SkippedCount" -ForegroundColor Yellow
Write-Host "Failed:  $FailedCount" -ForegroundColor Red
Write-Host "`nLog saved to: $LogPath" -ForegroundColor White

# ************** Checks *******************************

# For check which Privileged accounts don't have mandatory flag AccountNotDelegated
# Get-ADUser -Filter {(AccountNotDelegated -eq $false)} -SearchBase "OU=Tier Model Administration,DC=vz,DC=gov,DC=cz" | Select-Object DistinguishedName


# For check what is created
# Write-host "-DisplayName $user.DisplayName -Name $user.UserName -Description $adUserDescription -Path $adUserDNPath -SamAccountName $user.UserName -UserPrincipalName $adUserUPN" -ForegroundColor Green


