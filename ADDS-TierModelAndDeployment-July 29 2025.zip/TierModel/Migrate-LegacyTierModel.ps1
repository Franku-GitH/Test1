param (
    [Parameter(Mandatory=$true)]
    [string]$preferredDC
)

<#
.SYNOPSIS
    This script is used to create rename legacy Tier Model objects before deploying the latest Tier Model to avoid conflicts where duplicate names exist.

.DESCRIPTION
    RM prefix stands for Remove, mean after migration these objects can will be removed as they are no longer required by the new Tier Model.
    This script will rename legacy Tier Model Groups to include the 'RM_' for both the Group Name and the pre-Windows 2000 name.
    This script will rename legacy Tier Model GPOs to include the 'RM_' for the GPO Name, from *- to *RM-.

.PARAMETER PreferredDC
    Ensure all changes occur on the Preferred Domain Controller to avoid replication issues.

.EXAMPLE
    .\Migrate-LegacyTierModel.ps1 -PreferredDC 'DC01.contoso.com'

.NOTES
    This sample script is not supported under any Microsoft standard support program or service. 
    The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims 
    all implied warranties including, without limitation, any implied warranties of merchantability 
    or of fitness for a particular purpose. The entire risk arising out of the use or performance of 
    the sample scripts and documentation remains with you. In no event shall Microsoft, its authors, 
    or anyone else involved in the creation, production, or delivery of the scripts be liable for any 
    damages whatsoever (including, without limitation, damages for loss of business profits, business 
    interruption, loss of business information, or other pecuniary loss) arising out of the use of or 
    inability to use the sample scripts or documentation, even if Microsoft has been advised of the 
    possibility of such damages
#>

# Import the Active Directory module
Import-Module ActiveDirectory

# Define the prefix to add
$groupPrefix = "RM_"

# Define the array of existing group names
$existingGroupNames = @(
    "AdminDomainJoin",
    "BreakGlassAdmins",
    "Tier 0 Application Operators",
    "Tier 0 Build Domain Controller using MDT",
    "Tier 0 Domain Operators",
    "Tier 0 HGS Admins",
    "Tier 0 HGS gMSA Users",
    "Tier 0 HGS View Admins",
    "Tier 2 Computer Quarantine Operators",
    "Tier0Admins",
    "Tier0Operators",
    "Tier0ServerOperators",
    "Tier1Admins",
    "Tier1ApplicationXOperators",
    "Tier1Operators",
    "Tier1ServerOperators",
    "Tier2AccountOperators",
    "Tier2Admins",
    "Tier2DeviceOperators",
    "Tier2GroupOperators",
    "Tier2HelpdeskOperators",
    "Tier2Operators"
)

foreach ($existingGroupName in $existingGroupNames) {
    # Get the group object
    $group = Get-ADGroup -Identity $existingGroupName

    # Construct the new names
    $newGroupName = $groupPrefix + $group.Name
    $newPreWin2000Name = $groupPrefix + $group.sAMAccountName

    # Rename the group
    Rename-ADObject -Identity $group.DistinguishedName -NewName $newGroupName -Server $preferredDC

    # Update the sAMAccountName (pre-Windows 2000 name)
    Set-ADGroup -Identity $group.SamAccountName -SamAccountName $newPreWin2000Name -Server $preferredDC

    Write-Output "Group renamed successfully to $newGroupName with pre-Windows 2000 name $newPreWin2000Name"
}

$existingGPONames = @(
    "*- Additional Domain Security Settings",
    "*- Computer Quarantine",
    "*- MSFT Windows Server 2022 - Domain Security",
    "*- PAW Staging BitLocker",
    "*- PAW Staging Restricted Groups",
    "*- Tier 0 DCs MSFT Edge Version 107 - Computer",
    "*- Tier 0 DCs MSFT Internet Explorer 11 - Computer",
    "*- Tier 0 DCs MSFT Windows 10 1809 and Server 2019 - Defender Antivirus",
    "*- Tier 0 DCs MSFT Windows 10 and Server 2016 Defender",
    "*- Tier 0 DCs MSFT Windows Server 2012 R2 Domain Controller Baseline",
    "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller",
    "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller Virtualization Based Security",
    "*- Tier 0 DCs MSFT Windows Server 2022 - Defender Antivirus",
    "*- Tier 0 DCs MSFT Windows Server 2022 - Domain Controller",
    "*- Tier 0 DCs MSFT Windows Server 2022 - Domain Controller Virtualization Based Security",
    "*- Tier 0 DCs SCM Windows Server 2016 - Domain Controller Baseline",
    "*- Tier 0 DCs Windows Server 2019 Disable System Guard Secure Launch",
    "*- Tier 0 PAWs",
    "*- Tier 0 PAWs Admin",
    "*- Tier 0 PAWs BitLocker",
    "*- Tier 0 PAWs Devices Base AppLocker Audit",
    "*- Tier 0 PAWs Devices Base AppLocker Enforce",
    "*- Tier 0 PAWs Internet Access Configuration - User",
    "*- Tier 0 PAWs LAPS",
    "*- Tier 0 PAWs MSFT Edge Version 107 - Computer",
    "*- Tier 0 PAWs MSFT Internet Explorer 11 - Computer",
    "*- Tier 0 PAWs MSFT Internet Explorer 11 - User",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - Computer",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - User",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - Computer",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - User",
    "*- Tier 0 PAWs Telemetry Configuration",
    "*- Tier 0 Servers",
    "*- Tier 0 Servers Host Guardian Service Administration Policy",
    "*- Tier 0 Servers LAPS",
    "*- Tier 0 Servers MSFT Edge Version 107 - Computer",
    "*- Tier 0 Servers MSFT Internet Explorer 11 - Computer",
    "*- Tier 0 Servers MSFT Windows 10 1809 and Server 2019 - Defender Antivirus",
    "*- Tier 0 Servers MSFT Windows 10 1809 and Server 2019 Member Server - Credential Guard",
    "*- Tier 0 Servers MSFT Windows 10 and Server 2016 - Credential Guard",
    "*- Tier 0 Servers MSFT Windows 10 and Server 2016 Defender",
    "*- Tier 0 Servers MSFT Windows Server 2012 R2 Member Server Baseline",
    "*- Tier 0 Servers MSFT Windows Server 2019 - Member Server",
    "*- Tier 0 Servers MSFT Windows Server 2022 - Defender Antivirus",
    "*- Tier 0 Servers MSFT Windows Server 2022 - Member Server",
    "*- Tier 0 Servers MSFT Windows Server 2022 - Member Server Credential Guard",
    "*- Tier 0 Servers SCM Windows Server 2016 - Member Server Baseline - Computer",
    "*- Tier 0 Servers SCM Windows Server 2016 - Member Server Baseline - User",
    "*- Tier 0 Servers Windows Server 2019 Disable System Guard Secure Launch",
    "*- Tier 1 PAWs",
    "*- Tier 1 PAWs Admin",
    "*- Tier 1 PAWs BitLocker",
    "*- Tier 1 PAWs Devices Base AppLocker Audit",
    "*- Tier 1 PAWs Devices Base AppLocker Enforce",
    "*- Tier 1 PAWs Internet Access Configuration - User",
    "*- Tier 1 PAWs LAPS",
    "*- Tier 1 PAWs MSFT Edge Version 107 - Computer",
    "*- Tier 1 PAWs MSFT Internet Explorer 11 - Computer",
    "*- Tier 1 PAWs MSFT Internet Explorer 11 - User",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - Computer",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - User",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - Computer",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - User",
    "*- Tier 1 PAWs Telemetry Configuration",
    "*- Tier 1 Servers",
    "*- Tier 1 Servers LAPS",
    "*- Tier 1 Servers MSFT Edge Version 107 - Computer",
    "*- Tier 1 Servers MSFT Internet Explorer 11 - Computer",
    "*- Tier 1 Servers MSFT Windows 10 1809 and Server 2019 - Defender Antivirus",
    "*- Tier 1 Servers MSFT Windows 10 1809 and Server 2019 Member Server - Credential Guard",
    "*- Tier 1 Servers MSFT Windows 10 and Server 2016 - Credential Guard",
    "*- Tier 1 Servers MSFT Windows 10 and Server 2016 Defender",
    "*- Tier 1 Servers MSFT Windows Server 2012 R2 Member Server Baseline",
    "*- Tier 1 Servers MSFT Windows Server 2019 - Member Server",
    "*- Tier 1 Servers MSFT Windows Server 2022 - Defender Antivirus",
    "*- Tier 1 Servers MSFT Windows Server 2022 - Member Server",
    "*- Tier 1 Servers MSFT Windows Server 2022 - Member Server Credential Guard",
    "*- Tier 1 Servers SCM Windows Server 2016 - Member Server Baseline - Computer",
    "*- Tier 1 Servers SCM Windows Server 2016 - Member Server Baseline - User",
    "*- Tier 1 Servers Staging",
    "*- Tier 1 Servers Windows Server 2019 Disable System Guard Secure Launch",
    "*- Tier 2 Devices Staging",
    "*- Tier 2 LAPS",
    "*- Tier 2 MSFT Edge Version 107 - Computer",
    "*- Tier 2 MSFT Internet Explorer 11 - Computer",
    "*- Tier 2 MSFT Internet Explorer 11 - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Computer",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - DDE Block - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Legacy File Block - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Legacy JScript Block - Computer",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Require Macro Signing - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - User",
    "*- Tier 2 MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 2 MSFT Windows 11 21H2 - Computer",
    "*- Tier 2 MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 2 MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 2 MSFT Windows 11 21H2 - User",
    "*- Tier 2 MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 2 MSFT Windows 11 22H2 - Computer",
    "*- Tier 2 MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 2 MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 2 MSFT Windows 11 22H2 - User",
    "*- Tier 2 PAWs",
    "*- Tier 2 PAWs Admin",
    "*- Tier 2 PAWs BitLocker",
    "*- Tier 2 PAWs Devices Base AppLocker Audit",
    "*- Tier 2 PAWs Devices Base AppLocker Enforce",
    "*- Tier 2 PAWs Internet Access Configuration - User",
    "*- Tier 2 PAWs LAPS",
    "*- Tier 2 PAWs MSFT Edge Version 107 - Computer",
    "*- Tier 2 PAWs MSFT Internet Explorer 11 - Computer",
    "*- Tier 2 PAWs MSFT Internet Explorer 11 - User",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - Computer",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - User",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - Computer",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - User",
    "*- Tier 2 PAWs Telemetry Configuration",
    "*- Tier 2 Workstations"
)

foreach ($existingGPOName in $existingGPONames) {
    
    # Get the GPO object
    $gpo = Get-GPO -DisplayName $existingGPOName

    # Replace name with new name
    $newName = $gpo.DisplayName -replace '[*]', '*RM'
        
    # Rename the GPO
    Rename-GPO -Guid $gpo.Id -TargetName $newName -Server $preferredDC
    Write-Output "Renamed GPO '$($gpo.DisplayName)' to '$newName'"

}

# SIG # Begin signature block
# MIIoPAYJKoZIhvcNAQcCoIIoLTCCKCkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBa9n41RNaQ9Cwc
# wmb3nOImt8rsVMpu0+9OJrB/U2ZV8KCCDYUwggYDMIID66ADAgECAhMzAAAEhJji
# EuB4ozFdAAAAAASEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM1WhcNMjYwNjE3MTgyMTM1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDtekqMKDnzfsyc1T1QpHfFtr+rkir8ldzLPKmMXbRDouVXAsvBfd6E82tPj4Yz
# aSluGDQoX3NpMKooKeVFjjNRq37yyT/h1QTLMB8dpmsZ/70UM+U/sYxvt1PWWxLj
# MNIXqzB8PjG6i7H2YFgk4YOhfGSekvnzW13dLAtfjD0wiwREPvCNlilRz7XoFde5
# KO01eFiWeteh48qUOqUaAkIznC4XB3sFd1LWUmupXHK05QfJSmnei9qZJBYTt8Zh
# ArGDh7nQn+Y1jOA3oBiCUJ4n1CMaWdDhrgdMuu026oWAbfC3prqkUn8LWp28H+2S
# LetNG5KQZZwvy3Zcn7+PQGl5AgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUBN/0b6Fh6nMdE4FAxYG9kWCpbYUw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwNTM2MjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGLQps1XU4RTcoDIDLP6QG3NnRE3p/WSMp61Cs8Z+JUv3xJWGtBzYmCINmHVFv6i
# 8pYF/e79FNK6P1oKjduxqHSicBdg8Mj0k8kDFA/0eU26bPBRQUIaiWrhsDOrXWdL
# m7Zmu516oQoUWcINs4jBfjDEVV4bmgQYfe+4/MUJwQJ9h6mfE+kcCP4HlP4ChIQB
# UHoSymakcTBvZw+Qst7sbdt5KnQKkSEN01CzPG1awClCI6zLKf/vKIwnqHw/+Wvc
# Ar7gwKlWNmLwTNi807r9rWsXQep1Q8YMkIuGmZ0a1qCd3GuOkSRznz2/0ojeZVYh
# ZyohCQi1Bs+xfRkv/fy0HfV3mNyO22dFUvHzBZgqE5FbGjmUnrSr1x8lCrK+s4A+
# bOGp2IejOphWoZEPGOco/HEznZ5Lk6w6W+E2Jy3PHoFE0Y8TtkSE4/80Y2lBJhLj
# 27d8ueJ8IdQhSpL/WzTjjnuYH7Dx5o9pWdIGSaFNYuSqOYxrVW7N4AEQVRDZeqDc
# fqPG3O6r5SNsxXbd71DCIQURtUKss53ON+vrlV0rjiKBIdwvMNLQ9zK0jy77owDy
# XXoYkQxakN2uFIBO1UNAvCYXjs4rw3SRmBX9qiZ5ENxcn/pLMkiyb68QdwHUXz+1
# fI6ea3/jjpNPz6Dlc/RMcXIWeMMkhup/XEbwu73U+uz/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAASEmOIS4HijMV0AAAAA
# BIQwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICIL
# q8U0pfOuBHbx4WxIsfc80GJ8Fnn/5TXTbfcOB/yBMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAVfIiezqD/vsnwpL26s4uGp1Hdz9ySU8Nq5jl
# oaxUWukQz9gs5m3mgnYFWFUUtIyiPrvTt0C2qUbfwGxw0+6h1VQE/y25HeW8c6tP
# C0tMFU5hjMcKtC0y0OQXLFdMWCXmu642xsBlS3i8Wp4yAEo643JWm+NH8wRCpe97
# U+9n0Nl1g0vJgO/ImnJiMDgwbdVcGOF/v7A+HPyOwCY/75LsyeG0ZorycPpvchZa
# 5PeOj1QrqjbhhtsYrJxFVTSwdD3A232as76Aefr6YsG3BVeVutN28vs4Hq1OppYJ
# aJD0puk7DUPjc4HN5WsCm5Lm1FP+144M/ZYnqmIuGBqmo0oGTKGCF5cwgheTBgor
# BgEEAYI3AwMBMYIXgzCCF38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFSBgsqhkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCD/VyvVqx5mRnLRkLz7ubcL3QNen3nTBUPL
# LHxmTICV2gIGaEtDcHTdGBMyMDI1MDcyOTE4MjgyMy45MzhaMASAAgH0oIHRpIHO
# MIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxk
# IFRTUyBFU046RjAwMi0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFNlcnZpY2WgghHtMIIHIDCCBQigAwIBAgITMwAAAgU8dWyCRIfN/gAB
# AAACBTANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDAeFw0yNTAxMzAxOTQyNDlaFw0yNjA0MjIxOTQyNDlaMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046RjAwMi0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCSkvLfd7gF1r2wGdy85CFY
# XHUC8ywEyD4LRLv0WYEXeeZ0u5YuK7p2cXVzQmZPOHTN8TWqG2SPlUb+7PldzFDD
# AlR3vU8piOjmhu9rHW43M2dbor9jl9gluhzwUd2SciVGa7f9t67tM3KFKRSMXFtH
# KF3KwBB7aVo+b1qy5p9DWlo2N5FGrBqHMEVlNyzreHYoDLL+m8fSsqMu/iYUqxzK
# 5F4S7IY5NemAB8B+A3QgwVIi64KJIfeKZUeiWKCTf4odUgP3AQilxh48P6z7AT4I
# A0dMEtKhYLFs4W/KNDMsYr7KpQPKVCcC5E8uDHdKewubyzenkTxy4ff1N3g8yho5
# Pi9BfjR0VytrkmpDfep8JPwcb4BNOIXOo1pfdHZ8EvnR7JFZFQiqpMZFlO5CAuTY
# H8ujc5PUHlaMAJ8NEa9TFJTOSBrB7PRgeh/6NJ2xu9yxPh/kVN9BGss93MC6Ujpo
# xeM4x70bwbwiK8SNHIO8D8cql7VSevUYbjN4NogFFwhBClhodE/zeGPq6y6ixD4z
# 65IHY3zwFQbBVX/w+L/VHNn/BMGs2PGHnlRjO/Kk8NIpN4shkFQqA1fM08frrDSN
# EY9VKDtpsUpAF51Y1oQ6tJhWM1d3neCXh6b/6N+XeHORCwnY83K+pFMMhg8isXQb
# 6KRl65kg8XYBd4JwkbKoVQIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFHR6Wrs27b6+
# yJ3bEZ9o5NdL1bLwMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQAOuxk47b1i75V8
# 1Tx6xo10xNIr4zZxYVfkF5TFq2kndPHgzVyLnssw/HKkEZRCgZVpkKEJ6Y4jvG5t
# ugMi+Wjt7hUMSipk+RpB5gFQvh1xmAEL2flegzTWEsnj0wrESplI5Z3vgf2eGXAr
# /RcqGjSpouHbD2HY9Y3F0Ol6FRDCV/HEGKRHzn2M5rQpFGSjacT4DkqVYmem/ArO
# fSvVojnKEIW914UxGtuhJSr9jOo5RqTX7GIqbtvN7zhWld+i3XxdhdNcflQz9Yho
# FqQexBenoIRgAPAtwH68xczr9LMC3l9ALEpnsvO0RiKPXF4l22/OfcFffaphnl/T
# DwkiJfxOyAMfUF3xI9+3izT1WX2CFs2RaOAq3dcohyJw+xRG0E8wkCHqkV57BbUB
# EzLX8L9lGJ1DoxYNpoDX7iQzJ9Qdkypi5fv773E3Ch8A+toxeFp6FifQZyCc8IcI
# BlHyak6MbT6YTVQNgQ/h8FF+S5OqP7CECFvIH2Kt2P0GlOu9C0BfashnTjodmtZF
# ZsptUvirk/2HOLLjBiMjDwJsQAFAzJuz4ZtTyorrvER10Gl/mbmViHqhvNACfTzP
# iLfjDgyvp9s7/bHu/CalKmeiJULGjh/lwAj5319pggsGJqbhJ4FbFc+oU5zffbm/
# rKjVZ8kxND3im10Qp41n2t/qpyP6ETCCB3EwggVZoAMCAQICEzMAAAAVxedrngKb
# SZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIy
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXI
# yjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjo
# YH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1y
# aa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v
# 3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pG
# ve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viS
# kR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYr
# bqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlM
# jgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSL
# W6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AF
# emzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIu
# rQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIE
# FgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWn
# G1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEW
# M2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5
# Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBi
# AEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV
# 9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3Js
# Lm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv
# 6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZn
# OlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1
# bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4
# rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU
# 6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDF
# NLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/
# HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdU
# CbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKi
# excdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTm
# dHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZq
# ELQdVTNYs6FwZvKhggNQMIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJp
# Y2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkYwMDItMDVF
# MC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMK
# AQEwBwYFKw4DAhoDFQDVsH9p1tJn+krwCMvqOhVvXrbetKCBgzCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7DMLjDAi
# GA8yMDI1MDcyOTA4NTc0OFoYDzIwMjUwNzMwMDg1NzQ4WjB3MD0GCisGAQQBhFkK
# BAExLzAtMAoCBQDsMwuMAgEAMAoCAQACAghfAgH/MAcCAQACAhNXMAoCBQDsNF0M
# AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSCh
# CjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBAA2peG3jOE2w+hKIuKBN27vU
# 73fKGiuDyhPc9p7MFI6Yl2e4ugcC8aWFmtp+mLDxIUXPLGoUPxS8hOatDlVGeSJ5
# 0lBLhD1FHm7+HVmtC8GNbgCG3KH7K1VIEPWtch07FiefkMvbkIdg6IwKndBMgb0s
# 0wSUw3/H5a8KnOorEdoY+A+3OXGdQcQZfD4eaPHvI1b7+GSeSFS2xRHI1ZQtxDff
# +8Kh5Z99kw93vTrE99+l7Y6PdP1bAHjhOPnOLxDxtfzLwbgcEGo4vOkrI1HROxn8
# ifpseiGJ9GczYZhe4CDQ2nBigo1U99TYi43fVFTlbUAMWgLF8HCAbi2+HfTYIdox
# ggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AgU8dWyCRIfN/gABAAACBTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDYwCOZcxMlkafnkkphpwep
# G3xquTG5QzApdgUzqsZCqDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIIAN
# Az3ceY0umhdWLR2sJpq0OPqtJDTAYRmjHVkwEW9IMIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAIFPHVsgkSHzf4AAQAAAgUwIgQgqNHc
# KvV91DF0c0GEazBuNUL4Mz6tH+k+K8pHc+ju3CkwDQYJKoZIhvcNAQELBQAEggIA
# VQCsXlB6OSKrRVCPxk9+KaGBS2guih2XMsZE7hc+8jUlR8oVZjzCp25diZcpuMiJ
# GspNzgyJyxOou/0jO4nnXCm9ah6U6SPD1puVq30z0osbpmO18ujPS85lb4IP2Cpt
# dsZ+LC1zue2zmO9wLj1MUZv+keMjnI2ujPfkkp26URPHqAbWYWam9AhuWIYoAgbk
# VtnWRVed6mvc57E+qSjuNyn6ZbZMJTiRAiVA1T59Aw+N2tvXe6w+laldTZnHGIW2
# fBBrXRru3dhd+1D7/zh/NL19aXth0F5iyiy8wbQN22Go60p+H1eu5wb6nyzpCczM
# 7WBBkfhyHmn0lC++WXikX9RB+wKpjyscabNSU3+4Rgze9HDmMco2d1+fpif6vYkn
# U86aFLuMnCTHW/B+dX9u4qNe7NfdErE5UEYTLjUMMQ68gPAPMFStKJiTqeTJ067J
# +/CEKVecmxhU700kd1+kd2nwLc/fD/4Mxv57t812Jf++MfC1gQ3JKGEX7QTVAtWz
# N6l56ZfBT/r5tUJ5DLdn0FfIyPT6wCqD2aOhhkDPB/aHIPrD9HL4mrB47U6v/lWa
# vW/cJwSkrZravNdRqwY6TgEnL/cxXATBfcOmME156p5bOv7tZ8th140N3O+W83J3
# kHvOnw+GxRpuOMOqOeaCGaTP8wx1gYv+aQzUmgr4XOw=
# SIG # End signature block
