[cmdletbinding(SupportsShouldProcess=$true)]
param (
    [Parameter(Mandatory=$false)]
	[string]$TieredUsersOU = "OU=Tier 1 Accounts,OU=Tier 1,OU=Tier Model Administration",
    
    [Parameter(Mandatory=$false)]
    [string]$TieredServiceAccountsOU = "OU=Tier 1 Service Accounts,OU=Tier 1,OU=Tier Model Administration",
	   
	[Parameter(Mandatory=$false)]
	[string]$KerberosPolicyName = "*- Tier 1 Authentication Silo",
    
    [Parameter (Mandatory=$false)]
    [string]$ExcludeTieredUser = "svc-t1srvdomainjoin",
    
    [Parameter(Mandatory=$false)]
    [switch]$MultiDomainForest = $false,

    [Parameter(Mandatory=$false)]
    [bool]$RemoveUserFromPrivilegedGroups = $true,
    
    [Parameter(Mandatory=$false)]
    [switch]$ExcludeProtectedUsersGroup
)
<#
.Synopsis
    This scripts is meant to maintain the Tier 1 Users and ensure they are assigned to the Tier 1 Authentication Silo policy.

.DESCRIPTION
    The script will get all Tier 1 User objects within the Tier 1 Accounts OU and assign them to the Tier 1 Authentication Silo policy. 
    Any users not within the Tier 1 Accounts OU will be removed from the Tier 1 Authentication Silo policy. 
    The script will also ensure that the Tier 1 Users are marked as sensitive and cannot be delegated.
    The script will also add the users to the Protected Users group.
    By default the script will not add any Tier 1 Servers Accounts, Tier 1 MSA, Tier 1 gMSA, or Tier 1 dMSA accounts automatically, thus must be manually added to the Tier 1 Authentication Silo policy.

.PARAMETER TieredUsersOU
    Path of the Tier 1 Accounts OU which contains all Tier 1 User objects

.PARAMETER KerberosPolicyName
    Name of the Tier 1 Authentication Silo policy to assign to all Tier 1 Users objects

.PARAMETER TieredServiceAccountsOU
    Name of the Tier 1 Service Accounts OU which contains all Tier 1 Service Account objects, this is used to exclude these accounts from the Tier 1 Authentication Silo policy.

.PARAMETER ExcludeTieredUser
    List of any Tier 1 User accounts to be excluded from the Tier 1 Authentication Silo policy such as a Domain join account which requires NTLM authentication.

.PARAMETER MultiDomainForest
    The script will manage all privileged users / groups in every domain of the forest.

.PARAMETER RemoveUserFromPrivilegedGroups
    Default is $true. If set to $true, the script will remove any users from the following groups: Administrators, Domain Admins, Backup Operators, Server Managers, Account

.EXAMPLE
    Tier1UserManagement.ps1 -PrivilegedOUPath "OU=Privileged Accounts,OU=Tier 1,OU=Admin" -KerberosPolicyName "Tier 1 Isolation" -PrivilegedServiceAcocuntOU "OU=service accounts,OU=Tier 1,OU=Admin"  -EnableMultiDomainSupport

.NOTES
    This sample script is not supported under any Microsoft standard support program or service. 
    The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims 
    all implied warranties including, without limitation, any implied warranties of merchantability 
    or of fitness for a particular purpose. The entire risk arising out of the use or performance of 
    the sample scripts and documentation remains with you. In no event shall Microsoft, its authors, 
    or anyone else involved in the creation, production, or delivery of the scripts be liable for any 
    damages whatsoever (including, without limitation, damages for loss of business profits, business 
    interruption, loss of business information, or other pecuniary loss) arising out of the use of or 
    inability to use the sample scripts or documentation, even if Microsoft has been advised of the 
    possibility of such damages 
#>
function Write-Log {
    param (
        # status message
        [Parameter(Mandatory=$true)]
        [string]
        $Message,
        #Severity of the message
        [Parameter (Mandatory = $true)]
        [Validateset('Error', 'Warning', 'Information', 'Debug') ]
        $Severity
    )
    #Format the log message and write it to the log file
    $LogLine = "$(Get-Date -Format o), [$Severity], $Message"
    Add-Content -Path $LogFile -Value $LogLine 
    switch ($Severity) {
        'Error'   { 
            Write-Host $Message -ForegroundColor Red
            Add-Content -Path $LogFile -Value $Error[0].ScriptStackTrace  
        }
        'Warning' { Write-Host $Message -ForegroundColor Yellow}
        'Information' { Write-Host $Message }
    }
}

function validateAndRemoveUser{
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        #The SID uof the group
        [string] $SID,
        #The DNS domain Name
        [string] $DomainDNSName
    )
    $Group = Get-ADGroup -Identity $SID -Properties members,canonicalName -Server $DomainDNSName 
    #validate the SID exists
    if ($null -eq $Group){
        Write-Log "Can't validate $SID. This SID is not available" -Severity Warning
        return
    }
    #walk through all members of the group and check this member is a valid user or group
    foreach ($Groupmember in $Group.members)
    {
        $member = Get-ADObject -Filter {DistinguishedName -eq $Groupmember} -Properties * -server "$($DomainDNSName):3268"
        switch ($member.ObjectClass){
            "user"{
                if (($member.ObjectSid.value   -notlike "*-500")                              -and ` #ignore if the member is Built-In Administrator
                    ($member.objectSid.value   -notlike "*-512")                              -and ` #ignore if the member is Domain Admins group
                    ($member.ObjectSid.value   -notlike "*-518")                              -and ` #ignore if the member is Schema Admins
                    ($member.ObjectSid.Value   -notlike "*-519")                              -and ` #ignore if the member is Enterprise Admins
                    ($member.objectSid.Value   -notlike "*-520")                              -and ` #ignore if the member is Group Policy Creator
                    ($member.objectSid.Value   -notlike "*-522")                              -and ` #ignore if the member is cloneable domain controllers
                    ($member.objectSid.Value   -notlike "*-527")                              -and ` #ignore if the member is Enterprise Key Admins
                    ($member.objectClass       -ne "msDS-GroupManagedServiceAccount")         -and ` #ignore if the member is a GMSA
                    ($member.distinguishedName -notlike "*,$TieredUsersOU,*")              -and ` #ignore if the member is located in the Tier 1 user OU
                    ($member.distinguishedName -notlike "*,$TieredServiceAccountsOU*") -and ` #ignore if the member is located in the service account OU
                    ($ExcludeTieredUser              -notlike "*$($member.DistinguishedName)*" )           #ignore if the member is in the exclude user list
                    ){    
                        try{
                            Write-Log -Message "remove $member from $($Group.DistinguishedName)" -Severity Information
                            Set-ADObject -Identity $Group -Remove @{member="$($member.DistinguishedName)"} -Server $DomainDNSName
                        }
                        catch [Microsoft.ActiveDirectory.Management.ADServerDownException]{
                            Write-Log -Message "can't connect to AD-WebServices. $($member.DistinguishedName) is not remove from $($Group.DistinguishedName)" -Severity Error
                        }
                        catch [Microsoft.ActiveDirectory.Management.ADException]{
                            Write-Log -Message "Cannot remove $($member.DistinguishedName) from $($Error[0].CategoryInfo.TargetName) $($Error[0].Exception.Message)" -Severity Error
                        }
                        catch{
                            Write-Log -Message $Error[0].GetType().Name -Severity Error
                        }
                    }
            }
            "group"{
                $MemberDomainDN = [regex]::Match($member.DistinguishedName,"DC=.*").value
                $MemberDNSroot = (Get-ADObject -Filter "ncName -eq '$MemberDomainDN'" -SearchBase (Get-ADForest).Partitionscontainer -Properties dnsRoot).dnsRoot
                validateAndRemoveUser -SID $member.ObjectSid.Value -DomainDNSName $MemberDNSroot
            }
        }
    }        
}

#region Manage log file
[int]$MaxLogFileSize = 1048576 #Maximum size of the log file
$LogFile = "$($env:LOCALAPPDATA)\$($MyInvocation.MyCommand).log" #Name and path of the log file
#rename existing log files to *.sav if the currentlog file exceed the size of $MaxLogFileSize
if (Test-Path $LogFile){
    if ((Get-Item $LogFile ).Length -gt $MaxLogFileSize){
        if (Test-Path "$LogFile.sav"){
            Remove-Item "$LogFile.sav"
        }
        Rename-Item -Path $LogFile -NewName "$logFile.sav"
    }
}
#endregion
Write-Log -Message $MyInvocation.Line -Severity Debug

#Validate the Kerberos Authentication policy exists. If not terminate the script with error code 0xA3. 
$KerberosAuthenticationPolicy = Get-ADAuthenticationPolicy -Filter {Name -eq $KerberosPolicyName}
if ($null -eq $KerberosAuthenticationPolicy){
    Write-Log -Message "Kerberos Authentication Policy '$KerberosPolicyName' not found on AD. Script terminates with error 0xA3" -Severity Error
    exit 0xA3
}
# enumerate the target domains. If the EnableMultiDomain switch is enabled in a multi domain forest, any domain will be part of the 
# Tier 1 user management. This is the recommended configuration, because the security boundary of Active Directory is the forest not the 
# domain. Any target domain will be captured in the $aryDomainName variable
$aryDomainName = @() #contains all domains for script validation
if ($MultiDomainForest){
    #MultidomainSupport is enabled get all forest domains
    $aryDomainName += (Get-ADForest).Domains
    Write-Log -Message "Multidomain mode is enabled. Found $((Get-ADDomain).Domains.count) domains" -Severity Debug
} else {
    $aryDomainName += (Get-ADDomain).DNSRoot
    Write-Log -Message "Single domain mode is enabled" -Severity Information
}

foreach ($DomainName in $aryDomainName){
    #validating Web-Services are running on this domain
    try {
    Write-Log "Connect to $((Get-ADDomain -Server $DomainName).DistinguishedName) AD web services" -Severity Debug    
    #region Validate the group membership and authentication policy settings in the Tier 1 OU 
        try{
            $oProtectedUsersGroup = Get-ADGroup -Identity "$((Get-ADDomain -Server $domainName).DomainSID)-525" -Server $DomainName -Properties members
            #search for any user in the privileged OU
            foreach ($user in Get-ADUser -SearchBase "$TieredUsersOU,$((Get-ADDomain -Server $DomainName).DistinguishedName)" -Filter * -Properties msDS-AssignedAuthNPolicy,memberOf,UserAccountControl -SearchScope Subtree -Server $DomainName){
                Write-Log -Message "Working on $($User.Distiguishedname)" -Severity Debug
                
                if (($user.UserAccountControl -BAND 1048576) -ne 1048576){
                    try {
                        Set-ADAccountControl -Identity $user -AccountNotDelegated $True
                        Write-Log "Mark $($User.DistinguishedName) as sensitive and cannot be delegated" -Severity Information
                    }
                    catch [Microsoft.ActiveDirectory.Management.ADException]{
                        Write-Log "Cannot add Sensitive flag to the $($user.DistinguishedName)" -Severity Error
                    }
                }
                if ($ExcludeProtectedUsersGroup -ne $true){
                    try{
                        if (($oProtectedUsersGroup.members -notlike $user.DistinguishedName) -or ($oProtectedUsersGroup.Members.Count -eq 0)) {
                            Add-ADGroupMember -Identity $oProtectedUsersGroup $user -Server $DomainName
                            
                            Write-Log "User $($user.Distiguishedname) is addeded to protected users in $Domain" -Severity Information
                        }
                    }
                    catch [Microsoft.ActiveDirectory.Management.ADException]{
                        Write-Log "A access denied error has occured on User $($user.DistinguishedName) while adding user to the protected users group)" -Severity Error
                    }
                }
                #validate the Kerberos Authentication policy is assigned to the user
                if ($user.'msDS-AssignedAuthNPolicy' -ne $KerberosAuthenticationPolicy.DistinguishedName){
                    try {
                        Write-Log "Adding Kerberos Authentication Policy $KerberosPolicyName on $User" -Severity Information
                        Set-ADUser $user -AuthenticationPolicy $KerberosPolicyName -Server $DomainName
                        #if the Kerberos Authentication policy is assigned to a user, the user will be marked as "This user is sensitive and cannot be delegated"
                        #This attribute will only applied to the user, while adding the KerbAuthPol. If the attribute will be removed afterwards it will not be 
                        #reapplied
                        Set-ADAccountControl -Identity $user -AccountNotDelegated $True
                    }
                    catch {
                        Write-Log -Message "The Kerberos Authenticatin Policy $KerberosPolicyName could not be added to $($user.DistinguishedName))" -Severity Error
                    }
                }
            }
        } 
        catch [Microsoft.ActiveDirectory.Management.ADIdentityNotFoundException]{
            Write-Log "Can't get the users in $TieredUsersOU on $domain. ADIdentityNotFoundException" -Severity Error
        }
        catch {
            Write-Log "A unexpected error has occured $($Error[0])" -Severity Error
        }
        #endregion

        #region validate Critical Group Membership
        #any user / group object who is not fulfill the criteria will be removed from the privileged groups
        #store any well-known critical domain group with relative domain sid in $PrivilegedDomainSID
        #groups like Backup Operators, Print Operators, Administrators have a well-known SID without domain SID 
        #Using the SID, provides language independency
        $PrivlegeDomainSid = @(
            "512", #Domain Admins
            "520", #Group Policy Creator Owner
            "522" #Cloneable Domain Controllers
        #   "527" #Enterprise Key Admins
        )
        if ($RemoveUserFromPrivilegedGroups){
            Write-Log "searching for unexpected users in critical groups" -Severity Debug
            foreach ($relativeSid in $PrivlegeDomainSid) {
                validateAndRemoveUser -SID "$((Get-ADDomain -server $DomainName).DomainSID)-$RelativeSid" -DomainDNSName $DomainName
            }
            #Backup Operators
            validateAndRemoveUser -SID "S-1-5-32-551" -DomainDNSName $DomainName
            #Print Operators
            validateAndRemoveUser -SID "S-1-5-32-550" -DomainDNSName $DomainName
            #Server Operators
            validateAndRemoveUser -SID "S-1-5-32-549" -DomainDNSName $DomainName
            #Server Operators
            validateAndRemoveUser -SID "S-1-5-32-548" -DomainDNSName $DomainName
            #Administrators
            validateAndRemoveUser -SID "S-1-5-32-544" -DomainDNSName $DomainName
    }
}
catch {
    Write-Log -Message "Failed to connect to AD Webservices on $DomainName" -Severity Error
}

#endregion
}
#Schema and Enterprise Admins only exists in Forest root domain
if ($RemoveUserFromPrivilegedGroups){
    $forestDNS = (Get-ADDomain).Forest
    $forestSID = (Get-ADDomain -Server $forestDNS).DomainSID.Value
    Write-Log "searching for unexpected users in schema admins" -Severity Debug
    validateAndRemoveUser -SID "$forestSID-518" -DomainDNSName $forestDNS
    Write-Log "searching for unexpteded users in enterprise admins" -Severity Debug
    validateAndRemoveUser -SID "$forestSID-519" -DomainDNSName $forestDNS
}

# SIG # Begin signature block
# MIIoUQYJKoZIhvcNAQcCoIIoQjCCKD4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQiG/HgHoRqwqF
# GWBG+Ba+NmvUKYjhcMExW+QfZC3Bc6CCDYUwggYDMIID66ADAgECAhMzAAAEhJji
# EuB4ozFdAAAAAASEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM1WhcNMjYwNjE3MTgyMTM1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDtekqMKDnzfsyc1T1QpHfFtr+rkir8ldzLPKmMXbRDouVXAsvBfd6E82tPj4Yz
# aSluGDQoX3NpMKooKeVFjjNRq37yyT/h1QTLMB8dpmsZ/70UM+U/sYxvt1PWWxLj
# MNIXqzB8PjG6i7H2YFgk4YOhfGSekvnzW13dLAtfjD0wiwREPvCNlilRz7XoFde5
# KO01eFiWeteh48qUOqUaAkIznC4XB3sFd1LWUmupXHK05QfJSmnei9qZJBYTt8Zh
# ArGDh7nQn+Y1jOA3oBiCUJ4n1CMaWdDhrgdMuu026oWAbfC3prqkUn8LWp28H+2S
# LetNG5KQZZwvy3Zcn7+PQGl5AgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUBN/0b6Fh6nMdE4FAxYG9kWCpbYUw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwNTM2MjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGLQps1XU4RTcoDIDLP6QG3NnRE3p/WSMp61Cs8Z+JUv3xJWGtBzYmCINmHVFv6i
# 8pYF/e79FNK6P1oKjduxqHSicBdg8Mj0k8kDFA/0eU26bPBRQUIaiWrhsDOrXWdL
# m7Zmu516oQoUWcINs4jBfjDEVV4bmgQYfe+4/MUJwQJ9h6mfE+kcCP4HlP4ChIQB
# UHoSymakcTBvZw+Qst7sbdt5KnQKkSEN01CzPG1awClCI6zLKf/vKIwnqHw/+Wvc
# Ar7gwKlWNmLwTNi807r9rWsXQep1Q8YMkIuGmZ0a1qCd3GuOkSRznz2/0ojeZVYh
# ZyohCQi1Bs+xfRkv/fy0HfV3mNyO22dFUvHzBZgqE5FbGjmUnrSr1x8lCrK+s4A+
# bOGp2IejOphWoZEPGOco/HEznZ5Lk6w6W+E2Jy3PHoFE0Y8TtkSE4/80Y2lBJhLj
# 27d8ueJ8IdQhSpL/WzTjjnuYH7Dx5o9pWdIGSaFNYuSqOYxrVW7N4AEQVRDZeqDc
# fqPG3O6r5SNsxXbd71DCIQURtUKss53ON+vrlV0rjiKBIdwvMNLQ9zK0jy77owDy
# XXoYkQxakN2uFIBO1UNAvCYXjs4rw3SRmBX9qiZ5ENxcn/pLMkiyb68QdwHUXz+1
# fI6ea3/jjpNPz6Dlc/RMcXIWeMMkhup/XEbwu73U+uz/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGiIwghoeAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAASEmOIS4HijMV0AAAAA
# BIQwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIKT0
# S9JuEJCP7XIBx0O5pSd3jvSIOb+brKe3qV2PQx4KMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAXGyPB7arpJ0sn2xIfm+tL4i+T13LSZP81MGG
# PEIINbKvwvQyH4HyjJXDbTyrfvF8WHITuwGK27CCuvtHE2fz87qWf1jazwUaDWX8
# bITq10ngf7TaNpiIPU4Luncnlk5CzarjjiJp71dPcqydEAxicDMmYA9tAVoVQmwP
# 814yz4KHtY2baFCljzsXt8dJKAVMctRae7i+gaVteRGQXD3D4fLTp8LcyGv2ke5f
# iaekewzXHQBoflHWo+BrIbDrnYTIrXC8+DWq7g0bVMbHZg6TfRSinBZHR28pu6j2
# 6Pgm9kG46sr5eAAixR6Yy9IBOxUVynin8xR4bVVismo1zcSTrKGCF6wwgheoBgor
# BgEEAYI3AwMBMYIXmDCCF5QGCSqGSIb3DQEHAqCCF4UwgheBAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFZBgsqhkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCDsQLg2i2CeA/e9wD0Xm6lEz426125J9uRL
# FtGgZtoIsQIGaHpuKm92GBIyMDI1MDcyOTE4MjgzNy41MVowBIACAfSggdmkgdYw
# gdMxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsT
# JE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMe
# blNoaWVsZCBUU1MgRVNOOjZGMUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIR+zCCBygwggUQoAMCAQICEzMAAAH8GKCv
# zGlahzoAAQAAAfwwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwHhcNMjQwNzI1MTgzMTE0WhcNMjUxMDIyMTgzMTE0WjCB0zELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9z
# b2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxk
# IFRTUyBFU046NkYxQS0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCn
# UMAovGltBw9Vg8eUkfJbtbmUFmMlZYOMx+XlbKG4DKU/8sObaFvjKZSZLKZXQQVF
# ByYzwHKnCOFY/wXvHiI7zx370Zn0xCY2HeNIOiGFdeB/ys40QDJ8I9WYnMzvK2y6
# tn3Ghxu4Qvv4/sSQjCg64wWVMXYb/O6rHUT7AA2yWk+o+lvw8LnoFDGAkIjUs4Xm
# WTcB48nvw4vdrD812WS91WXdWAFI9fg1rC3dSBSh+4+f9yn2/AooHC4hZAQVnzfs
# ZdchOyF3Yx+zqhh/FcS2aPZIEYSHFWzvERG5YZvRwrpp/LudoqRtkja/VSqzG5m3
# 3iuf97LbKe+6eXHRHr9vqc2QLWs5MB9aWmwCP9CXPIzq5hNLFhkLZhbMtttGXSVG
# 1LP7hN2lRT+gBlIH5j6zXZGqaDOLtFXE1wjaWb/+wISboDrecIkKBi0z4st72lOy
# GX9Z/w4649BGID6y1OyDz0E4b21uVrPaR946Rh/mF0fymEBu464NB+vqzlhrpb69
# nPoTRmx6fOLQ60x/lEJraEANhWBTEP6CsLwSm19Z5UBaBgJpAWF4039kY1AySTvx
# XrfKg8F98kQC74HnGVM9iiKNR2j01ei8magZePpHxOCyj5A9oAYcrEJsdrVAv0BI
# wXc6zWOuiAIcaLKR+nV0oaeYDnAlPo3HsF52VIOwCQIDAQABo4IBSTCCAUUwHQYD
# VR0OBBYEFJjxpSuxRrOHEHIfv12GJAIv/tB2MB8GA1UdIwQYMBaAFJ+nFV0AXmJd
# g/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGlt
# ZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0l
# AQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUA
# A4ICAQBPuyz9kBnRtNoWyuyIlh3/8tDoiYpv0llIqJHD3GzyHCTlj/vOKCf2Aa3B
# 5EKELaUnwZVEeCsWQHEAKO64+mtLP9RhfufnbYkpy52da4h4TWnfQFmuo9M6exwP
# 3wNmLpY1MDKadpLuK3moCA0iet4AltNTZwCiwmh5cAevnRiBIaWYkz5w3qZgsAvp
# NMUy0Vgmukr1MzlHKHl5mabpRMmcaDSO3WkX/a7w9J3Pd0PLsMXsoMlp3aofFk5G
# 8zeT1Xxifckjlgs+4uyjYnmzd+lfIJWBH+GrzqDnON31tFHLKILyIsib833mrodZ
# WwJ7JJ62up+wPJhZK3Av3qHLsMjIsvmKHxgUx3QB2a9NGjKWYAO4rATZNAJO8+eO
# cuTvKklbb23XtjJrhX4mXPniwGc9TuQh5hmy9RP5gqDKQ/VAH6n65R1Efp7v1VqL
# P6J7Basglni1eQMyYvbWeHSP7nwTV5wBgO9PoHjIUh6ifED/oaX1ezsktyI8IgLq
# EZ2WKIQGnJh5QXSiFkWfs0pC7zQhnSN3nXVYDZurrH1pSr/MXJ/wSDD526dSPUq0
# 2hamrtW4mpqlyRiya+aZgdlcKMrUS6ztXUj5peOsFi6rIz1Cl4VlThTTVgbXm5bB
# QJqPS5mVqH9EZJgx3zjL0MKo6l94oTo8syTuEueG9w5CufE/qTCCB3EwggVZoAMC
# AQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29m
# dCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIy
# NVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9
# DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2
# Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N
# 7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXc
# ag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJ
# j361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjk
# lqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37Zy
# L9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M
# 269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLX
# pyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLU
# HMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode
# 2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYE
# FJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEB
# MEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# RG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt
# 4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsP
# MeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++
# Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9
# QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2
# wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aR
# AfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5z
# bcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nx
# t67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3
# Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+AN
# uOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/Z
# cGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNWMIICPgIBATCCAQGhgdmkgdYw
# gdMxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsT
# JE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMe
# blNoaWVsZCBUU1MgRVNOOjZGMUEtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBOQSklc5qojbB+
# oGzDg0tXCpiqqqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBCwUAAgUA7DNsZzAiGA8yMDI1MDcyOTE1NTEwM1oYDzIwMjUw
# NzMwMTU1MTAzWjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDsM2xnAgEAMAcCAQAC
# Ag3EMAcCAQACAhMbMAoCBQDsNL3nAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQAD
# ggEBAEHaq9x1w3hZiYcy8FJkupVDjzabTseGYgO/TTUTBhxDlWTvGJxZDJmd5LRi
# 8XDCL+bOc+BdnxYI79qVybY4+1/nEW01MSHi0EsDaZ4D1Gy2++dI4QtuMAoSF4He
# sE4ELCO2HZRcBhJoOR4B8LBNESO80pnor/uLltS9cpC4HPXo7uf+OBkH7tVJ4qCL
# D6tY8xFj7bT5af/YINB7M2V1HaedunAvmRXJP5FZ2n2tibo7s3Z9BT1i6FE8kFbB
# jMtx+VSgQV+/9f4j1quPqudn7/E5EEUWRO5oCIOfHgDiPVP5KRIPCdmBRyEhpmDp
# Id3MfSXbO0IOz/IBF9rgJT0rPEUxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAfwYoK/MaVqHOgABAAAB/DANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCAnh9xd9xEMKAnBhHXGi5QIP1hkU/rOCuaffMMthJHzRjCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EIJVCr5C77+H8E5U/jDB5TBse4JSGH5PuGrd3kwJo
# 0S1iMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAH8
# GKCvzGlahzoAAQAAAfwwIgQgwxu28GvfJ62bwLrZnVYoi/veYKpD6eYJB3eVm2NO
# ZjswDQYJKoZIhvcNAQELBQAEggIAVVu0qGVpJGK9+nUGa9X3dakIDP/sqUKkmGlU
# TAPaXvUYBw8VuM1Q2Zgv3LdwkD8z2J7c1ihqwNkaEqSCbVCi6CzOSroqVG677OBN
# 8hWQBEhu3ze2GTocKDBAmjgC40uOCl0jb9Upr0qnPB9rqhYSFN4NT0fTzh8DD63o
# EMPFnnrlxp74u3aNAEqnHV64JOqA08f0/4d4FMH5vJjyMADhRxB6ElI3RljpU0DW
# NgNudoIY7eMms+pKed1jDPKQgY3DF4A/dzHBamgHyp0e266OgUdkXMI3yhDxvh6F
# Tsp3JRQ6icDXTxpAS1fHsZmZqV4FxGtSWOsNvkra840am3lvtoB/Ia+sK9eS3ivu
# 9l70DLyH5tcSXez28sopzIjKIneQmf7rMPrYVzFO5hBxu2pfyaiPKYacGOhFxR/B
# oZxOzlyyRjPktjfQ3sXhN2OvU/vW3Miw8ccmTOe5sWZZ1txdcBDKL6FFE0TtjcOT
# 1YVPEJABp+oervwyDZe19EPzapG57yJp69e9tpgNmO28AeGLNKDW5HvwslwTa4fg
# VI0jYhn2xrzexXWp8GImsU42hhEfeFiDmeRT94qjHZfY637shA3MxVEm83vwMfMF
# mKwBwEqFAZJc/Yt6E02azBi6Z9HGCLa6Lc2IlXp7uyeV0Xf2vAqCPlLfEx/Sfoyo
# JZd3+lk=
# SIG # End signature block
