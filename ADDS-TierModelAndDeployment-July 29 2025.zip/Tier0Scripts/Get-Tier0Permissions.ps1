﻿# Written by Kip Gumenberg, Microsoft Security Enterprise Services, February 2024
############
### Init ###
############
param (
    $DomainName,
    $ResultSetSize,
    [switch]$Debug, 
    [switch]$IncludeNestedPermissions,
    [switch]$DistDataFolder,
    [switch]$IncludeAllServers,
    [switch]$SkipConfigAndSchema,
    [switch]$ExcludeConfigAndSchemaGroupExpansion
)

if ($DistDataFolder.IsPresent -eq $false) {
    Write-Host "Syntax: .\Get-Tier0Permissions.ps1 -DistDataFolder [-ResultSetSize 100] [-IncludeNestedPermissions] [-Debug] [-IncludeAllServers] [-SkipConfigAndSchema] [-ExcludeConfigAndSchemaGroupExpansion]"
    write-Host
    Write-Host "I.e.:   .\Get-Tier0Permissions.ps1 -DistDataFolder"
    exit
}

import-module ActiveDirectory
Add-Type -AssemblyName System.DirectoryServices
$DebugFlag=$False


if ($DomainName -eq $null)
{
    $CollectionMode = "Forest"
} else {
    $CollectionMode = "Domain"
}

$FileTime = get-date -format "MM-dd-yyyy-HH-mm"
$ScriptRoot = $PSScriptRoot
$CurFolder = $PSScriptRoot + "\Reports"
$StartTime = Get-Date
$ADDriveNumber=1
$DistDataPath = $ScriptRoot + "\DistData"
$RootDSE = Get-ADRootDSE -ErrorAction SilentlyContinue
$RootDomain = $RootDSE.rootDomainNamingContext
$ConfigPartition = $RootDSE.configurationNamingContext
$DefaultNamingContext = $RootDSE.defaultNamingContext
$SchemaPartition = $RootDSE.schemaNamingContext



###################
### Hash Tables ###
###################
$dicPreferredDCs = @{}                   # Key = Domain DNS Name,                                             Item = Preferred Domain Controller FQDN
$dicGroupObjects = @{}                   # Key = Group Distinguished Name,                                    Item = Group Object
$dicGroupMembers = @{}                   # Key = Member Distinguished Name,                                   Item = Group Member Object
$dicADObjects = @{}                      # Key = Object Distinguished Name,                                   Item = AD Object
$dicDomainSIDs = @{}                     # Key = Domain SID,                                                  Item = Domain Controller FQDN
$dicTier0RIDs = @{}                      # Key = Group RID,                                                   Item = Group Name
$dicDomainFQDN = @{}                     # Key = Domain FQDN,                                                 Item = Domain LDAP
$dicDomainLDAP = @{}                     # Key = Target Authority,                                            Item = Domain LDAP
$dicDcDistinguishedName = @{}            # Key = Domain Controller FQDN,                                      Item = Domain Controller Container
$dicDcFQDN = @{}                         # Key = Domain Controller FQDN,                                      Item = Domain Controller Short Name
$dicTier0Containers = @{}                # Key = Container LDAP,                                              Item = "container"
$dicTier0DistinguishedNames = @{}        # Key = Tier 0 Object Distinguished Name,                            Item = Object Class
$dicTier0Owners = @{}                    # Key = Tier 0 Object Distinguished Name,                            Item = Owner Name
$dicTier0SIDs = @{}                      # Key = Tier 0 Member SID,                                           Item = Tier 0 Member RID
$dicTier0IdentitiesBySID = @{}           # Key = Member SID,                                                  Item = SamAccountName
$dicDomainDC = @{}                       # Key = Domain FQDN,                                                 Item = Target DC FQDN
$dicDomainNetBIOSNameByDomain = @{}      # Key = Domain FQDN,                                                 Item = Domain NETBIOS Name
$dicDomainNetBIOSNameByNetBIOSName = @{} # Key = Domain NETBIOS Name,                                         Item = Target DC FQDN
$dicADDriveMapping = @{}                 # Key = Domain FQDN,                                                 Item = AD Drive Number
$dicTrustByFQDN = @{}                    # Key = Trust Domain FQDN,                                           Item = Trust DC FQDN
$dicTrustBySID = @{}                     # Key = Trust Domain SID,                                            Item = Trust Domain FQDN
$dictmpDCs = @{}                         # Key = Domain FQDN,                                                 Item = Target DC FQDN
$dicAvoidTrust = @{}                     # Key = Trust Domain DNS Name OR Trust Domain Controller DNS Name,   Item = <Not Used>
$dicMemberServerDN = @{}                 # Key = Member Server Distinguished Name,                            Item = Member Server FQDN
$dicMemberServerFQDN = @{}               # Key = Member Server FQDN,                                          Item = Member Server Distinguished Name
$dicMemberServerApplication = @{}        # Key = Member Server Distinguished Name,                            Item = Member Server Application
$dicMemberServerRole = @{}               # Key = Member Server Distinguished Name,                            Item = Member Server Role
$dicMemberDNs = @{}                      # Key = Member Distinguished Name,                                   Item = <Not Used>
$dicMemberState = @{}                    # Key = Member Distinguished Name,                                   Item = Member State
$dicMemberUAC = @{}                      # Key = Member Distinguished Name,                                   Item = Member User Account Control
$dicExcludedGroups = @{}                 # Key = Group SID                                                    Item = Group Name
$dicOutputDNs = @{}                      # Key = Display Key,                                                 Item = <Not Used>                    
$schemaIDGUID = @{}                      # Key = Object GUID,                                                 Item = Object Type Name
$dicIdentityDN = @{}                     # Key = Identity Reference,                                          Item = Object DistinguishedName
$dicIdentityObjectClass = @{}            # Key = Identity Reference,                                          Item = Object Class
$dicIdentitySID = @{}                    # Key = Identity Reference,                                          Item = Object SID
$dicTempDomainLDAP = @{}                 # Key = Target Authority,                                            Item = Domain LDAP
$dicTargetContainers = @{}               # Key = Container Distinguished Name,                                Item = <Not Used>
$dicTier0GPOs = @{}                      # Key = Object Distinguished Name,                                   Item = Container Distinguished Name
$dicGPOName = @{}                        # Key = GPO Distinguished Name,                                      Item = GPO Display Name
$dicGPOWhenChanged = @{}                 # Key = GPO Distinguished Name,                                      Item = GPO When Changed Date
$dicGPOWhenCreated = @{}                 # Key = GPO Distinguished Name,                                      Item = GPO When Created Date
$dicIdentitiesNotFound = @{}             # Key = Identity Reference,                                          Item = <Not Used>
$dicIndirectGroups = @{}                 # Key = Group Distinguished Name,                                    Item = <Not Used>
$dicIsTier0CustomGroup = @{}             # Key = Group Distinguished Name,                                    Item = True or False


########################
### Global Variables ###
########################
$Global:ObjectCount = 0
$Global:FileSizeThreshold = 1000000
$Global:FileFragmentCount = 0
$Global:FragmentFilename = ""


###################
### Input Files ###
###################
$PreferredDomainControllersFile = $ScriptRoot + "\PreferredDomainControllers.CSV"
$LocalGroupFiles = gci $DistDataPath\LocalGroupMembership-*.CSV
$RegistryFiles = gci $DistDataPath\RegistryPermissions-*.CSV
$ShareFiles = gci $DistDataPath\SharePermissions-*.CSV
$ServiceFiles = gci $DistDataPath\Services-*.CSV
$ScheduledTaskFiles = gci $DistDataPath\ScheduledTasks-*.CSV
$InstalledSoftwareFiles = gci $DistDataPath\InstalledSoftware-*.CSV
$WindowsFeaturesFiles = gci $DistDataPath\WindowsFeatures-*.CSV
$HotfixFiles = gci $DistDataPath\Hotfixes-*.CSV
$LocalUserFiles = gci $DistDataPath\LocalUsers-*.CSV
$OSInfoFiles = gci $DistDataPath\OSInfo-*.CSV
$DCRegistryFiles = gci $DistDataPath\DCRegistryValues-*.CSV
$CredGuardFiles = gci $DistDataPath\CredentialGuardStatus-*.CSV

$DCInfoFile = gci $CurFolder\DCINFO*.csv | sort LastWriteTime | select -last 1
$Tier0GroupsFile = gci $CurFolder\Tier0GroupMembership*.CSV | sort LastWriteTime | select -last 1
$Tier0URAFile = gci $CurFolder\Tier0UserRightsAssignments*.CSV | sort LastWriteTime | select -last 1

$Tier0MemberServerFile = $ScriptRoot + "\" + "Tier0MemberServers.CSV"
$LocalGroupSIDsToFilterOutFile = $ScriptRoot + "\" + "LocalGroupSIDsToFilterOut.CSV"
$Tier0GroupRIDsFile = $ScriptRoot + "\" + "Tier0GroupRIDs.CSV"
$Tier0GroupsDNsFile = $CurFolder + "\" + "Tier0GroupDistinguishedNames.CSV"
$Tier0CustomGroupsFile = $ScriptRoot + "\" + "Tier0CustomGroups.CSV"


####################
### Output Files ###
####################
$LogFile = $CurFolder + "\" + "Get-Tier0Permissions-$FileTime.LOG"
$Tier0MemberServerGroupMembershipFile = $CurFolder + "\" + "Tier0MemberServerGroupMembership-$FileTime.CSV"
$AllServerGroupMembershipFile = $CurFolder + "\" + "AllServerGroupMembership-$FileTime.CSV"
$Tier0SecurityPrincipalPermissionsFile = $CurFolder + "\" + "Tier0SecurityPrincipalPermissions-$FileTime.CSV"
$Tier0ContainerPermissionsFile = $CurFolder + "\" + "Tier0ContainerPermissions-$FileTime.CSV"
$Tier0DomainRootPermissionsFile = $CurFolder + "\" + "Tier0DomainRootPermissions-$FileTime.CSV"
$Tier0AdminSDHolderPermissionsFile = $CurFolder + "\" + "Tier0AdminSDHolderPermissions-$FileTime.CSV"
$Tier0ConfigurationNCPermissionsFile = $CurFolder + "\" + "Tier0ConfigurationNCPermissions-$FileTime.CSV"
$Tier0DistinguishedNamesFile = $CurFolder + "\" + "Tier0DistinguishedNames-$FileTime.CSV"
$Tier0ContainerDistinguishedNamesFile = $CurFolder + "\" + "Tier0Containers-$FileTime.CSV"
$Tier0SchemaNCPermissionsFile = $CurFolder + "\" + "Tier0SchemaNCPermissions-$FileTime.CSV"
$Tier0GPOsFile = $CurFolder + "\" + "Tier0GPOs-$FileTime.CSV"
$Tier0GPOPermissionsFile = $CurFolder + "\" + "Tier0GPOPermissions-$FileTime.CSV"
$NonTier0AdminCountFile = $CurFolder + "\" + "NonTier0AdminCount-$FileTime.CSV"
$Tier0SIDHistoryFile = $CurFolder + "\" + "Tier0SIDHistory-$FileTime.CSV"
$Tier0RegistryAccessFile = $CurFolder + "\" + "Tier0RegistryAccess-$FileTime.CSV"
$Tier0ShareFile = $CurFolder + "\" + "Tier0ShareAccess-$FileTime.CSV"
$Tier0TrustFile = $CurFolder + "\" + "Tier0TrustRelationships-$FileTime.CSV"
$Tier0ServicesFile = $CurFolder + "\" + "Tier0Services-$FileTime.CSV"
$Tier0ScheduledTasksFile = $CurFolder + "\" + "Tier0ScheduledTasks-$FileTime.CSV"
$Tier0InstalledSoftwareFile = $CurFolder + "\" + "Tier0InstalledSoftware-$FileTime.CSV"
$Tier0WindowsFeaturesFile = $CurFolder + "\" + "Tier0WindowsFeatures-$FileTime.CSV"
$AccountDispositionFile = $CurFolder + "\" + "Account Disposition-$FileTime.CSV"
$IndirectGroupsFilename = $CurFolder + "\" + "Tier0IndirectGroups-$FileTime.CSV"
$Tier0HotfixFilename = $CurFolder + "\" + "Tier0Hotfixes-$FileTime.CSV"
$Tier0LocalUsersFilename = $CurFolder + "\" + "Tier0LocalUsers-$FileTime.CSV"
$CertificateTemplateFilename = $CurFolder + "\" + "CertificateTemplates-$FileTime.CSV"
$Tier0OSInfoFilename = $CurFolder + "\" + "Tier0OSInfo-$FileTime.CSV"
$DCRegistryFilename = $CurFolder + "\" + "DomainControllerRegistryValues-$FileTime.CSV"
$ForestUsersFilename = $CurFolder + "\" + "ForestUsersAndComputers-$FileTime.CSV"
$SpecialGroupsFilename = $CurFolder + "\" + "SpecialGroups-$FileTime.CSV"
$DomainInformationFilename = $CurFolder + "\" + "DomainInformation-$FileTime.CSV"
$BackupStatusFilename = $CurFolder + "\" + "BackupStatus-$FileTime.CSV"
$ForestInformationFilename = $CurFolder + "\" + "ForestInformation-$FileTime.CSV"
$PartitionsFilename = $CurFolder + "\" + "Partitions-$FileTime.CSV"
$DNSZonesFilename = $CurFolder + "\" + "DNSZones-$FileTime.CSV"
$CredGuardFilename = $CurFolder + "\" + "Tier0CredentialGuardStatus-$FileTime.CSV"


if ($Debug.IsPresent -eq $true) {
    $DebugFlag="on"
}
if ($IncludeNestedPermissions.IsPresent -eq $true) {
    $IncludeNested=$True
} else {
    $IncludeNested=$false
}

$LineOut = '"Tier0DistinguishedNames"'
Set-Content -Path $Tier0DistinguishedNamesFile -Value $LineOut -Encoding Unicode

$LineOut = '"Tier0Containers"'
Set-Content -Path $Tier0ContainerDistinguishedNamesFile -Value $LineOut -Encoding Unicode

$LineOut = '"Tier0GPOs",'`
         + '"GPOName",'`
         + '"WhenChanged",'`
         + '"WhenCreated",'`
         + '"LinkedTo"'

Set-Content -Path $Tier0GPOsFile -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"ServerDistinguishedName",'`
            + '"ServerContainer",'`
            + '"LocalGroupName",'`
            + '"LocalGroupSID",'`
            + '"MemberName",'`
            + '"MemberSamAccountName",'`
            + '"MemberDomain",'`
            + '"MemberObjectClass",'`
            + '"MemberDistinguishedName",'`
            + '"MemberSID",'`
            + '"MemberContainer",'`
            + '"MemberState",'`
            + '"MemberUserAccountControl",'`
            + '"MembershipType",'`
            + '"ServerApplication",'`
            + '"ServerRole"'

Set-Content -Path $Tier0MemberServerGroupMembershipFile -Value $LineOut -Encoding Unicode

Set-Content -Path $AllServerGroupMembershipFile -Value $LineOut -Encoding Unicode

$LineOut = '"Tier0DistinguishedName",'`
            + '"AccessRulesProtected",'`
            + '"ObjectTypeName",'`
            + '"InheritedObjectTypeName",'`
            + '"ActiveDirectoryRights",'`
            + '"InheritanceType",'`
            + '"ObjectTypeGUID",'`
            + '"InheritedObjectTypeGUID",'`
            + '"ObjectFlags",'`
            + '"AccessControlType",'`
            + '"IdentityReference",'`
            + '"IdentityObjectClass",'`
            + '"IdentityDistinguishedName",'`
            + '"IdentityContainer",'`
            + '"IdentityDomainFQDN",'`
            + '"IdentityType",'`
            + '"IsInherited",'`
            + '"InheritanceFlags",'`
            + '"PropagationFlags",'`
            + '"OwnerIdentityReference",'`
            + '"OwnerDistinguishedName",'`
            + '"OwnerObjectClass",'`
            + '"OwnerDomainFQDN",'`
            + '"Reason"'

Set-Content -Path $Tier0SecurityPrincipalPermissionsFile -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0ContainerPermissionsFile -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0DomainRootPermissionsFile -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0AdminSDHolderPermissionsFile -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0ConfigurationNCPermissionsFile -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0SchemaNCPermissionsFile -Value $LineOut -Encoding Unicode

$LineOut = '"Tier0DistinguishedName",'`
            + '"AccessRulesProtected",'`
            + '"ObjectTypeName",'`
            + '"InheritedObjectTypeName",'`
            + '"ActiveDirectoryRights",'`
            + '"InheritanceType",'`
            + '"ObjectTypeGUID",'`
            + '"InheritedObjectTypeGUID",'`
            + '"ObjectFlags",'`
            + '"AccessControlType",'`
            + '"IdentityReference",'`
            + '"IdentityObjectClass",'`
            + '"IdentityDistinguishedName",'`
            + '"IdentityContainer",'`
            + '"IdentityDomainFQDN",'`
            + '"IdentityType",'`
            + '"IsInherited",'`
            + '"InheritanceFlags",'`
            + '"PropagationFlags",'`
            + '"OwnerIdentityReference",'`
            + '"OwnerDistinguishedName",'`
            + '"OwnerObjectClass",'`
            + '"OwnerDomainFQDN",'`
            + '"Reason",'`
            + '"GPOName",'`
            + '"WhenChanged",'`
            + '"WhenCreated",'`
            + '"LinkedTo"'


Set-Content -Path $Tier0GPOPermissionsFile -Value $LineOut -Encoding Unicode

$LineOut = '"DistinguisheName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"AdminCount",'`
            + '"LastLogonTimestamp",'`
            + '"PwdLastSet",'`
            + '"ObjectSID",'`
            + '"Reason"'

Set-Content -Path $NonTier0AdminCountFile -Value $LineOut -Encoding Unicode

$LineOut = '"DistinguisheName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"SIDHistory",'`
            + '"LastLogonTimestamp",'`
            + '"PwdLastSet",'`
            + '"RIDFound",'`
            + '"Tier0Object",'`
            + '"Reason"'

Set-Content -Path $Tier0SIDHistoryFile -Value $LineOut -Encoding Unicode


$LineOut = '"ServerFQDN",'`
            + '"Name",'`
            + '"SamAccountName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"DistinguishedName",'`
            + '"RegistryLocation",'`
            + '"Access",'`
            + '"AccessType",'`
            + '"IsInherited",'`
            + '"Owner",'`
            + '"OwnerName",'`
            + '"OwnerDistinguishedName",'`
            + '"OwnerObjectClass",'`
            + '"OwnerDomainFQDN",'`
            + '"MembershipType",'`
            + '"Reason"'

Set-Content -Path $Tier0RegistryAccessFile -Value $LineOut -Encoding Unicode


$LineOut = '"ServerFQDN",'`
            + '"Name",'`
            + '"SamAccountName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"DistinguishedName",'`
            + '"ShareName",'`
            + '"Access",'`
            + '"AccessType",'`
            + '"SharePath",'`
            + '"MembershipType",'`
            + '"Reason"'

Set-Content -Path $Tier0ShareFile -Value $LineOut -Encoding Unicode

$LineOut = '"Direction",'`
            + '"DisallowTransivity",'`
            + '"DistinguishedName",'`
            + '"ForestTransitive",'`
            + '"IntraForest",'`
            + '"IsTreeParent",'`
            + '"IsTreeRoot",'`
            + '"ObjectClass",'`
            + '"ObjectGUID",'`
            + '"SelectiveAuthentication",'`
            + '"SIDFilteringForestAware",'`
            + '"SIDFilteringQuarantined",'`
            + '"Source",'`
            + '"Target",'`
            + '"TGTDelegation",'`
            + '"TrustAttributes",'`
            + '"TrustingPolicy",'`
            + '"TrustType",'`
            + '"UplevelOnly",'`
            + '"UsesAESKeys",'`
            + '"UsesRC4Encryption",'`
            + '"Reason",'`
            + '"WhenChanged"'

Set-Content -Path $Tier0TrustFile -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFqdn",'`
            + '"DisplayName",'`
            + '"PathName",'`
            + '"StartName",'`
            + '"ServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole",'`
            + '"StartMode",'`
            + '"State"'


Set-Content -Path $Tier0ServicesFile -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFqdn",'`
            + '"TaskName",'`
            + '"Principal",'`
            + '"ServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole"'

Set-Content -Path $Tier0ScheduledTasksFile -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"DisplayName",'`
            + '"DisplayVersion",'`
            + '"Publisher",'`
            + '"InstallDate",'`
            + '"ServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole"'

Set-Content -Path $Tier0InstalledSoftwareFile -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"Name",'`
            + '"DisplayName",'`
            + '"Description",'`
            + '"Installed",'`
            + '"InstalledState",'`
            + '"Type",'`
            + '"Path",'`
            + '"Depth",'`
            + '"DependsOn",'`
            + '"Parent",'`
            + '"ServerComponentDescriptor",'`
            + '"SubFeatures",'`
            + '"SystemService",'`
            + '"Notification",'`
            + '"BestPracticesNodeId",'`
            + '"EventQuery",'`
            + '"PostConfigurationNeeded",'`
            + '"MajorVersion",'`
            + '"MinorVersion",'`
            + '"NumericId",'`
            + '"InstallName",'`
            + '"ServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole"'


Set-Content -Path $Tier0WindowsFeaturesFile -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"Description",'`
            + '"HotFixID",'`
            + '"InstalledBy",'`
            + '"InstalledOn",'`
            + '"OperatingSystem",'`
            + '"ServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole"'


Set-Content -Path $Tier0HotfixFilename -Value $LineOut -Encoding Unicode


$LineOut = '"ServerFQDN",'`
            + '"ServerApplication",'`
            + '"ServerRole",'`
            + '"ServerDistinguishedName",'`
            + '"UserName",'`
            + '"PasswordLastSet",'`
            + '"LastLogon",'`
            + '"AccountCreated",'`
            + '"UserSID",'`
            + '"Enabled",'`
            + '"Description",'`
            + '"FullName",'`
            + '"PrincipalSource"'


Set-Content -Path $Tier0LocalUsersFilename -Value $LineOut -Encoding Unicode




$LineOut = '"DistinguishedName",'`
            + '"Container",'`
            + '"SamAccountName",'`
            + '"Name",'`
            + '"ObjectClass",'`
            + '"Domain",'`
            + '"UserAccountControl",'`
            + '"Enabled",'`
            + '"PwdLastSet",'`
            + '"LastLogonTimestamp",'`
            + '"GivenName",'`
            + '"Surname",'`
            + '"Title",'`
            + '"Department",'`
            + '"Description",'`
            + '"Mail",'`
            + '"info",'`
            + '"Company",'`
            + '"ManagerDN",'`
            + '"ManagerDisplayName",'`
            + '"ManagerGivenName",'`
            + '"ManagerSamAccountName",'`
            + '"ManagerName",'`
            + '"OwnerDN",'`
            + '"OwnerDisplayName",'`
            + '"OwnerGivenName",'`
            + '"OwnerSamAccountName",'`
            + '"OwnerName",'`
            + '"EmployeeID",'`
            + '"EmployeeNumber",'`
            + '"UserPrincipalName",'`
            + '"ServicePrincipalName",'`
            + '"AccountSensitiveAndCannotBeDelegated",'`
            + '"SmartCardRequired",'`
            + '"PasswordNeverExpires",'`
            + '"CannotChangePassword",'`
            + '"StorePasswordWithReversibleEncryption",'`
            + '"DoNotRequireKerberosPreauthentication",'`
            + '"AdminCount",'`
            + '"ObjectSID",'`
            + '"RID",'`
            + '"msDSSupportedEncryptionTypes",'`
            + '"IsTier0CustomGroup",'`

Set-Content -Path $AccountDispositionFile -Value $LineOut -Encoding Unicode

$LineOut = '"DistinguishedName",'`
            + '"MemberName",'`
            + '"MemberSamAccountName",'`
            + '"MemberDomainFQDN",'`
            + '"MemberObjectClass",'`
            + '"MemberDistinguishedName",'`
            + '"MemberSID",'`
            + '"MemberIdentityType",'`
            + '"MemberState"'

Set-Content -Path $IndirectGroupsFilename -Value $LineOut -Encoding Unicode

$LineOut = '"CertificateTemplateName",'`
            + '"CanSupplySubjectName",'`
            + '"CAIssuedBy",'`
            + '"CAIssuedByDNS",'`
            + '"IdentityReference",'`
            + '"ActiveDirectoryRights",'`
            + '"msPKICertificateApplicationPolicy"'

Set-Content -Path $CertificateTemplateFilename -Value $LineOut -Encoding Unicode


$LineOut = '"ServerFQDN",'`
            + '"OperatingSystem",'`
            + '"Name",'`
            + '"Value",'`
            + '"MemberServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole"'

Set-Content -Path $Tier0OSInfoFilename -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"OperatingSystem",'`
            + '"Name",'`
            + '"Value",'`
            + '"MemberServerDistinguishedName",'`
            + '"ServerApplication",'`
            + '"ServerRole"'

Set-Content -Path $DCRegistryFilename -Value $LineOut -Encoding Unicode

$LineOut = '"DomainFQDN",'`
            + '"SamAccountName",'`
            + '"Name",'`
            + '"UserAccountControl",'`
            + '"UACBinary",'`
            + '"LastLogonTimestamp",'`
            + '"msDSSupportedEncryptionTypes",'`
            + '"ObjectClass",'`
            + '"ServicePrincipalName",'`
            + '"msDS-AllowedToDelegateTo",'`
            + '"PrimaryGroup",'`
            + '"PwdLastSet",'`
            + '"WhenCreated",'`
            + '"WhenChanged",'`
            + '"OperatingSystem",'`
            + '"msDSSupportedEncryptionTypesBinary"'

Set-Content -Path $ForestUsersFilename -Value $LineOut -Encoding Unicode

$LineOut = '"DistinguishedName",'`
            + '"MemberName",'`
            + '"MemberSamAccountName",'`
            + '"MemberDomainFQDN",'`
            + '"MemberObjectClass",'`
            + '"MemberDistinguishedName",'`
            + '"MemberSID",'`
            + '"MemberIdentityType",'`
            + '"MemberState"'

Set-Content -Path $SpecialGroupsFilename -Value $LineOut -Encoding Unicode

$LineOut = '"DomainFQDN",'`
            + '"msDSMachineAccountQuota"'

Set-Content -Path $DomainInformationFilename -Value $LineOut -Encoding Unicode

$LineOut = '"Partition",'`
            + '"BackupInvocationID",'`
            + '"BackupDate",'`
            + '"Version",'`
            + '"HoursSinceBackup",'`
            + '"OriginatingDC"'

Set-Content -Path $BackupStatusFilename -Value $LineOut -Encoding Unicode

$LineOut = '"Name",'`
            + '"Value"'

Set-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode

$LineOut = '"PartitionName",'`
            + '"PartitionNCName",'`
            + '"PartitionSystemFlags",'`
            + '"PartitionDNSRoot",'`
            + '"PartitionNetbiosName",'`
            + '"PartitionWhenCreated",'`
            + '"PartitionWhenChanged"'

Set-Content -Path $PartitionsFilename -Value $LineOut -Encoding Unicode

$LineOut = '"DNSContainer",'`
            + '"DNSZoneDN",'`
            + '"IdentityReference",'`
            + '"ActiveDirectoryRights"'

Set-Content -Path $DNSZonesFilename -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"CredentialGuardEnabled"'

Set-Content -Path $CredGuardFilename -Value $LineOut -Encoding Unicode


if ($DebugFlag -eq "on") {
    Set-Content -Path $LogFile -Value $LineOut -Encoding Unicode
}

#################
### Write Log ###
#################
Function WriteLog
{
    param (
        $LineIn,
        $WriteToScreen,
        $Color
    )

    $CurTime =  get-date -UFormat "%m/%d/%Y %T"
    $LineOut = "$CurTime $LineIn"

    if ($WriteToScreen -eq $true)
    {
        if ($Color)
        {
            write-host $LineIn -ForegroundColor $Color
        } else {
            write-host $LineIn
        }
    }
    if ($DebugFlag -eq "on") {
        Add-Content -Path $LogFile -Value $LineOut -Encoding Unicode
    }
}


#################################
### Escape Special Characters ###
#################################
Function EscapeSpecialCharacters
{
    param ($TargetDN)
    $TargetDN = $TargetDN -replace "'", "''"
    return $TargetDN

}

####################################################
### Determine If Preferred DCs Have Been Defined ###
####################################################
Function DetermineIfPreferredDCsHaveBeenDefined
{
    WriteLog ""
    WriteLog "####################################################"
    WriteLog "### Determine If Preferred DCs Have Been Defined ###"
    WriteLog "####################################################"

    WriteLog "Checking for entries in $PreferredDomainControllersFile" $true
    $CSV = Import-Csv $PreferredDomainControllersFile
    foreach ($Row in $CSV)
    {    
        $DomainControllerFQDN = $Row.PreferredDomainControllerFQDN

        $Index = $DomainControllerFQDN.IndexOf(".")
        $Length = $DomainControllerFQDN.Length

        $DCDomain = $DomainControllerFQDN.Substring($Index+1,$Length-($Index+1))
        if ($dicPreferredDCs.ContainsKey($DCDomain) -eq $false)
        {
            $dicPreferredDCs.Add($DCDomain,$DomainControllerFQDN)
        }

        WriteLog "Preferred Domain Controller for $DCDomain found: $DomainControllerFQDN" $true Green
    }
    $PrefDCCount = $dicPreferredDCs.Count
    WriteLog "Number of Preferred Domain Controllers Found: $PrefDCCount" $true

}

######################
### Get Closest DC ###
######################
Function GetClosestDC
{
    param 
    (
        $TargetDomain
    )
    writeLog ""
    WriteLog "######################"
    WriteLog "### Get Closest DC ###"
    WriteLog "######################"
    WriteLog "GetClosestDC: $TargetDomain"

    if ($dicPreferredDCs.ContainsKey($TargetDomain) -eq $true)
    {
        $ClosestDC = $dicPreferredDCs.$TargetDomain
        WriteLog "Using preffered DC: $ClosestDC"
        if ($dicDomainDC.ContainsKey($TargetDomain) -eq $false)
        {
            $dicDomainDC.add($TargetDomain,$ClosestDC)
        }
    } else {
        if ($dicDomainDC.ContainsKey($TargetDomain) -eq $true)
        {
            $ClosestDC = $dicDomainDC.$TargetDomain
            WriteLog "Using cached DC $ClosestDC for Domain: $TargetDomain" 
       
        } else {
        
            WriteLog "Discovering Domain Controller for domain: $TargetDomain"
            $DCObj = Get-ADDomainController -Discover -Domain $TargetDomain -ErrorAction SilentlyContinue
            if ($DCObj)
            {
                $ClosestDC = [string]$DCObj.HostName
                $dicDomainDC.Add($TargetDomain,$ClosestDC)
                WriteLog "Using discovered DC: $ClosestDC"
            } else {
                WriteLog "The following error occured trying to discover a DC in $TargetDomain : $Error"
            }
        }
    }
    WriteLog ""

    return $ClosestDC
}

###################################
### Read Tier 0 Group RIDs File ###
###################################
Function ReadTier0GroupRIDsFile
{
    WriteLog "Reading $Tier0GroupRIDsFile." $true
    $CSV = Import-Csv $Tier0GroupRIDsFile
    
    foreach ($Row in $CSV)
    {
        $RID = $Row.RID
        $GroupName = $Row.GroupName

        if ($dicTier0RIDs.ContainsKey($RID) -eq $false)
        {
            $dicTier0RIDs.Add($RID,$GroupName)
        }
    }
}




###########################
### Get Nested Members2 ###
###########################
Function GetNestedMembers2
{
    param (
        $TargetGroupDistinguishedName, 
        $TargetFilename,
        $OrigServerFqdn,
        $OrigMemberServerDistinguishedName,
        $OrigMemberServerContainer,
        $OrigLocalGroupName,
        $OrigLocalGroupSID
    )

    $Index = $TargetGroupDistinguishedName.IndexOf("DC=")
    $Length = $TargetGroupDistinguishedName.Length + 1
    $AppliedLength = $Length - ($Index+1)
    $TargetDomainDN = $TargetGroupDistinguishedName.Substring($Index,$AppliedLength)

    $MemberServerApplication = $dicMemberServerApplication.$OrigMemberServerDistinguishedName
    $MemberServerRole = $dicMemberServerRole.$OrigMemberServerDistinguishedName

    #$dicDomainDC = @{}

    $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
    $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""

    $Index = $TargetGroupDistinguishedName.IndexOf(",OU=")
    if ($Index -eq -1) {$Index = $TargetGroupDistinguishedName.IndexOf(",CN=")}
    if ($Index -eq -1) {$Index = $TargetGroupDistinguishedName.IndexOf(",DC=")}

    $Length = $TargetGroupDistinguishedName.Length
    $AppliedLength = $Length - ($Index + 1)
    $TargetContainer = $TargetGroupDistinguishedName.Substring($Index+1,$AppliedLength)
        
    if ($dicDomainDC.ContainsKey($TargetDomainDN) -eq $true) {
        $TargetDC = $dicDomainDC.$TargetDomainDN
    } else {
        $TargetDC = GetClosestDC $TargetDomainFQDN
    }
    $TargetGroupDistinguishedName2 = EscapeSpecialCharacters $TargetGroupDistinguishedName
    if ($dicGroupObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $false)
    {
        if ($dicADObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $true)
        {
            $Group = $dicADObjects.$TargetGroupDistinguishedName2
        } else {
            try
            {
                $Group = Get-adobject -Filter "DistinguishedName -eq '$TargetGroupDistinguishedName2'" -Server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
            } catch {
                WriteLog "Group: $TargetSID not found on TargetDC: $TargetDC"
            }
        }

        WriteLog ""
        WriteLog "########################"
        WriteLog "### GetNestedMembers ###"
        WriteLog "########################"
        WriteLog "TargetGroupDistinguishedName: $TargetGroupDistinguishedName"
        WriteLog "OrigGroupSamAccountName: $OrigGroupSamAccountName"
        WriteLog "OrigGroupDisplayName: $OrigGroupDisplayName"
        WriteLog "OrigGroupDomain: $OrigGroupDomain"
        WriteLog "OrigGroupScope: $OrigGroupScope"
        WriteLog "OrigGroupSID: $OrigGroupSID"
        WriteLog "OrigGroupDistinguishedName: $OrigGroupDistinguishedName"
        WriteLog "OrigGroupContainer: $OrigGroupContainer"

        If ($Group) 
        {
            if ($dicADObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $false)
            {
                $dicADObjects.add($TargetGroupDistinguishedName2,$Group)
            }
            if ($dicGroupObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $false)
            {
                $dicGroupObjects.add($TargetGroupDistinguishedName2,$Group)
            }

            $GroupSamAccountName = $Group.SamAccountName
            $GroupDisplayName = $Group.Name
            $GroupDomain = $DomainFQDN
            $GroupType = $Group.GroupType
            $GroupSID = $Group.ObjectSID
            $GroupMemberDNs = $Group.Member
            $GroupDistinguishedName = $Group.DistinguishedName
            $Index = $GroupDistinguishedName.IndexOf(",")
            $Length = $GroupDistinguishedName.Length
            $AppliedLength = $Length - ($Index + 1)
            $GroupContainer = $GroupDistinguishedName.Substring($Index+1,$AppliedLength)

            $IsDomainLocal = ($GroupType -band 4) -ne 0
            $IsGlobal = ($GroupType -band 2) -ne 0
            $IsUniversal = ($GroupType -band 8) -ne 0
            $IsSecurity = ($GroupType -band 0x80000000) -ne 0

            if ($IsDomainLocal -eq $true) {$GroupScope = "DomainLocal"}
            if ($IsGlobal -eq $true) {$GroupScope = "Global"}
            if ($IsUniversal -eq $true) {$GroupScope = "Universal"}

            WriteLog ""
            WriteLog "GroupSamAccountName: $GroupSamAccountName"
            WriteLog "GroupDisplayName: $GroupDisplayName"
            WriteLog "GroupDomain: $GroupDomain"
            WriteLog "GroupType: $GroupType"
            WriteLog "IsDomainLocal: $IsDomainLocal"
            WriteLog "IsGlobal: $IsGlobal"
            WriteLog "IsUniversal: $IsUniversal"
            WriteLog "GroupScope: $GroupScope"
            WriteLog "GroupSID: $GroupSID"
            WriteLog "GroupDistinguishedName: $GroupDistinguishedName"
            WriteLog "GroupContainer: $GroupContainer"


            foreach ($MemberDN in $GroupMemberDNs) 
            {

                WriteLog "MemberDN: $MemberDN"

                $MemberDistinguishedName = $MemberDN

                $Index = $MemberDistinguishedName.IndexOf("DC=")
                $Length = $MemberDistinguishedName.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                $Index = $MemberDistinguishedName.IndexOf(",OU=")
                if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
                if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

                $Length = $MemberDistinguishedName.Length
                $AppliedLength = $Length - ($Index + 1)
                $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)
        
                if ($dicDomainDC.ContainsKey($MemberDomainFQDN) -eq $true) {
                    $MemberTargetDC = $dicDomainDC.$MemberDomainFQDN
                } else {
                    $MemberTargetDC = GetClosestDC $MemberDomainFQDN
                }

                $MemberDistinguishedName2 = EscapeSpecialCharacters $MemberDistinguishedName
                if ($dicMemberDNs.ContainsKey($MemberDistinguishedName2) -eq $false) 
                {
                    $dicMemberDNs.Add($MemberDistinguishedName2,"")

                    if ($dicGroupMembers.ContainsKey($MemberDistinguishedName2) -eq $false)
                    {
                        if ($dicADObjects.ContainsKey($MemberDistinguishedName2) -eq $true)
                        {
                            $Member = $dicADObjects.$MemberDistinguishedName2
                        } else {
                            Try
                            {
                                $Member = Get-adobject -Filter "DistinguishedName -eq '$MemberDistinguishedName2'" -Server $MemberTargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                            } Catch {
                                WriteLog "Ref2 - Could not find: $MemberDistinguishedName"
                            }
                        }
                    } else {
                        $Member = $dicGroupMembers.$MemberDistinguishedName2    
                    }

                    if ($Member)
                    {
                        if ($dicADObjects.ContainsKey($MemberDistinguishedName2) -eq $false)
                        {
                            $dicADObjects.Add($MemberDistinguishedName2,$Member)
                        }
                        if ($dicGroupMembers.ContainsKey($MemberDistinguishedName2) -eq $false)
                        {
                            $dicGroupMembers.add($MemberDistinguishedName2,$Member)
                        }
                        $MemberDisplayName = $Member.name
                        $MemberSID = [string]$Member.ObjectSID
                        $MemberSamAccountName = $Member.SamAccountName
                        $MemberObjectClass = $Member.objectClass

                        if ($MemberObjectClass -eq "user" -or $MemberObjectClass -eq "computer" -or $MemberObjectClass -eq "msDS-GroupManagedServiceAccount") {
                            $MemberUserAccountControl = $Member.UserAccountControl
                            if (($MemberUserAccountControl -band 2) -ne 2) {
                                $MemberState = "Enabled"
                            } else {
                                $MemberState = "Disabled"
                            }
                        } else {
                            $MemberState = ""
                            $MemberUserAccountControl = ""
                        }
                        if ($dicMemberState.ContainsKey($MemberDistinguishedName) -eq $false)
                        {
                            $dicMemberState.Add($MemberDistinguishedName,$MemberState)
                        }
                        if ($dicMemberUAC.ContainsKey($MemberDistinguishedName) -eq $false)
                        {
                            $dicMemberUAC.Add($MemberDistinguishedName,$MemberUserAccountControl)
                        }

                        WriteLog ""
                        WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                        WriteLog "MemberDisplayName: $MemberDisplayName"
                        WriteLog "MemberSID: $MemberSID"
                        WriteLog "MemberSamAccountName: $MemberSamAccountName"
                        WriteLog "MemberObjectClass: $MemberObjectClass"
                        WriteLog "MemberDomainDN: $MemberDomainDN"
                        WriteLog "MemberDomainFQDN: $MemberDomainFQDN"
                        WriteLog "MemberTargetDC: $MemberTargetDC"
                        WriteLog "MemberContainer: $MemberContainer"
                        WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                        WriteLog "MemberState: $MemberState"
                        WriteLog "MemberMemberShipType: Explicit"

                        $LineOut = '"' + $OrigServerFqdn + '",'`
                                    + '"' + $OrigMemberServerDistinguishedName  + '",'`
                                    + '"' + $OrigMemberServerContainer  + '",'`
                                    + '"' + $OrigLocalGroupName  + '",'`
                                    + '"' + $OrigLocalGroupSID  + '",'`
                                    + '"' + $MemberDisplayName  + '",'`
                                    + '"' + $MemberSamAccountName  + '",'`
                                    + '"' + $MemberDomainFQDN  + '",'`
                                    + '"' + $MemberObjectClass  + '",'`
                                    + '"' + $MemberDistinguishedName  + '",'`
                                    + '"' + $MemberSID  + '",'`
                                    + '"' + $MemberContainer  + '",'`
                                    + '"' + $MemberState  + '",'`
                                    + '"' + $MemberUserAccountControl  + '",'`
                                    + '"Nested",'`
                                    + '"' + $MemberServerApplication  + '",'`
                                    + '"' + $MemberServerRole  + '"'

                        $DisplayKey = $OrigServerFqdn + $MemberDistinguishedName + $OrigLocalGroupName
                        if ($dicOutputDNs.ContainsKey($DisplayKey) -eq $false)
                        {
                            $dicOutputDNs.add($DisplayKey,"")

                            if ($dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
                            {
                                Add-Content -Path $TargetFilename -Value $LineOut -Encoding Unicode
                            }

                            Add-Content -Path $AllServerGroupMembershipFile -Value $LineOut -Encoding Unicode

                        }
                    
                        $Index = $MemberSID.LastIndexOf("-")
                        $Length = $MemberSID.Length + 1
                        $AppliedLength = $Length - ($Index+1)
                        $MemberRID = $MemberSID.Substring($Index+1,$AppliedLength-1)

                        if ($dicTier0SIDs.ContainsKey($MemberSID) -eq $false -and $dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
                        {
                            $dicTier0SIDs.Add($MemberSID,$MemberRID)
                            $dicTier0IdentitiesBySID.Add($MemberSID,$MemberSamAccountName)
                        }

                        if ($dicTier0Containers.ContainsKey($MemberContainer) -eq $false -and $dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
                        {
                            $dicTier0Containers.Add($MemberContainer,"container")
                        }
                        if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false -and $dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
                        {
                            $dicTier0DistinguishedNames.Add($MemberDistinguishedName,$MemberObjectClass)
                        }

                        if ($MemberObjectClass -eq "group" -and $IncludeNested -eq $true)
                        {
                            GetNestedMembers2 $MemberDistinguishedName $Tier0MemberServerGroupMembershipFile $OrigServerFqdn $OrigMemberServerDistinguishedName $OrigMemberServerContainer $OrigLocalGroupName $OrigLocalGroupSID
                        }
                    }
                }
                
            }
        }
    } else {
        $Group = $dicGroupObjects.$TargetGroupDistinguishedName

        $GroupSamAccountName = $Group.SamAccountName
        $GroupDisplayName = $Group.Name
        $GroupDomain = $DomainFQDN
        $GroupType = $Group.GroupType
        $GroupSID = $Group.ObjectSID
        $GroupMemberDNs = $Group.Member
        $GroupDistinguishedName = $Group.DistinguishedName
        $Index = $GroupDistinguishedName.IndexOf(",")
        $Length = $GroupDistinguishedName.Length
        $AppliedLength = $Length - ($Index + 1)
        $GroupContainer = $GroupDistinguishedName.Substring($Index+1,$AppliedLength)

        $IsDomainLocal = ($GroupType -band 4) -ne 0
        $IsGlobal = ($GroupType -band 2) -ne 0
        $IsUniversal = ($GroupType -band 8) -ne 0
        $IsSecurity = ($GroupType -band 0x80000000) -ne 0

        if ($IsDomainLocal -eq $true) {$GroupScope = "DomainLocal"}
        if ($IsGlobal -eq $true) {$GroupScope = "Global"}
        if ($IsUniversal -eq $true) {$GroupScope = "Universal"}

        foreach ($MemberDN in $GroupMemberDNs) 
        {

            WriteLog "MemberDN: $MemberDN"

            $MemberDistinguishedName = $MemberDN

            $Index = $MemberDistinguishedName.IndexOf("DC=")
            $Length = $MemberDistinguishedName.Length + 1
            $AppliedLength = $Length - ($Index+1)
            $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

            $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
            $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

            $Index = $MemberDistinguishedName.IndexOf(",OU=")
            if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
            if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

            $Length = $MemberDistinguishedName.Length
            $AppliedLength = $Length - ($Index + 1)
            $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)
            
            if ($dicMemberDNs.ContainsKey($MemberDistinguishedName) -eq $false) 
            {
                $dicMemberDNs.Add($MemberDistinguishedName,"")

                $Member = $dicGroupMembers.$MemberDistinguishedName

                $MemberDisplayName = $Member.name
                $MemberSID = [string]$Member.ObjectSID
                $MemberSamAccountName = $Member.SamAccountName
                $MemberObjectClass = $Member.objectClass

                if ($MemberObjectClass -eq "user" -or $MemberObjectClass -eq "computer" -or $MemberObjectClass -eq "msDS-GroupManagedServiceAccount") {
                    $MemberUserAccountControl = $Member.UserAccountControl
                    if (($MemberUserAccountControl -band 2) -ne 2) {
                        $MemberState = "Enabled"
                    } else {
                        $MemberState = "Disabled"
                    }
                } else {
                    $MemberState = ""
                    $MemberUserAccountControl = ""
                }
                if ($dicMemberState.ContainsKey($MemberDistinguishedName) -eq $false)
                {
                    $dicMemberState.Add($MemberDistinguishedName,$MemberState)
                }
                if ($dicMemberUAC.ContainsKey($MemberDistinguishedName) -eq $false)
                {
                    $dicMemberUAC.Add($MemberDistinguishedName,$MemberUserAccountControl)
                }

                WriteLog ""
                WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                WriteLog "MemberDisplayName: $MemberDisplayName"
                WriteLog "MemberSID: $MemberSID"
                WriteLog "MemberSamAccountName: $MemberSamAccountName"
                WriteLog "MemberObjectClass: $MemberObjectClass"
                WriteLog "MemberDomainDN: $MemberDomainDN"
                WriteLog "MemberDomainFQDN: $MemberDomainFQDN"
                WriteLog "MemberTargetDC: $MemberTargetDC"
                WriteLog "MemberContainer: $MemberContainer"
                WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                WriteLog "MemberState: $MemberState"
                WriteLog "MemberMemberShipType: Explicit"

                $LineOut = '"' + $OrigServerFqdn + '",'`
                            + '"' + $OrigMemberServerDistinguishedName  + '",'`
                            + '"' + $OrigMemberServerContainer  + '",'`
                            + '"' + $OrigLocalGroupName  + '",'`
                            + '"' + $OrigLocalGroupSID  + '",'`
                            + '"' + $MemberDisplayName  + '",'`
                            + '"' + $MemberSamAccountName  + '",'`
                            + '"' + $MemberDomainFQDN  + '",'`
                            + '"' + $MemberObjectClass  + '",'`
                            + '"' + $MemberDistinguishedName  + '",'`
                            + '"' + $MemberSID  + '",'`
                            + '"' + $MemberContainer  + '",'`
                            + '"' + $MemberState  + '",'`
                            + '"' + $MemberUserAccountControl  + '",'`
                            + '"Nested",'`
                            + '"' + $MemberServerApplication  + '",'`
                            + '"' + $MemberServerRole  + '"'


                $DisplayKey = $OrigServerFqdn + $MemberDistinguishedName + $OrigLocalGroupName
                if ($dicOutputDNs.ContainsKey($DisplayKey) -eq $false)
                {
                    $dicOutputDNs.add($DisplayKey,"")

                    if ($dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
                    {
                        Add-Content -Path $TargetFilename -Value $LineOut -Encoding Unicode
                    }

                    Add-Content -Path $AllServerGroupMembershipFile -Value $LineOut -Encoding Unicode
                }
            }
            $Index = $MemberSID.LastIndexOf("-")
            $Length = $MemberSID.Length + 1
            $AppliedLength = $Length - ($Index+1)
            $MemberRID = $MemberSID.Substring($Index+1,$AppliedLength-1)

            if ($dicTier0SIDs.ContainsKey($MemberSID) -eq $false -and $dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
            {
                $dicTier0SIDs.Add($MemberSID,$MemberRID)
                $dicTier0IdentitiesBySID.Add($MemberSID,$MemberSamAccountName)
            }

            if ($dicTier0Containers.ContainsKey($MemberContainer) -eq $false -and $dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
            {
                $dicTier0Containers.Add($MemberContainer,"container")
            }
            if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false -and $dicMemberServerFQDN.ContainsKey($OrigServerFqdn) -eq $true)
            {
                $dicTier0DistinguishedNames.Add($MemberDistinguishedName,$MemberObjectClass)
            }

            if ($MemberObjectClass -eq "group" -and $IncludeNested -eq $true)
            {
                GetNestedMembers2 $MemberDistinguishedName $Tier0MemberServerGroupMembershipFile $OrigServerFqdn $OrigMemberServerDistinguishedName $OrigMemberServerContainer $OrigLocalGroupName $OrigLocalGroupSID
            }
        }
    }
}



##################
### Get AD ACL ###
##################
Function GetADACL
{
    param (
        $TargetDN, 
        $TargetFilename,
        $GetAllACEs,
        $TargetNC,
        $DataType
    )
    $SaveTargetNC = $TargetNC
    $NonDefaultOwner=$false

    $Global:ObjectCount = $Global:ObjectCount + 1
    Write-Host -NoNewline $("`rObjects Scanned: $Global:ObjectCount")



    if ($DebugFlag -eq $true)
    {
        write-host ""
        write-host "TargetDN: $TargetDN" -ForegroundColor Cyan
        write-host "TargetFilename: $TargetFilename" -ForegroundColor Cyan
        write-host "GetAllACEs: $GetAllACEs" -ForegroundColor Cyan
        write-host "TargetNC: $TargetNC" -ForegroundColor Cyan
        write-host "DataType: $DataType" -ForegroundColor Cyan
    }

    if ($TargetDN -eq "" -or $TargetDN -eq $null)
    {
        Return # Bail out
    }

    $Index = $TargetDN.IndexOf("DC=")
    $Length = $TargetDN.Length + 1
    $AppliedLength = $Length - ($Index+1)
    $TargetDomainDN = $TargetDN.Substring($Index,$AppliedLength)

    $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
    $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""
    $TargetDomainNetBIOSName = $dicDomainNetBIOSNameByDomain.$TargetDomainFQDN
    
    $TargetDC = $dicDomainDC.$TargetDomainFQDN
    $TargetLDAP = $dicDomainLDAP.$TargetDomainFQDN

    if ($TargetDC -eq "" -or $TargetDC -eq $null)
    {
        $TargetDC = GetClosestDC $TargetDomainFQDN
    }
    
    if ($DebugFlag -eq $true)
    {
        write-host "TargetDomainFQDN: $TargetDomainFQDN" -ForegroundColor Cyan
        write-host "TargetDC: $TargetDC" -ForegroundColor Cyan
    }
        
    $RootDSE = Get-ADRootDSE -Server $TargetDC -ErrorAction silentlyContinue
    $RootDomain = $RootDSE.rootDomainNamingContext

    $RootDomainFQDN = $RootDomain -replace ",DC=", "."
    $RootDomainFQDN = $RootDomainFQDN -replace "DC=", ""
    
    $ConfigPartition = $RootDSE.configurationNamingContext
    $DefaultNamingContext = $RootDSE.defaultNamingContext
    $SchemaPartition = $RootDSE.schemaNamingContext

    if ($TargetNC -eq $null -or $TargetNC -eq "Domain")
    {
        $TargetNC = $DefaultNamingContext
    }
    if ($TargetNC -eq "Config")
    {
        $TargetNC = $ConfigPartition
    }
    if ($TargetNC -eq "Schema")
    {
        $TargetNC = $SchemaPartition
    }
    if ($TargetDN.Contains(",CN=Configuration,DC")) 
    {
        $TargetNC=$ConfigPartition
    }
    if ($TargetDN.Contains("CN=Schema,CN=Configuration,DC")) 
    {
        $TargetNC=$SchemaPartition
    }

    if ($DebugFlag -eq $true)
    {
        write-host "TargetNC: $TargetNC" -ForegroundColor Cyan
    }


    $TargetDN2 = EscapeSpecialCharacters $TargetDN
    if ($dicADObjects.ContainsKey($TargetDN2) -eq $true)
    {
        $DoesExist = $dicADObjects.$TargetDN2
    } else {
        try 
        {
            $DoesExist = get-adobject -Searchbase "$TargetNC" -Filter "DistinguishedName -eq '$TargetDN2'" -server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
        } catch {
            WriteLog "No access to read object: $TargetDN on $TargetDC"
        }
    }

    if ($DebugFlag -eq $true)
    {
        write-host "DoesExist: $DoesExist" -ForegroundColor Cyan
    }


    if ($DoesExist)
    {
        if ($dicADObjects.ContainsKey($TargetDN2) -eq $false)
        {
            $dicADObjects.Add($TargetDN2,$DoesExist)
        }
        
        $ACL = ""
        $addriveNumber = $dicADDriveMapping.$TargetDomainFQDN

        if ($DebugFlag -eq $true)
        {
            write-host "addriveNumber: $addriveNumber" -ForegroundColor Cyan
        }

        $Error.Clear()
        switch ($addriveNumber) {
            2 { Try { $ACL = Get-Acl -Path "AD2:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            3 { Try { $ACL = Get-Acl -Path "AD3:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            4 { Try { $ACL = Get-Acl -Path "AD4:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            5 { Try { $ACL = Get-Acl -Path "AD5:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            6 { Try { $ACL = Get-Acl -Path "AD6:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            7 { Try { $ACL = Get-Acl -Path "AD7:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            8 { Try { $ACL = Get-Acl -Path "AD8:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
            9 { Try { $ACL = Get-Acl -Path "AD9:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           10 { Try { $ACL = Get-Acl -Path "AD10:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           11 { Try { $ACL = Get-Acl -Path "AD11:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           12 { Try { $ACL = Get-Acl -Path "AD12:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           13 { Try { $ACL = Get-Acl -Path "AD13:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           14 { Try { $ACL = Get-Acl -Path "AD14:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           15 { Try { $ACL = Get-Acl -Path "AD15:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           16 { Try { $ACL = Get-Acl -Path "AD16:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           17 { Try { $ACL = Get-Acl -Path "AD17:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           18 { Try { $ACL = Get-Acl -Path "AD18:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           19 { Try { $ACL = Get-Acl -Path "AD19:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           20 { Try { $ACL = Get-Acl -Path "AD20:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           21 { Try { $ACL = Get-Acl -Path "AD21:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           22 { Try { $ACL = Get-Acl -Path "AD22:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           23 { Try { $ACL = Get-Acl -Path "AD23:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           24 { Try { $ACL = Get-Acl -Path "AD24:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           25 { Try { $ACL = Get-Acl -Path "AD25:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           26 { Try { $ACL = Get-Acl -Path "AD26:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           27 { Try { $ACL = Get-Acl -Path "AD27:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           28 { Try { $ACL = Get-Acl -Path "AD28:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           29 { Try { $ACL = Get-Acl -Path "AD29:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           30 { Try { $ACL = Get-Acl -Path "AD30:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           31 { Try { $ACL = Get-Acl -Path "AD31:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           32 { Try { $ACL = Get-Acl -Path "AD32:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           33 { Try { $ACL = Get-Acl -Path "AD33:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           34 { Try { $ACL = Get-Acl -Path "AD34:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           35 { Try { $ACL = Get-Acl -Path "AD35:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           36 { Try { $ACL = Get-Acl -Path "AD36:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           37 { Try { $ACL = Get-Acl -Path "AD37:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           38 { Try { $ACL = Get-Acl -Path "AD38:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           39 { Try { $ACL = Get-Acl -Path "AD39:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           40 { Try { $ACL = Get-Acl -Path "AD40:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           41 { Try { $ACL = Get-Acl -Path "AD41:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           42 { Try { $ACL = Get-Acl -Path "AD42:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           43 { Try { $ACL = Get-Acl -Path "AD43:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           44 { Try { $ACL = Get-Acl -Path "AD44:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           45 { Try { $ACL = Get-Acl -Path "AD45:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           46 { Try { $ACL = Get-Acl -Path "AD46:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           47 { Try { $ACL = Get-Acl -Path "AD47:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           48 { Try { $ACL = Get-Acl -Path "AD48:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           49 { Try { $ACL = Get-Acl -Path "AD49:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           50 { Try { $ACL = Get-Acl -Path "AD50:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           51 { Try { $ACL = Get-Acl -Path "AD51:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           52 { Try { $ACL = Get-Acl -Path "AD52:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           53 { Try { $ACL = Get-Acl -Path "AD53:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           54 { Try { $ACL = Get-Acl -Path "AD54:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           55 { Try { $ACL = Get-Acl -Path "AD55:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           56 { Try { $ACL = Get-Acl -Path "AD56:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           57 { Try { $ACL = Get-Acl -Path "AD57:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           58 { Try { $ACL = Get-Acl -Path "AD58:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           59 { Try { $ACL = Get-Acl -Path "AD59:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           60 { Try { $ACL = Get-Acl -Path "AD60:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           61 { Try { $ACL = Get-Acl -Path "AD61:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           62 { Try { $ACL = Get-Acl -Path "AD62:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           63 { Try { $ACL = Get-Acl -Path "AD63:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           64 { Try { $ACL = Get-Acl -Path "AD64:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           65 { Try { $ACL = Get-Acl -Path "AD65:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           66 { Try { $ACL = Get-Acl -Path "AD66:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           67 { Try { $ACL = Get-Acl -Path "AD67:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           68 { Try { $ACL = Get-Acl -Path "AD68:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           69 { Try { $ACL = Get-Acl -Path "AD69:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           70 { Try { $ACL = Get-Acl -Path "AD70:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           71 { Try { $ACL = Get-Acl -Path "AD71:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           72 { Try { $ACL = Get-Acl -Path "AD72:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           73 { Try { $ACL = Get-Acl -Path "AD73:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           74 { Try { $ACL = Get-Acl -Path "AD74:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           75 { Try { $ACL = Get-Acl -Path "AD75:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           76 { Try { $ACL = Get-Acl -Path "AD76:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           77 { Try { $ACL = Get-Acl -Path "AD77:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           78 { Try { $ACL = Get-Acl -Path "AD78:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           79 { Try { $ACL = Get-Acl -Path "AD79:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           80 { Try { $ACL = Get-Acl -Path "AD80:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           81 { Try { $ACL = Get-Acl -Path "AD81:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           82 { Try { $ACL = Get-Acl -Path "AD82:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           83 { Try { $ACL = Get-Acl -Path "AD83:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           84 { Try { $ACL = Get-Acl -Path "AD84:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           85 { Try { $ACL = Get-Acl -Path "AD85:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           86 { Try { $ACL = Get-Acl -Path "AD86:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           87 { Try { $ACL = Get-Acl -Path "AD87:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           88 { Try { $ACL = Get-Acl -Path "AD88:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           89 { Try { $ACL = Get-Acl -Path "AD89:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           90 { Try { $ACL = Get-Acl -Path "AD90:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           91 { Try { $ACL = Get-Acl -Path "AD91:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

           92 { Try { $ACL = Get-Acl -Path "AD92:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           93 { Try { $ACL = Get-Acl -Path "AD93:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           94 { Try { $ACL = Get-Acl -Path "AD94:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           95 { Try { $ACL = Get-Acl -Path "AD95:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           96 { Try { $ACL = Get-Acl -Path "AD96:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           97 { Try { $ACL = Get-Acl -Path "AD97:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           98 { Try { $ACL = Get-Acl -Path "AD98:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
           99 { Try { $ACL = Get-Acl -Path "AD99:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
          100 { Try { $ACL = Get-Acl -Path "AD100:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}
          101 { Try { $ACL = Get-Acl -Path "AD101:\$TargetDN" -ErrorAction SilentlyContinue } Catch {}}

        }

        if ($DebugFlag -eq $true)
        {
            write-host "Error: $Error" -ForegroundColor Cyan
        }

        if ($Error)
        {
            $Error.Clear()
            $ACL = Get-Acl -Path "Microsoft.ActiveDirectory.Management.dll\ActiveDirectory:://RootDSE/$TargetDN" -ErrorAction SilentlyContinue
        }

    }

    if (!$Error -and $addrivenumber -ne $null)
    {

        $Report += $ACL | select-Object -ExpandProperty Access 
        Try 
        {
            $Owner = $ACL | select-object -ExpandProperty Owner -ErrorAction SilentlyContinue
        } Catch {
            $Owner = $null
        }

        $AreAccessRulesProtected = $ACL.AreAccessRulesProtected

        if ($DebugFlag -eq $true)
        {
            write-host "AreAccessRulesProtected: $AreAccessRulesProtected" -ForegroundColor Cyan
        }


        ####################
        ### Owner Lookup ###
        ####################
        if ($Owner)
        {
            $Owner2 = EscapeSpecialCharacters $Owner
            if ($Owner2.contains("S-1-5-32-"))
            {
                if ($dicADObjects.ContainsKey($Owner2) -eq $true)
                {
                    $objOwner = $dicADObjects.$Owner2
                } else {
                    try
                    {
                        $ObjOwner = get-adobject -Filter "ObjectSID -eq '$Owner2'" -server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                    } catch {
                        WriteLog "Ref5 - Could not find $Owner on $TargetDC."
                    }
                }
                if ($ObjOwner)
                {
                    if ($dicADObjects.ContainsKey($Owner2) -eq $false)
                    {
                        $dicADObjects.add($Owner2,$ObjOwner)
                    }
                    $ObjOwnerDistinguishedName = $ObjOwner.DistinguishedName
                    $ObjOwnerObjectClass = $ObjOwner.ObjectClass
                }
            }
            if ($Owner.contains("\"))
            {
                $Index = $Owner.IndexOf("\")
                $Length = $Owner.Length
                $AppliedLength = $Length - ($Index)-1
                $TargetIdentity = $Owner.Substring($Index+1,$AppliedLength)
                $TargetAuthority = $Owner.Substring(0,$Index)

                $ObjOwnerDistinguishedName = ""
                $TargetIdentity2 = EscapeSpecialCharacters $TargetIdentity

                if ($TargetAuthority -eq "NT AUTHORITY")
                {
                    if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                    {
                        $objOwner = $dicADObjects.$TargetIdentity2
                    } else {
                        try
                        {
                            $ObjOwner = get-adobject -searchbase (get-adrootdse).configurationNamingContext -Filter "Name -eq '$TargetIdentity2'" -server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                        } catch {
                            WriteLog "Ref7 - Could not find $TargetIdentity on $TargetDC."
                        }
                    }
                    if ($objOwner)
                    {
                        if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                        {
                            $dicADObjects.add($TargetIdentity2,$objOwner)
                        }
                        $ObjOwnerDistinguishedName = $ObjOwner.DistinguishedName
                        $ObjOwnerObjectClass = $ObjOwner.ObjectClass
                    }
                }
                if ($TargetAuthority -eq "BUILTIN")
                {
                    
                    $BuiltinContainerDN = "CN=Builtin," + $TargetDomainDN
                    if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                    {
                        $objOwner = $dicADObjects.$TargetIdentity2
                    } else {
                        try
                        {
                        
                            $objOwner = Get-ADObject -Filter "Name -eq '$TargetIdentity2'" -SearchBase $BuiltinContainerDN -SearchScope OneLevel -server $TargetDC -ErrorAction SilentlyContinue
                        } catch {
                            WriteLog "Ref8 - Could not find $TargetIdentity on $TargetDC."
                        }
                    }
                    if ($ObjOwner)
                    {
                        if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                        {
                            $dicADObjects.add($TargetIdentity2,$objOwner)
                        }
                        $ObjOwnerDistinguishedName = $ObjOwner.DistinguishedName
                        $ObjOwnerObjectClass = $ObjOwner.ObjectClass
                    }
                }

                if ($ObjOwnerDistinguishedName -eq "" -or $ObjOwnerDistinguishedName -eq $null)
                {
                    #<#
                    if ($dicDomainNetBIOSNameByNetBIOSName.ContainsKey($TargetAuthority) -eq $false)
                    {
                        try
                        {
                            $objDomain = Get-ADDomain -identity $TargetAuthority -ErrorAction SilentlyContinue
                        } catch {

                        }
                        if ($objDomain)
                        {
                            $DomainFQDN = $objDomain.DNSRoot
                            $TargetLDAP = $objDomain.DistinguishedName
                            $DomainSID = $objDomain.DomainSID
                            $TargetDomainNetBIOSName = $objDomain.NetBIOSName

                            If ($RootDomain -eq $objDomain.DNSRoot) {
                                $DomainRootSID = $objDomain.DomainSID
                            }
                            If ($RootDomain -eq $DomainFQDN)
                            {
                                $IsRootDomain = $true
                            } else {
                                $IsRootDomain = $false
                            }
    
                            $TargetDC = GetClosestDC $TargetAuthority
                            if ($TargetDC)
                            {
                                if ($dicDomainNetBIOSNameByNetBIOSName.ContainsKey($TargetAuthority) -eq $false)
                                {
                                    $dicDomainNetBIOSNameByNetBIOSName.add($TargetAuthority,$TargetDC)
                                }
                            }
                        }

                    }
                    #>
                    if ($dicDomainNetBIOSNameByNetBIOSName.ContainsKey($TargetAuthority) -eq $true)
                    {

                        $DCtoQuery = $dicDomainNetBIOSNameByNetBIOSName.$TargetAuthority
                        $TargetIdentity2 = EscapeSpecialCharacters $TargetIdentity
                        if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                        {
                            $objOwner = $dicADObjects.$TargetIdentity2
                        } else {
                            try
                            {
                                $ObjOwner = get-adobject -Filter "SamAccountName -eq '$TargetIdentity2'" -server $DCtoQuery -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue

                            } catch {
                                WriteLog "Ref6 - Could not find $TargetIdentity on $DCtoQuery."
                            }
                        }
                        if ($ObjOwner)
                        {
                            if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                            {
                                $dicADObjects.Add($TargetIdentity2,$ObjOwner)
                            }
                            $ObjOwnerDistinguishedName = $ObjOwner.DistinguishedName
                            $ObjOwnerObjectClass = $ObjOwner.ObjectClass
                        }
                    }
                }
            }

            if ($ObjOwnerDistinguishedName.length -gt 1)
            {
                $Index = $ObjOwnerDistinguishedName.IndexOf("DC=")
                $Length = $ObjOwnerDistinguishedName.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $ObjOwnerDomainDN = $ObjOwnerDistinguishedName.Substring($Index,$AppliedLength)

                $ObjOwnerDomainFQDN = $ObjOwnerDomainDN -replace ",DC=", "."
                $ObjOwnerDomainFQDN = $ObjOwnerDomainFQDN -replace "DC=", ""
            } else {
                $ObjOwnerDomainFQDN = ""
            }

            if ($dicTier0DistinguishedNames.ContainsKey($TargetDN) -eq $true)
            {
                if ($ObjOwner)
                {
                    if ($dicTier0Owners.ContainsKey($TargetDN) -eq $false)
                    {
                        $OwnerName = $ObjOwnerDistinguishedName
                        $dicTier0Owners.add($TargetDN,$OwnerName)
                    }
                }
            }
        } else {
            $ObjOwnerDistinguishedName = ""
            $ObjOwnerObjectClass = ""
            $ObjOwnerDomainFQDN = ""
            $OwnerName = ""
        }
        ########################
        ### End Owner Lookup ###
        ########################

        if ($dicDomainDC.ContainsKey($TargetDomainFQDN) -eq $false)
        {
            return #Bail out as we're not getting permissions for objects in remote forest(s), but the Owner was resolved and recorded.
        }


        foreach ($item in $report) 
        {
            $ActiveDirectoryRights = $item.ActiveDirectoryRights.ToString()
            $InheritanceType = $item.InheritanceType
            $ObjectType = $item.ObjectType
            $InheritedObjectType = $item.inheritedObjectType
            $ObjectFlags = $item.ObjectFlags
            $AccessControlType = $item.AccessControlType
            $IdentityReference = $item.IdentityReference.ToString()
            $IsInherited = $item.IsInherited
            $InheritanceFlags = $item.InheritanceFlags
            $PropogationFlags = $item.PropagationFlags
            $objectTypeName = $schemaIDGUID.$ObjectType
            $inheritedObjectTypeName = $schemaIDGUID.$InheritedObjectType

            $Reason = ""
            $ObjSamAccountName = ""
            $WriteAccess = $false  
            $CriticalACL = $false
            $NonTier0Owner = $false
            $BitlockerAccess = $false

            if ($ObjOwner -and $ObjOwnerDistinguishedName.length -gt 1)
            {
                if ($objOwnerDistinguishedName.contains("CN=System,CN=WellKnown Security Principals,CN=Configuration,DC="))
                {
                    $NonDefaultOwner = $false
                    $NonTier0Owner = $false

                } else {
                    if ($objOwnerDistinguishedName -ne $null -and $objOwnerDistinguishedName -ne "")
                    {
                        if ($dicTier0DistinguishedNames.ContainsKey($objOwnerDistinguishedName) -eq $false) 
                        { 
                            $NonTier0Owner = $true
                            $NonDefaultOwner = $true
                            if ($Reason -eq "")
                            {
                                $Reason = "Non-Tier0 Owner"
                            } else {
                                $Reason = $Reason + ", Non-Tier0 Owner"
                            }
                        } else {
                            $NonDefaultOwner = $false
                        }
                    } else {
                        $NonDefaultOwner = $false
                        $NonTier0Owner = $false
                    }
                }
            }
            if ($ActiveDirectoryRights.contains("WriteProperty")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("ExtendedRight")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("WriteDacl")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("WriteOwner")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("CreateChild")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("Delete")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("DeleteTree")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("DeleteChild")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("DeleteTree")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("GenericAll")) 
            { 
                $WriteAccess = $true 
            }
            if ($ActiveDirectoryRights.contains("All")) 
            { 
                $WriteAccess = $true 
            }
            if ($GetAllACEs -eq $true) 
            { 
                $BitlockerAccess = $true
                if ($Reason -eq "")
                {
                    $Reason = "Bitlocker Access"
                } else {
                    $Reason = $Reason + ", Bitlocker Access"
                }

            }
            if ($TargetDN.contains("CN=AdminSDHolder,") -and $AreAccessRulesProtected -eq $false) 
            { 
                $CriticalACL = $true
                if ($Reason -eq "")
                {
                    $Reason = "Critical ACL is inherited"
                } else {
                    $Reason = $Reason + ", Critical ACL is inherited"
                }
            }

            if ($IdentityReference.contains("S-1-5-21-") -and $ObjDistinguishedName -eq "") 
            { 
                if ($Reason -eq "")
                {
                    $Reason = "Orphaned SID"
                } else {
                    $Reason = $Reason + ", Orphaned SID"
                }
            }

            if (($Reason -ne "" -or $WriteAccess -eq $true) -and $AccessControlType -eq "Allow")
            {
                $ObjDistinguishedName = ""
                $ObjObjectClass = ""

                $IdentityReference2 = EscapeSpecialCharacters $IdentityReference

                if ($dicIdentityDN.ContainsKey($IdentityReference2) -eq $false) 
                {
                    if ($IdentityReference.contains("S-1-5-32-"))
                    {
                        
                        if ($dicADObjects.ContainsKey($IdentityReference2) -eq $true)
                        {
                            $Obj = $dicADObjects.$IdentityReference2
                        } else {
                            try
                            {
                                $Obj = get-adobject -Filter "ObjectSID -eq '$IdentityReference2'" -server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                            } catch {
                                WriteLog "Ref9 - Could not find $IdentityReference on $TargetDC."
                            }
                        }
                        if ($Obj)
                        {
                            if ($dicADObjects.ContainsKey($IdentityReference2) -eq $false)
                            {
                                $dicADObjects.add($IdentityReference2,$Obj)
                            }
                            $ObjDistinguishedName = $Obj.DistinguishedName
                        }

                        if ($ObjDistinguishedName -eq $null -or $ObjDistinguishedName -eq "")
                        {
                            $TargetRootDC = GetClosestDC $RootDomainFQDN
                            if ($dicADObjects.ContainsKey($IdentityReference2) -eq $true)
                            {
                                $Obj = $dicADObjects.$IdentityReference2
                            } else {
                                try
                                {
                                    $Obj = get-adobject -Filter "ObjectSID -eq '$IdentityReference2'" -server $TargetRootDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                                } catch {
                                    WriteLog "Ref9.5 - Could not find $IdentityReference on $RootDomainFQDN"
                                }
                            }
                        }
                        if ($Obj)
                        {
                            if ($dicADObjects.ContainsKey($IdentityReference2) -eq $false)
                            {
                                $dicADObjects.Add($IdentityReference2,$Obj)
                            }
                            $ObjDistinguishedName = $Obj.DistinguishedName
                            $ObjObjectClass = $Obj.ObjectClass
                            $ObjSID = [string]$Obj.ObjectSID
                            $ObjSamAccountName = $Obj.SamAccountName

                            if ($DicIdentityDN.ContainsKey($IdentityReference) -eq $false) {$dicIdentityDN.Add($IdentityReference,$ObjDistinguishedName)}
                            if ($dicIdentityObjectClass.ContainsKey($IdentityReference) -eq $false) {$dicIdentityObjectClass.Add($IdentityReference,$ObjObjectClass)}
                            if ($dicIdentitySID.ContainsKey($IdentityReference) -eq $false) {$dicIdentitySID.Add($IdentityReference,$ObjSID)}
                        }

                    }


                    if ($IdentityReference.contains("\"))
                    {

                        $Index = $IdentityReference.IndexOf("\")
                        $Length = $IdentityReference.Length
                        $AppliedLength = $Length - ($Index)-1
                        $TargetIdentity = $IdentityReference.Substring($Index+1,$AppliedLength)
                        $TargetAuthority = $IdentityReference.Substring(0,$Index)
                        $TargetIdentity2 = EscapeSpecialCharacters $TargetIdentity

                        if ($TargetAuthority -eq "NT AUTHORITY")
                        {
                            
                            if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                            {
                                $Obj = $dicADObjects.$TargetIdentity2
                            } else {
                                try
                                {
                                
                                    $Obj = get-adobject -searchbase (get-adrootdse).configurationNamingContext -Filter "Name -eq '$TargetIdentity2'" -server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                                } catch {
                                    WriteLog "Ref11 - Could not find $TargetIdentity on $TargetDC."
                                }
                            }
                            if ($Obj)
                            {
                                if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                                {
                                    $dicADObjects.Add($TargetIdentity2,$Obj)
                                }
                                $ObjDistinguishedName = $Obj.DistinguishedName
                                $ObjObjectClass = $Obj.ObjectClass
                                $ObjSID = [string]$Obj.ObjectSID
                                $ObjSamAccountName = $Obj.SamAccountName

                                if ($DicIdentityDN.ContainsKey($IdentityReference) -eq $false) {$dicIdentityDN.Add($IdentityReference,$ObjDistinguishedName)}
                                if ($dicIdentityObjectClass.ContainsKey($IdentityReference) -eq $false) {$dicIdentityObjectClass.Add($IdentityReference,$ObjObjectClass)}
                                if ($dicIdentitySID.ContainsKey($IdentityReference) -eq $false) {$dicIdentitySID.Add($IdentityReference,$ObjSID)}

                            }
                        }

                        if ($TargetAuthority -eq "BUILTIN")
                        {
                            $BuiltinContainerDN = "CN=Builtin," + $TargetDomainDN
                            if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                            {
                                $Obj = $dicADObjects.$TargetIdentity2
                            } else {
                                try
                                {
                                    $Obj = Get-ADObject -Filter "Name -eq '$TargetIdentity2'" -SearchBase $BuiltinContainerDN -SearchScope OneLevel -server $TargetDC -ErrorAction SilentlyContinue
                                } catch {
                                    WriteLog "Ref12 - Could not find $TargetIdentity on $TargetDC."
                                }
                            }

                            if ($obj)
                            {
                                if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                                {
                                    $dicADObjects.add($TargetIdentity2,$Obj)
                                }
                                $ObjDistinguishedName = $Obj.DistinguishedName
                                $ObjObjectClass = $Obj.ObjectClass
                                $ObjSID = [string]$Obj.ObjectSID
                                $ObjSamAccountName = $Obj.SamAccountName

                                if ($DicIdentityDN.ContainsKey($IdentityReference) -eq $false) {$dicIdentityDN.Add($IdentityReference,$ObjDistinguishedName)}
                                if ($dicIdentityObjectClass.ContainsKey($IdentityReference) -eq $false) {$dicIdentityObjectClass.Add($IdentityReference,$ObjObjectClass)}
                                if ($dicIdentitySID.ContainsKey($IdentityReference) -eq $false) {$dicIdentitySID.Add($IdentityReference,$ObjSID)}
                            }
                        }

                        if ($dicDomainNetBIOSNameByNetBIOSName.ContainsKey($TargetAuthority) -eq $true)
                        {
                            $DCtoQuery = $dicDomainNetBIOSNameByNetBIOSName.$TargetAuthority
                            if ($DCtoQuery -ne "" -and $DCtoQuery -ne $null)
                            {
                                if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                                {
                                    $Obj = $dicADObjects.$TargetIdentity2
                                } else {
                                    try
                                    {
                                        $Obj = get-adobject -Filter "SamAccountName -eq '$TargetIdentity2'" -server $DCtoQuery -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                                    } catch {
                                        WriteLog "Ref10 - Could not find $TargetIdentity on $DCtoQuery."
                                    }
                                }

                                if ($Obj)
                                {
                                    if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                                    {
                                        $dicADObjects.add($TargetIdentity2,$Obj)
                                    }
                                    $ObjDistinguishedName = $Obj.DistinguishedName
                                    $ObjObjectClass = $Obj.ObjectClass
                                    $ObjSID = [string]$Obj.ObjectSID
                                    $ObjSamAccountName = $Obj.SamAccountName

                                    if ($DicIdentityDN.ContainsKey($IdentityReference) -eq $false) {$dicIdentityDN.Add($IdentityReference,$ObjDistinguishedName)}
                                    if ($dicIdentityObjectClass.ContainsKey($IdentityReference) -eq $false) {$dicIdentityObjectClass.Add($IdentityReference,$ObjObjectClass)}
                                    if ($dicIdentitySID.ContainsKey($IdentityReference) -eq $false) {$dicIdentitySID.Add($IdentityReference,$ObjSID)}
                                }
                            }
                        } else {
                            if ($TargetAuthority -ne "BUILTIN" -and $TargetAuthority -ne "NT AUTHORITY")
                            {
                                # This is the path when an ACE references a domain in a remote forest for the first time.
                                $RemoteTargetDC = GetClosestDC $TargetAuthority
                                if ($RemoteTargetDC)
                                {
                                    if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $true)
                                    {
                                        $Obj = $dicADObjects.$TargetIdentity2
                                    } else {
                                        try
                                        {
                                            $Obj = get-adobject -Filter "SamAccountName -eq '$TargetIdentity2'" -server $RemoteTargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                                        } catch {
                                            WriteLog "Ref10.5 - Could not find $TargetIdentity on $RemoteTargetDCFQDN."
                                        }
                                    }

                                    if ($Obj)
                                    {
                                        if ($dicADObjects.ContainsKey($TargetIdentity2) -eq $false)
                                        {
                                            $dicADObjects.add($TargetIdentity2,$Obj)
                                        }
                                        $ObjDistinguishedName = $Obj.DistinguishedName
                                        $ObjObjectClass = $Obj.ObjectClass
                                        $ObjSID = [string]$Obj.ObjectSID
                                        $ObjSamAccountName = $Obj.SamAccountName

                                        if ($DicIdentityDN.ContainsKey($IdentityReference) -eq $false) {$dicIdentityDN.Add($IdentityReference,$ObjDistinguishedName)}
                                        if ($dicIdentityObjectClass.ContainsKey($IdentityReference) -eq $false) {$dicIdentityObjectClass.Add($IdentityReference,$ObjObjectClass)}
                                        if ($dicIdentitySID.ContainsKey($IdentityReference) -eq $false) {$dicIdentitySID.Add($IdentityReference,$ObjSID)}
                                    }
                                }
                            }
                        }

                    } else {
                        $IdentityReference2 = EscapeSpecialCharacters $IdentityReference
                        if ($dicADObjects.ContainsKey($IdentityReference2) -eq $true)
                        {
                            $Obj = $dicADObjects.$IdentityReference2
                        } else {
                            try
                            {
                                $Obj = get-adobject -searchbase (get-adrootdse).configurationNamingContext -Filter "Name -eq '$IdentityReference2'" -server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                            } catch {
                                WriteLog "Ref13 - Could not find $IdentityReference on $TargetDC."
                            }
                        }
                        if ($Obj)
                        {
                            if ($dicADObjects.ContainsKey($IdentityReference2) -eq $false)
                            {
                                $dicADObjects.add($IdentityReference2,$Obj)
                            }
                            $ObjDistinguishedName = $Obj.DistinguishedName
                            $ObjObjectClass = $Obj.ObjectClass
                            $ObjSID = [string]$Obj.ObjectSID
                            $ObjSamAccountName = $Obj.SamAccountName

                            if ($DicIdentityDN.ContainsKey($IdentityReference) -eq $false) {$dicIdentityDN.Add($IdentityReference,$ObjDistinguishedName)}
                            if ($dicIdentityObjectClass.ContainsKey($IdentityReference) -eq $false) {$dicIdentityObjectClass.Add($IdentityReference,$ObjObjectClass)}
                            if ($dicIdentitySID.ContainsKey($IdentityReference) -eq $false) {$dicIdentitySID.Add($IdentityReference,$ObjSID)}

                        }
                    }

                } else {
                    if ($IdentityReference -ne $null -and $IdentityReference -ne "")
                    {
                        $ObjDistinguishedName = $dicIdentityDN.$IdentityReference
                        $ObjObjectClass = $dicIdentityObjectClass.$IdentityReference
                        $ObjSID = $dicIdentitySID.$IdentityReference
                    }
                }

                if ($ObjDistinguishedName.length -gt 1)
                {

                    if ($dicTier0DistinguishedNames.ContainsKey($ObjDistinguishedName) -eq $false)
                    {
                        $IsTier0 = $false
                        If ($WriteAccess -eq $true)
                        {
                            if ($Reason -eq "")
                            {
                                $Reason = "Non-Tier 0 Identity With Write Access On Tier-0 Object"
                            } else {
                                $Reason = $Reason + ", Non-Tier 0 Identity With Write Access On Tier-0 Object"
                            }
                        }
                    } else {
                        $IsTier0 = $true
                    }
                    

                    $Index = $ObjDistinguishedName.IndexOf("DC=")
                    $Length = $ObjDistinguishedName.Length + 1
                    $AppliedLength = $Length - ($Index+1)
                    $ObjDomainDN = $ObjDistinguishedName.Substring($Index,$AppliedLength)

                    $ObjDomainFQDN = $ObjDomainDN -replace ",DC=", "."
                    $ObjDomainFQDN = $ObjDomainFQDN -replace "DC=", ""
                } else {
                    $ObjDomainFQDN = ""
                }

                if ($ObjDistinguishedName -ne $null -and $ObjDistinguishedName -ne "" -and $ObjSID -ne "" -and $ObjSID -ne $null)
                {

                    $Index = $ObjSID.LastIndexOf("-")
                    $Length = $ObjSID.Length + 1
                    $AppliedLength = $Length - ($Index+1)
                    $CurrentRID = $ObjSID.Substring($Index+1,$AppliedLength-1)
                    $RidFound = $false
                    $Tier0Object = ""

                    if ($dicTier0RIDs.ContainsKey($CurrentRID) -eq $true)
                    {
                        $RIDFound = $true
                        $Tier0Object = $dicTier0RIDs.$CurrentRID
                    } 
                    if ($dicTier0SIDs.ContainsKey($ObjSID) -eq $true)
                    {
                        $RIDFound = $true
                        $Tier0Object = $dicTier0IdentitiesBySID.$ObjSID
                    }

                    if ($ObjDistinguishedName -ne "" -and $ObjDistinguishedName -ne $null)
                    {
                        $Index = $ObjDistinguishedName.IndexOf(",")
                        $Length = $ObjDistinguishedName.Length
                        $AppliedLength = $Length - ($Index + 1)
                        $ObjContainer = $ObjDistinguishedName.Substring($Index+1,$AppliedLength)
                    } else {
                        $ObjContainer = ""
                    }
                    if ($ObjDistinguishedName.contains("CN=Self,")) 
                    { 
                        $IsSelf = $true 
                    } else {
                        $IsSelf = $false
                    }
                    if ($ObjDistinguishedName.contains("CN=Creator Owner,")) 
                    { 
                        $IsCreatorOwner = $true 
                    } else {
                        $IsCreatorOwner = $false
                    }
                    if ($objectTypeName -eq "Apply-Group-Policy")
                    {
                        $IsApplyGPO = $true
                    } else {
                        $IsApplyGPO = $false
                    }
                    if ($objectTypeName -eq "Certificate-Enrollment" -or $objectTypeName -eq "Certificate-AutoEnrollment")
                    {
                        $IsCertEnrollment = $true
                    } else {
                        $IsCertEnrollment = $false
                    }
                    if (($dicTier0DistinguishedNames.ContainsKey($ObjDistinguishedName) -eq $false -and $IsSelf -eq $false -and $IsCreatorOwner -eq $false -and $RIDFound -eq $false -and $IsApplyGPO -eq $false -and $IsCertEnrollment -eq $false) -or ($NonDefaultOwner -eq $true)) 
                    {
                        if ($IdentityReference.contains("S-1-5-32-"))
                        {
                            $IdentityReferenceOut = $ObjSamAccountName
                        } else {
                            $IdentityReferenceOut = $IdentityReference
                        }

                        ### Check File Threshold Size ###
                        #$Global:ObjectCount = 0
                        #$Global:FileSizeThreshold = 10000
                        #$Global:FileFragmentCount = 0
                        #$Global:FragmentFilename = ""

                        if ($Global:FileFragmentCount -ne 0)
                        {
                            $TargetFilename = $Global:FragmentFilename
                        }

                        $fileSizeBytes = (Get-Item -Path $TargetFilename).Length

                        if ($fileSizeBytes -gt $Global:FileSizeThreshold)
                        {
                            #Create new File Fragment
                            $Global:FileFragmentCount = $Global:FileFragmentCount + 1

                            if ($Global:FileFragmentCount -eq 1)
                            {
                                $Index = $TargetFilename.lastindexof(".CSV")
                                $Filename = $TargetFilename.Substring(0,$Index) + "-" + $Global:FileFragmentCount + ".CSV"
                                $Global:FragmentFilename = $Filename
                            } else {
                                $Index = $TargetFilename.lastindexof("-")
                                $FileName = $TargetFilename.Substring(0,$Index) + "-" + $Global:FileFragmentCount + ".CSV"
                                $Global:FragmentFilename = $Filename
                            }
                            $TargetFilename = $Global:FragmentFilename
                        }

                        if ($DataType -ne "GPO")
                        {

                            $LineOut = '"' + $TargetDN + '",'`
                                        + '"' + $AreAccessRulesProtected  + '",'`
                                        + '"' + $objectTypeName  + '",'`
                                        + '"' + $inheritedObjectTypeName  + '",'`
                                        + '"' + $ActiveDirectoryRights  + '",'`
                                        + '"' + $InheritanceType  + '",'`
                                        + '"' + $ObjectType  + '",'`
                                        + '"' + $InheritedObjectType  + '",'`
                                        + '"' + $ObjectFlags  + '",'`
                                        + '"' + $AccessControlType  + '",'`
                                        + '"' + $IdentityReferenceOut  + '",'`
                                        + '"' + $ObjObjectClass  + '",'`
                                        + '"' + $ObjDistinguishedName  + '",'`
                                        + '"' + $ObjContainer  + '",'`
                                        + '"' + $ObjDomainFQDN  + '",'`
                                        + '"Explicit",'`
                                        + '"' + $IsInherited  + '",'`
                                        + '"' + $InheritanceFlags  + '",'`
                                        + '"' + $PropogationFlags  + '",'`
                                        + '"' + $Owner  + '",'`
                                        + '"' + $ObjOwnerDistinguishedName  + '",'`
                                        + '"' + $ObjOwnerObjectClass  + '",'`
                                        + '"' + $ObjOwnerDomainFQDN  + '",'`
                                        + '"' + $Reason  + '"'
            
                            Add-Content -Path $TargetFilename -Value $LineOut -Encoding Unicode

                        } else {

                            $GPOName = $dicGPOName.$TargetDN
                            $GPOWhenChanged = $dicGPOWhenChanged.$TargetDN
                            $GPOWhenCreated = $dicGpOWhenCreated.$TargetDN
                            $GPOLinkedTo = $dicTier0GPOs.$TargetDN

                            $LineOut = '"' + $TargetDN + '",'`
                                        + '"' + $AreAccessRulesProtected  + '",'`
                                        + '"' + $objectTypeName  + '",'`
                                        + '"' + $inheritedObjectTypeName  + '",'`
                                        + '"' + $ActiveDirectoryRights  + '",'`
                                        + '"' + $InheritanceType  + '",'`
                                        + '"' + $ObjectType  + '",'`
                                        + '"' + $InheritedObjectType  + '",'`
                                        + '"' + $ObjectFlags  + '",'`
                                        + '"' + $AccessControlType  + '",'`
                                        + '"' + $IdentityReferenceOut  + '",'`
                                        + '"' + $ObjObjectClass  + '",'`
                                        + '"' + $ObjDistinguishedName  + '",'`
                                        + '"' + $ObjContainer  + '",'`
                                        + '"' + $ObjDomainFQDN  + '",'`
                                        + '"Explicit",'`
                                        + '"' + $IsInherited  + '",'`
                                        + '"' + $InheritanceFlags  + '",'`
                                        + '"' + $PropogationFlags  + '",'`
                                        + '"' + $Owner  + '",'`
                                        + '"' + $ObjOwnerDistinguishedName  + '",'`
                                        + '"' + $ObjOwnerObjectClass  + '",'`
                                        + '"' + $ObjOwnerDomainFQDN  + '",'`
                                        + '"' + $Reason  + '",'`
                                        + '"' + $GPOName  + '",'`
                                        + '"' + $GPOWhenChanged.ToUniversalTime()  + '",'`
                                        + '"' + $GPOWhenCreated.ToUniversalTime()  + '",'`
                                        + '"' + $GPOLinkedTo  + '"'
            
                            Add-Content -Path $TargetFilename -Value $LineOut -Encoding Unicode

                        }

                        #Get Nested Members

                        $FilterOut = $false
                        if ($ObjDistinguishedName.contains("Domain Users")) { $FilterOut = $true }
                        if ($ObjDistinguishedName.contains("Domain Computers")) { $FilterOut = $true }
                        if ($ObjObjectClass -eq "group" -and $FilterOut -eq $false)
                        {
                            try
                            {
                                $dicMemberDNs.Clear()   #KipG
                            } catch {
                                #???
                            }
                            if ($IncludeNested -eq $true)
                            {    
                                if ($dicIndirectGroups.ContainsKey($ObjDistinguishedName) -eq $false)
                                {
                                    $dicIndirectGroups.Add($ObjDistinguishedName,"")
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        #WriteLog "Object not found: $TargetDN"
    }
}  ### End GETADACL ###


#########################
### Combine CSV Files ###
#########################
function CombineCSVFiles
{
    param(
        $TargetFilename
    )

    WriteLog "" $true
    WriteLog "Combining Files: $TargetFilename" $true

    $Index = $TargetFilename.lastindexOf(".CSV")

    $FilePrefix = $TargetFilename.Substring(0,$Index)
    
    $Index = $FilePrefix.LastIndexOf("\")
    $Length = $FilePrefix.Length
    $FilePrefix2 = $FilePrefix.Substring($Index + 1,$Length - ($Index + 1))

    $DestFilename = $CurFolder + "\" + $FilePrefix2 + ".CSV"
    
    $CheckFile = Test-Path "$CurFolder\$FilePrefix2-*.csv"

    if ($CheckFile -eq $true)
    {
        Get-Content "$CurFolder\$FilePrefix2-*.csv" | Add-Content $DestFilename -Encoding Unicode
        Get-ChildItem "$CurFolder\$FilePrefix2-*.csv" | remove-item
    }
    $Global:ObjectCount = 0
    $Global:FileFragmentCount = 0
    $Global:FragmentFilename = ""

}

#####################
### Get AD Object ###
#####################
function GetADObject
{
    param( 
        $CurIdentityReference, 
        $CurTargetDC,
        $CurServerDomain,
        $CacheObject
    )
    $RootDSE = Get-ADRootDSE -Server $CurTargetDC -ErrorAction SilentlyContinue
    $RootDomain = $RootDSE.rootDomainNamingContext
    $ConfigPartition = $RootDSE.configurationNamingContext
    $DefaultNamingContext = $RootDSE.defaultNamingContext
    $SchemaPartition = $RootDSE.schemaNamingContext
    $CurIdentityReference2 = EscapeSpecialCharacters $CurIdentityReference

    $Key = $CurServerDomain + $CurIdentityReference

    if ($dicIdentitiesNotFound.ContainsKey($CurIdentityReference) -eq $true)
    {
        Return $null
    }

    if ($dicADObjects.ContainsKey($Key) -eq $true)
    {
        $ADObject = $dicADObjects.$Key
    } else {
        
        $ADObject = $null
        
        if ($CurIdentityReference.contains("S-"))
        {
            try
            {
                $ADObject = get-adobject -Searchbase "$ConfigPartition" -Filter "ObjectSID -eq '$CurIdentityReference2'" -server $CurTargetDC -Properties * -ErrorAction SilentlyContinue
            } Catch {}

            if ($ADObject -eq $Null)
            {
                try
                {
                    $ADObject = Get-adobject -Searchbase "$DefaultNamingContext" -Filter "ObjectSID -eq '$CurIdentityReference2'" -Server $CurTargetDC -Properties * -ErrorAction SilentlyContinue
                } catch {}
            }
        }
        if ($ADObject -eq $Null)
        {
            try
            {
                $ADObject = Get-adobject -Searchbase "$DefaultNamingContext" -Filter "SamAccountName -eq '$CurIdentityReference2'" -Server $CurTargetDC -Properties * -erroraction SilentlyContinue
            } catch {}
        }
        if ($ADObject -eq $Null)
        {
            if ($CurIdentityReference.Contains("-") -eq $true)
            {
                $Index = $CurIdentityReference.LastIndexOf("-")
                $Length = $CurIdentityReference.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $TargetDomainSID = $CurIdentityReference.Substring(0,$Index)
                if ($dicDomainSIDs.ContainsKey($TargetDomainSID) -eq $true)
                {
                    $CurTargetDC = $dicDomainSIDs.$TargetDomainSID

                    $RootDSE = Get-ADRootDSE -Server $CurTargetDC
                    $DefaultNamingContext = $RootDSE.defaultNamingContext
                }

            }
            
            try
            {
                $ADObject = Get-adobject -Searchbase "$DefaultNamingContext" -Filter "ObjectSID -eq '$CurIdentityReference2'" -Server $CurTargetDC -Properties * -erroraction SilentlyContinue
            } catch {}
        }

        if ($ADObject -eq $null -and $CurIdentityReference.contains("S-1-5-21-"))
        {
            $RemoteMemberSID = $CurIdentityReference
            $Index = $RemoteMemberSID.LastIndexOf("-")
            $RemoteDomainSID = $RemoteMemberSID.Substring(0,$Index)

            if ($dicTrustBySID.ContainsKey($RemoteDomainSID) -eq $true)
            {
                
                $RemoteDomainFQDN = $dicTrustBySID.$RemoteDomainSID
                $RemoteDomainDC = $dicTrustByFQDN.$RemoteDomainFQDN

                Try
                {
                    $ADObject = Get-adobject -Filter "ObjectSID -eq '$RemoteMemberSID'" -Server $RemoteDomainDC -Properties * -erroraction SilentlyContinue
                } Catch {
                    WriteLog "Could not find1: $RemoteMemberSID on $RemoteDomainDC"
                }

            }
        }

        if ($ADObject)
        {
            if ($dicADObjects.ContainsKey($Key) -eq $false)
            {
                if ($CacheObject -eq $true)
                {
                    $dicADObjects.Add($Key,$ADObject)
                }
            }
            $DN = $ADObject.DistinguishedName
            if ($dicADObjects.ContainsKey($DN) -eq $false)
            {
                if ($CacheObject -eq $true)
                {
                    $dicADObjects.add($DN,$ADObject)
                }
            }
        } else {
            if ($dicIdentitiesNotFound.ContainsKey($CurIdentityReference) -eq $false)
            {
                if ($CacheObject -eq $true)
                {
                    $dicIdentitiesNotFound.Add($CurIdentityReference,"")
                }
            }
        }
    }
    Return $ADObject
}


#####################################
### Determine Trust Relationships ###
#####################################
Function DetermineTrustRelationships
{

    WriteLog "Getting Trust Relationships to remote domains." $true
    $error.clear()
    foreach ($Domain in $dicTmpDCs.Keys)
    {
        WriteLog "Domain: $Domain" $true
    }

    foreach ($Domain in $dicTmpDCs.Keys)
    {
        WriteLog "Enumerating trusts for: $Domain" $true

        $trusts= Get-ADTrust -Filter * -Server $Domain -ErrorAction SilentlyContinue

        foreach($trust in $trusts) 
        {
            $TrustDomain = $trust.Name
            $Direction = $trust.Direction
            $IsSelective = $trust.SelectiveAuthentication

            if ($dicTmpDCs.ContainsKey($TrustDomain) -eq $false -and $dicAvoidTrust.ContainsKey($TrustDomain) -eq $false)
            {

                WriteLog "TrustDomain: $TrustDomain  Direction: $Direction  SelectiveAuthentication: $IsSelective" $true

                if ($IsSelective -eq $false -and $Direction -ne "Outbound")
                {

                    WriteLog "Getting Domain Controllers for: $TrustDomain" $true

                    $Error.Clear()
                    $TrustDCs = Get-ADDomainController -Discover -DomainName $TrustDomain -ErrorAction SilentlyContinue
                    if ($Error)
                    {
                        if ($dicAvoidTrust.ContainsKey($TrustDomain) -eq $False)
                        {
                            $dicAvoidTrust.Add($TrustDomain,"")
                        }

                    }
                    if ($dicAvoidTrust.ContainsKey($TrustDomain) -eq $false)
                    {
                        if ($TrustDCs)
                        {
                            $TrustDC = $TrustDCs.Hostname[0]

                            WriteLog "Testing Connectivity for: $TrustDC" $true

                            $OriginalPref = $ProgressPreference # Default is 'Continue'
                            $global:ProgressPreference = "SilentlyContinue"
                            $Error.Clear()
                            $tnc = tnc $TrustDC -port 3268 -ErrorAction SilentlyContinue
                            $global:ProgressPreference = $OriginalPref

                            $isAvailable = $tnc.TcpTestSucceeded

                            WriteLog "isAvailable: $isAvailable" $true

                            if ($isAvailable -eq $false)
                            {
                                if ($dicAvoidTrust.ContainsKey($TrustDC) -eq $False)
                                {
                                    $dicAvoidTrust.Add($TrustDC,"")
                                }

                            }

                            if ($isAvailable -eq $true -and $dicAvoidTrust.ContainsKey($TrustDomain) -eq $false -and $dicAvoidTrust.ContainsKey($TrustDC) -eq $false)
                            {
                                WriteLog "Getting Domain: $TrustDomain on DC: $TrustDC" $true

                                $Error.Clear()
                                $objTrustDomain = Get-ADDomain -identity $TrustDomain -server $TrustDC -ErrorAction SilentlyContinue

                                if ($Error)
                                {
                                    if ($dicAvoidTrust.ContainsKey($TrustDomain) -eq $False)
                                    {
                                        $dicAvoidTrust.Add($TrustDomain,"")
                                    }
                                    if ($dicAvoidTrust.ContainsKey($TrustDC) -eq $False)
                                    {
                                        $dicAvoidTrust.Add($TrustDC,"")
                                    }
                                }


                                if ($objTrustDomain)
                                {
                                    $TrustDomainFQDN = $objTrustDomain.DNSRoot
                                    $TrustDomainLDAP = $objTrustDomain.DistinguishedName
                                    $TrustDomainSID = [string]$objTrustDomain.DomainSID
                                    $TrustDomainNetBIOSName = $objTrustDomain.NetBIOSName
                                
                                    if ($dicAvoidTrust.ContainsKey($TrustDomainFQDN) -eq $false)
                                    {

                                        WriteLog "Adding DC to hash tables: $TrustDC" $true

                                        if ($dicTrustByFQDN.ContainsKey($TrustDomain) -eq $false)
                                        {
                                            $dicTrustByFQDN.Add($TrustDomain,$TrustDC)
                                        }
                                        if ($dicTrustBySID.ContainsKey($TrustDomainSID) -eq $false)
                                        {
                                            $dicTrustBySID.Add($TrustDomainSID,$TrustDomain)
                                        }

                                        ### Get AD Drive Mappings ###
                                        if ($dicADDriveMapping.ContainsKey($TrustDomainFQDN) -eq $false)
                                        {

                                            $ADDriveNumber = $ADDriveNumber + 1

                                            switch ($ADDriveNumber) {
                                                2 { $AD2 = New-PSDrive -Name AD2 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                3 { $AD3 = New-PSDrive -Name AD3 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                4 { $AD4 = New-PSDrive -Name AD4 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                5 { $AD5 = New-PSDrive -Name AD5 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                6 { $AD6 = New-PSDrive -Name AD6 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                7 { $AD7 = New-PSDrive -Name AD7 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                8 { $AD8 = New-PSDrive -Name AD8 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                                9 { $AD9 = New-PSDrive -Name AD9 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               10 { $AD10 = New-PSDrive -Name AD10 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               11 { $AD11 = New-PSDrive -Name AD11 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               12 { $AD12 = New-PSDrive -Name AD12 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               13 { $AD13 = New-PSDrive -Name AD13 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               14 { $AD14 = New-PSDrive -Name AD14 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               15 { $AD15 = New-PSDrive -Name AD15 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               16 { $AD16 = New-PSDrive -Name AD16 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               17 { $AD17 = New-PSDrive -Name AD17 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               18 { $AD18 = New-PSDrive -Name AD18 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               19 { $AD19 = New-PSDrive -Name AD19 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               20 { $AD20 = New-PSDrive -Name AD20 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               21 { $AD21 = New-PSDrive -Name AD21 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               22 { $AD22 = New-PSDrive -Name AD22 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               23 { $AD23 = New-PSDrive -Name AD23 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               24 { $AD24 = New-PSDrive -Name AD24 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               25 { $AD25 = New-PSDrive -Name AD25 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               26 { $AD26 = New-PSDrive -Name AD26 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               27 { $AD27 = New-PSDrive -Name AD27 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               28 { $AD28 = New-PSDrive -Name AD28 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               29 { $AD29 = New-PSDrive -Name AD29 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               30 { $AD30 = New-PSDrive -Name AD30 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               31 { $AD31 = New-PSDrive -Name AD31 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               32 { $AD32 = New-PSDrive -Name AD32 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               33 { $AD33 = New-PSDrive -Name AD33 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               34 { $AD34 = New-PSDrive -Name AD34 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               35 { $AD35 = New-PSDrive -Name AD35 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               36 { $AD36 = New-PSDrive -Name AD36 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               37 { $AD37 = New-PSDrive -Name AD37 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               38 { $AD38 = New-PSDrive -Name AD38 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               39 { $AD39 = New-PSDrive -Name AD39 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               40 { $AD40 = New-PSDrive -Name AD40 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               41 { $AD41 = New-PSDrive -Name AD41 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               42 { $AD42 = New-PSDrive -Name AD42 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               43 { $AD43 = New-PSDrive -Name AD43 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               44 { $AD44 = New-PSDrive -Name AD44 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               45 { $AD45 = New-PSDrive -Name AD45 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               46 { $AD46 = New-PSDrive -Name AD46 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               47 { $AD47 = New-PSDrive -Name AD47 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               48 { $AD48 = New-PSDrive -Name AD48 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               49 { $AD49 = New-PSDrive -Name AD49 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               50 { $AD50 = New-PSDrive -Name AD50 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               51 { $AD51 = New-PSDrive -Name AD51 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               52 { $AD52 = New-PSDrive -Name AD52 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               53 { $AD53 = New-PSDrive -Name AD53 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               54 { $AD54 = New-PSDrive -Name AD54 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               55 { $AD55 = New-PSDrive -Name AD55 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               56 { $AD56 = New-PSDrive -Name AD56 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               57 { $AD57 = New-PSDrive -Name AD57 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               58 { $AD58 = New-PSDrive -Name AD58 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               59 { $AD59 = New-PSDrive -Name AD59 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               60 { $AD60 = New-PSDrive -Name AD60 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               61 { $AD61 = New-PSDrive -Name AD61 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               62 { $AD62 = New-PSDrive -Name AD62 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               63 { $AD63 = New-PSDrive -Name AD63 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               64 { $AD64 = New-PSDrive -Name AD64 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               65 { $AD65 = New-PSDrive -Name AD65 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               66 { $AD66 = New-PSDrive -Name AD66 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               67 { $AD67 = New-PSDrive -Name AD67 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               68 { $AD68 = New-PSDrive -Name AD68 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               69 { $AD69 = New-PSDrive -Name AD69 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               70 { $AD70 = New-PSDrive -Name AD70 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               71 { $AD71 = New-PSDrive -Name AD71 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               72 { $AD72 = New-PSDrive -Name AD72 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               73 { $AD73 = New-PSDrive -Name AD73 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               74 { $AD74 = New-PSDrive -Name AD74 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               75 { $AD75 = New-PSDrive -Name AD75 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               76 { $AD76 = New-PSDrive -Name AD76 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               77 { $AD77 = New-PSDrive -Name AD77 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               78 { $AD78 = New-PSDrive -Name AD78 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               79 { $AD79 = New-PSDrive -Name AD79 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               80 { $AD80 = New-PSDrive -Name AD80 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               81 { $AD81 = New-PSDrive -Name AD81 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               82 { $AD82 = New-PSDrive -Name AD82 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               83 { $AD83 = New-PSDrive -Name AD83 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               84 { $AD84 = New-PSDrive -Name AD84 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               85 { $AD85 = New-PSDrive -Name AD85 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               86 { $AD86 = New-PSDrive -Name AD86 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               87 { $AD87 = New-PSDrive -Name AD87 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               88 { $AD88 = New-PSDrive -Name AD88 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               89 { $AD89 = New-PSDrive -Name AD89 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               90 { $AD90 = New-PSDrive -Name AD90 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               91 { $AD91 = New-PSDrive -Name AD91 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                               92 { $AD92 = New-PSDrive -Name AD92 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               93 { $AD93 = New-PSDrive -Name AD93 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               94 { $AD94 = New-PSDrive -Name AD94 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               95 { $AD95 = New-PSDrive -Name AD95 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               96 { $AD96 = New-PSDrive -Name AD96 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               97 { $AD97 = New-PSDrive -Name AD97 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               98 { $AD98 = New-PSDrive -Name AD98 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                               99 { $AD99 = New-PSDrive -Name AD99 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                              100 { $AD100 = New-PSDrive -Name AD100 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }
                                              101 { $AD101 = New-PSDrive -Name AD101 -PSProvider ActiveDirectory -Server $TrustDC -root "//RootDSE/" }

                                            }

                                            $dicADDriveMapping.add($TrustDomainFQDN, $ADDriveNumber)

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    $ValidTrustCount = $dicTrustByFQDN.Count
    WriteLog "Number of valid trusts found: $ValidTrustCount" $true

}

#############################
### Lookup KrbTgt Account ###
#############################
Function LookupKrbTgtAccount
{
    WriteLog "Looking up KrbTgT account(s)." $true
    foreach ($Domain in $dicDomainFQDN.Keys)
    {
        $CurTargetDC = GetClosestDC $Domain

        $ADObject = GetADObject "KrbTgt" $CurTargetDC $Domain $false

        if ($ADObject)
        {
            $DN = $ADObject.DistinguishedName

            $Index = $DN.IndexOf(",")
            $Length = $DN.Length + 1
            $AppliedLength = $Length - ($Index+1)
            $Container = $DN.Substring($Index+1,$AppliedLength-1)

            if ($dicTier0Containers.ContainsKey($Container) -eq $false)
            {
                $dicTier0Containers.Add($Container,"container")
            }
            if ($dicTier0DistinguishedNames.ContainsKey($DN) -eq $false)
            {
                $dicTier0DistinguishedNames.Add($DN,"user")
            }
        }
    }

}

###########################################
### Read Tier 0 Member Servers CSV File ###
###########################################
Function ReadTier0MemberServersCSVFile
{

    $CheckFile = Test-Path $Tier0MemberServerFile -PathType Leaf
    WriteLog "CheckFile: $CheckFile"

    if ($CheckFile -eq $True)
    {
        WriteLog "Producing Tier 0 Member Server Group Membership File." $true
        WriteLog "Reading $Tier0MemberServerFile." $true
        $CSV = Import-Csv $Tier0MemberServerFile
        foreach ($Row in $CSV)
        {
            $MemberServer = $Row.Tier0MemberServerFQDN
            $MemberServerApplication = $Row.Application
            $MemberServerRole = $Row.Role

            WriteLog "MemberServer: $MemberServer"

            $Index = $MemberServer.IndexOf(".")
            $Length = $MemberServer.Length
            $AppliedLength = $Length - ($Index + 1)
            $MemberServerDomain = $MemberServer.Substring($Index+1,$AppliedLength)

            WriteLog "MemberServerDomain: $MemberServerDomain"

            if ($dicDomainDC.ContainsKey($MemberServerDomain) -eq $true)
            {
                $TargetDC = $dicDomainDC.$MemberServerDomain
                $TargetLDAP = $dicDomainLDAP.$MemberServerDomain
                WriteLog "TargetDC: $TargetDC"
                WriteLog "TargetLDAP: $TargetLDAP"
                Try
                {
                    $objMemberServer = Get-ADComputer -ldapfilter "(dNSHostname=$MemberServer)" -SearchBase $TargetLDAP -searchscope Subtree -Server "$TargetDC" -ErrorAction SilentlyContinue
                } Catch {

                }
                if ($objMemberServer) {
                    $MemberServerDistinguishedName = $objMemberServer.DistinguishedName
                    WriteLog "MemberServerDistinguishedName: $MemberServerDistinguishedName"

                    $Index = $MemberServerDistinguishedName.IndexOf(",")
                    $Length = $MemberServerDistinguishedName.Length
                    $AppliedLength = $Length - ($Index + 1)
                    $MemberServerContainer = $MemberServerDistinguishedName.Substring($Index+1,$AppliedLength)
                    WriteLog "MemberServerContainer: $MemberServerContainer"

                    if ($dicMemberServerDN.ContainsKey($MemberServerDistinguishedName) -eq $false) {
                        $dicMemberServerDN.Add($MemberServerDistinguishedName,$MemberServer)
                    }
                    if ($dicTier0Containers.ContainsKey($MemberServerContainer) -eq $false) {
                        $dicTier0Containers.Add($MemberServerContainer,"container")
                    }
                    if ($dicTier0DistinguishedNames.ContainsKey($MemberServerDistinguishedName) -eq $false) {
                        $dicTier0DistinguishedNames.Add($MemberServerDistinguishedName,"computer")
                    }
                    if ($dicMemberServerFQDN.ContainsKey($MemberServer) -eq $false) {
                        $dicMemberServerFQDN.Add($MemberServer,$MemberServerDistinguishedName)
                    }
                    if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $false) {
                        $dicMemberServerApplication.Add($MemberServerDistinguishedName,$MemberServerApplication)
                    }
                    if ($dicMemberServerRole.ContainsKey($MemberServerDistinguishedName) -eq $false) {
                        $dicMemberServerRole.Add($MemberServerDistinguishedName,$MemberServerRole)
                    }
                }
            }
        }
    }
}


#################################################
### Get Tier 0 Member Server Group Membership ###
#################################################
Function GetTier0MemberServerGroupMembership
{

    if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.Count -gt 0)
    {
        WriteLog "Reading $LocalGroupSIDsToFilterOutFile" $true
        $CSV = Import-Csv $LocalGroupSIDsToFilterOutFile
        foreach ($Row in $CSV)
        {
            $GroupName = $Row.GroupName
            $GroupSID = $Row.GroupSID   
            $dicExcludedGroups.Add($GroupSID,$GroupName)
            WriteLog "ExcludedSIDs: $GroupSID"
        }

        if ($DistDataFolder.IsPresent -eq $true) 
        {
            foreach ($CSVFile in $LocalGroupFiles)
            {

                $CSVFilename = $CSVFile.Name
                $Index = $CSVFilename.IndexOf("-")
                $Length = $CSVFilename.Length
                $AppliedLength = $Length - ($Index + 1)
                $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

                $Index1 = $ServerName.IndexOf(".")
                $Index2 = $ServerName.LastIndexOf(".")
                $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

                $Length = $ServerName.Length
                $ServerName = $ServerName.Substring(0,($Length-4))

                if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
                {
                    if ($dicDcFQDN.ContainsKey($ServerName) -eq $true -or $dicMemberServerFQDN.ContainsKey($ServerName) -eq $true -or $IncludeAllServers.IsPresent -eq $true)
                    {

                        WriteLog "Reading $CSVFile" $true
                        $CSV = Import-Csv $CSVFile
                        foreach ($Row in $CSV) 
                        {
                            $CurServerFqdn = $Row.ServerFqdn
                            $MemberSID = $Row.MemberSID
                            $LocalGroupSID = $Row.LocalGroupSID
                            $LocalGroupName = $Row.LocalGroupName

                            $MemberState = ""
                            $MemberUserAccountControl = ""

                            $Index = $CurServerFQDN.IndexOf(".")
                            $Length = $CurServerFQDN.Length
                            $AppliedLength = $Length - ($Index + 1)
                            $CurServerDomain = $CurServerFQDN.Substring($Index+1,$AppliedLength)
                            $CurServerSamAccountName = $CurServerFQDN.Substring(0,$Index) + "$"

                            $CurTargetDC = $dicDomainDC.$CurServerDomain

                            $ADObject = GetADObject $CurServerSamAccountName $CurTargetDC $CurServerDomain $false
                            if ($ADObject)
                            {
                                $MemberServerDistinguishedName = $ADObject.DistinguishedName
                                if ($MemberServerDistinguishedName)
                                {
                                    if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                                    {
                                        $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                        $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                                    } else {
                                        $MemberServerApplication = "n/a"
                                        $MemberServerRole = "n/a"
                                    }
                                } else {
                                    $MemberServerApplication = "n/a"
                                    $MemberServerRole = "n/a"
                                }


                                $Index = $MemberServerDistinguishedName.IndexOf(",")
                                $Length = $MemberServerDistinguishedName.Length
                                $AppliedLength = $Length - ($Index + 1)
                                $MemberServerContainer = $MemberServerDistinguishedName.Substring($Index+1,$AppliedLength)

                                WriteLog "CurServerFqdn: $CurServerFqdn"
                                WriteLog "CurServerSamAccountName: $CurServerSamAccountName"
                                WriteLog "CurTargetDC: $CurTargetDC"
                                WriteLog "MemberServerDistinguishedName: $MemberServerDistinguishedName"
                                WriteLog "MemberServerContainer: $MemberServerContainer"

                                $ADObject = GetADObject $MemberSID $CurTargetDC $CurServerDomain $false

                                $MemberDistinguishedName = $ADObject.DistinguishedName

                                if ($MemberDistinguishedName -ne "" -and $MemberDistinguishedName -ne $null)
                                {

                                    $MemberName = $ADObject.Name
                                    $MemberSamAccountName = $ADObject.SamAccountName
                    
                                    $Index = $MemberDistinguishedName.IndexOf("DC=")
                                    $Length = $MemberDistinguishedName.Length + 1
                                    $AppliedLength = $Length - ($Index+1)
                                    $TargetDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                                    $MemberDomain = $TargetDomainDN -replace ",DC=", "."
                                    $MemberDomain = $MemberDomain -replace "DC=", ""

                                    $MemberObjectClass = $ADObject.ObjectClass

                                    $Index = $MemberDistinguishedName.IndexOf("=",3) - 2
                                    $Length = $MemberDistinguishedName.Length
                                    $AppliedLength = $Length - ($Index)
                                    $MemberContainer = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                                    $MemberUserAccountControl = $ADObject.UserAccountControl

                                    if (($MemberUserAccountControl -band 2) -ne 2) {
                                        $MemberState = "Enabled"
                                    } else {
                                        $MemberState = "Disabled"
                                    }


                                    WriteLog "CurMemberSID: $CurMemberSID"
                                    WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                                    WriteLog "MemberName: $MemberName"
                                    WriteLog "MemberSamAccountName: $MemberSamAccountName"
                                    WriteLog "MemberDomain: $MemberDomain"
                                    WriteLog "MemberObjectClass: $MemberObjectClass"
                                    WriteLog "MemberSID: $MemberSID"
                                    WriteLog "MemberContainer: $MemberContainer"
                                    WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                                    WriteLog "MemberState: $MemberState"
                                    WriteLog "LocalGroupName: $LocalGroupName"
                                    WriteLog "LocalGroupSID: $LocalGroupSID"

                                    if ($dicExcludedGroups.ContainsKey($LocalGroupSID) -eq $False)
                                    {

                                        if ($dicMemberDNs.ContainsKey($MemberDistinguishedName) -eq $false)
                                        {
                                            $dicMemberDNs.Add($MemberDistinguishedName,"")

                                            if ($dicMemberState.ContainsKey($MemberDistinguishedName) -eq $false)
                                            {
                                                $dicMemberState.Add($MemberDistinguishedName,$MemberState)
                                            }
                                            if ($dicMemberUAC.ContainsKey($MemberDistinguishedName) -eq $false)
                                            {
                                                $dicMemberUAC.Add($MemberDistinguishedName,$MemberUserAccountControl)
                                            }

                                        }

                                        $LineOut = '"' + $CurServerFqdn + '",'`
                                                    + '"' + $MemberServerDistinguishedName  + '",'`
                                                    + '"' + $MemberServerContainer  + '",'`
                                                    + '"' + $LocalGroupName  + '",'`
                                                    + '"' + $LocalGroupSID  + '",'`
                                                    + '"' + $MemberName  + '",'`
                                                    + '"' + $MemberSamAccountName  + '",'`
                                                    + '"' + $MemberDomain  + '",'`
                                                    + '"' + $MemberObjectClass  + '",'`
                                                    + '"' + $MemberDistinguishedName  + '",'`
                                                    + '"' + $MemberSID  + '",'`
                                                    + '"' + $MemberContainer  + '",'`
                                                    + '"' + $MemberState  + '",'`
                                                    + '"' + $MemberUserAccountControl  + '",'`
                                                    + '"Explicit",'`
                                                    + '"' + $MemberServerApplication  + '",'`
                                                    + '"' + $MemberServerRole  + '"'


                                        $DisplayKey = $CurServerFqdn + $MemberDistinguishedName + $LocalGroupName
                                        if ($dicOutputDNs.ContainsKey($DisplayKey) -eq $false)
                                        {
                                            $dicOutputDNs.add($DisplayKey,"")

                                            if ($dicMemberServerFQDN.ContainsKey($CurServerFqdn) -eq $true)
                                            {
                                                Add-Content -Path $Tier0MemberServerGroupMembershipFile -Value $LineOut -Encoding Unicode
                                            }

                                            Add-Content -Path $AllServerGroupMembershipFile -Value $LineOut -Encoding Unicode
                                        }

                                        $Index = $MemberSID.LastIndexOf("-")
                                        $Length = $MemberSID.Length + 1
                                        $AppliedLength = $Length - ($Index+1)
                                        $MemberRID = $MemberSID.Substring($Index+1,$AppliedLength-1)

                                        $Index = $LocalGroupSID.LastIndexOf("-")
                                        $Length = $LocalGroupSID.Length + 1
                                        $AppliedLength = $Length - ($Index+1)
                                        $GroupRID = $LocalGroupSID.Substring($Index+1,$AppliedLength-1)

                                        if ($dicTier0SIDs.ContainsKey($MemberSID) -eq $false -and $dicMemberServerFQDN.ContainsKey($CurServerFqdn) -eq $true)
                                        {
                                            $dicTier0SIDs.Add($MemberSID,$MemberRID)
                                            $dicTier0IdentitiesBySID.Add($MemberSID,$MemberSamAccountName)
                                        }
                                        if ($dicTier0SIDs.ContainsKey($LocalGroupSID) -eq $false -and $dicMemberServerFQDN.ContainsKey($CurServerFqdn) -eq $true)
                                        {
                                            $dicTier0SIDs.Add($LocalGroupSID,$GroupRID)
                                            $dicTier0IdentitiesBySID.Add($LocalGroupSID,$LocalGroupName)
                                        }

                                        if ($dicTier0Containers.ContainsKey($MemberContainer) -eq $false -and $dicMemberServerFQDN.ContainsKey($CurServerFqdn) -eq $true)
                                        {
                                            $dicTier0Containers.Add($MemberContainer,"container")
                                        }
                                        if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false -and $dicMemberServerFQDN.ContainsKey($CurServerFqdn) -eq $true)
                                        {
                                            $dicTier0DistinguishedNames.Add($MemberDistinguishedName,$MemberObjectClass)
                                        }

                                        #Get Nested Membership
                                        if ($MemberObjectClass -eq "group")
                                        {
                                            $TargetDC = $dicDomainDC.$MemberDomain
                                            $TargetLDAP = $dicDomainLDAP.$MemberDomain

                                            $dicMemberDNs.Clear()
                                            GetNestedMembers2 $MemberDistinguishedName $Tier0MemberServerGroupMembershipFile $CurServerFqdn $MemberServerDistinguishedName $MemberServerContainer $LocalGroupName $LocalGroupSID
                        
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    WriteLog "Done.  File written to $Tier0MemberServerGroupMembershipFile." $true


}

####################################
### Read Tier 0 Group Membership ###
####################################
Function ReadTier0WellKnownGroupMembership
{

    WriteLog "Reading $Tier0GroupsFile." $true
    $CSV = Import-Csv $Tier0GroupsFile
    foreach ($Row in $CSV) 
    {
        $MemberContainer = $Row.MemberContainer
        $MemberDistinguishedName = $Row.MemberDistinguishedName
        $MemberObjectClass = $Row.MemberObjectClass
        $MemberSID = [String]$Row.MemberSID
        $MemberSamAccountName = $Row.MemberSamAccountName

        $GroupContainer = $Row.GroupContainer
        $GroupDistinguishedName = $Row.GroupDistinguishedName
        $GroupSID = [String]$Row.GroupSID
        $GroupSamAccountName = $Row.GroupSamAccountName
        $IsTier0CustomGroup = $Row.IsTier0CustomGroup

        $Index = $MemberSID.LastIndexOf("-")
        $Length = $MemberSID.Length + 1
        $AppliedLength = $Length - ($Index+1)
        $MemberRID = $MemberSID.Substring($Index+1,$AppliedLength-1)

        $Index = $GroupSID.LastIndexOf("-")
        $Length = $GroupSID.Length + 1
        $AppliedLength = $Length - ($Index+1)
        $GroupRID = $GroupSID.Substring($Index+1,$AppliedLength-1)

        if ($dicTier0SIDs.ContainsKey($MemberSID) -eq $false)
        {
            $dicTier0SIDs.Add($MemberSID,$MemberRID)
            $dicTier0IdentitiesBySID.Add($MemberSID,$MemberSamAccountName)
        }
        if ($dicTier0SIDs.ContainsKey($GroupSID) -eq $false)
        {
            $dicTier0SIDs.Add($GroupSID,$GroupRID)
            $dicTier0IdentitiesBySID.Add($GroupSID,$GroupSamAccountName)
        }

        WriteLog "MemberContainer: $MemberContainer"
        WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
        WriteLog "GroupContainer: $GroupContainer"
        WriteLog "GroupDistinguishedName: $GroupDistinguishedName"


        if ($dicTier0Containers.ContainsKey($MemberContainer) -eq $false)
        {
            $dicTier0Containers.Add($MemberContainer,"container")
        }
        if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false)
        {
            $dicTier0DistinguishedNames.Add($MemberDistinguishedName,$MemberObjectClass)
        }
        if ($dicTier0Containers.ContainsKey($GroupContainer) -eq $false)
        {
            $dicTier0Containers.Add($GroupContainer,"container")
        }
        if ($dicTier0DistinguishedNames.ContainsKey($GroupDistinguishedName) -eq $false)
        {
            $dicTier0DistinguishedNames.Add($GroupDistinguishedName,"group")
        }
        if ($dicIsTier0CustomGroup.ContainsKey($GroupDistinguishedName) -eq $false)
        {
            $dicIsTier0CustomGroup.Add($GroupDistinguishedName,$IsTier0CustomGroup)
        }

    }
}

############################
### Read Tier 0 URA File ###
############################
Function ReadTier0URAFile
{

    WriteLog "Reading $Tier0URAFile." $true
    $CSV = Import-Csv $Tier0URAFile
    foreach ($Row in $CSV) 
    {
        $MemberContainer = $Row.MemberContainer
        $MemberDistinguishedName = $Row.DistinguishedName
        $MemberObjectClass = $Row.MemberObjectClass
        $MemberSID = [String]$Row.SID
        $MemberSamAccountName = $Row.SamAccountName
        $ServerContainer = $Row.ServerContainer
        $ServerDistinguishedName = $Row.ServerDistinguishedName

        $Index = $MemberSID.LastIndexOf("-")
        $Length = $MemberSID.Length + 1
        $AppliedLength = $Length - ($Index+1)
        $MemberRID = $MemberSID.Substring($Index+1,$AppliedLength-1)

        if ($dicTier0SIDs.ContainsKey($MemberSID) -eq $false)
        {
            $dicTier0SIDs.Add($MemberSID,$MemberRID)
            $dicTier0IdentitiesBySID.Add($MemberSID,$MemberSamAccountName)
        }

        WriteLog "MemberContainer: $MemberContainer"
        WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
        WriteLog "ServerContainer: $ServerContainer"
        WriteLog "ServerDistinguishedName: $ServerDistinguishedName"

        if ($dicTier0Containers.ContainsKey($MemberContainer) -eq $false)
        {
            $dicTier0Containers.Add($MemberContainer,"container")
        }
        if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false)
        {
            $dicTier0DistinguishedNames.Add($MemberDistinguishedName,$MemberObjectClass)
        }
        if ($dicTier0Containers.ContainsKey($ServerContainer) -eq $false)
        {
            $dicTier0Containers.Add($ServerContainer,"container")
        }
        if ($dicTier0DistinguishedNames.ContainsKey($ServerDistinguishedName) -eq $false)
        {
            $dicTier0DistinguishedNames.Add($ServerDistinguishedName,"computer")
        }
    }
}

#################################
### Read Tier 0 Group DN File ###
#################################
Function ReadTier0GroupDNFile
{
    WriteLog "Reading $Tier0GroupsDNsFile." $true
    $CSV = Import-Csv $Tier0GroupsDNsFile
    foreach ($Row in $CSV) 
    {
        $GroupDN = $Row.Tier0GroupDistinguishedName
        if ($dicTier0DistinguishedNames.ContainsKey($GroupDN) -eq $false)
        {
            $dicTier0DistinguishedNames.Add($GroupDN,$MemberObjectClass)
        }
    }
}

######################################
### Read Tier 0 Custom Groups File ###
######################################
Function ReadTier0CustomGroups
{
    WriteLog "Reading $Tier0CustomGroupsFile." $true
    $CSV = Import-Csv $Tier0CustomGroupsFile
    foreach ($Row in $CSV) 
    {
        $GroupDN = $Row.Tier0CustomGroupDistinguishedName
        if ($dicIsTier0CustomGroup.ContainsKey($GroupDN) -eq $false)
        {
            $dicIsTier0CustomGroup.Add($GroupDN,"True")
        }
    }
}


###########################
### Query Schema Rights ###
###########################
Function QuerySchemaRights
{
    WriteLog "Getting Schema Objects." $true
    $GUIDs = Get-ADObject -SearchBase (Get-ADRootDSE).schemaNamingContext -LDAPFilter '(schemaIDGUID=*)' -Properties name, schemaIDGUID -ErrorAction SilentlyContinue
    Foreach ($GUID in $GUIDs)
    {
        $name = $GUID.name
        $schemaGUID = [System.GUID]$GUID.schemaIDGUID
        $schemaIDGUID.Add($SchemaGUID,$name)
    }

    $AccessRights = Get-ADObject -SearchBase "CN=Extended-Rights,$((Get-ADRootDSE).configurationNamingContext)" -LDAPFilter '(objectClass=controlAccessRight)' -Properties name, rightsGUID -ErrorAction SilentlyContinue
    foreach ($Right in $AccessRights)
    {
        $RightName = $Right.name
        $RightGUID = [System.GUID]$Right.rightsGUID
        if ($schemaIDGUID.ContainsKey($RightGUID) -eq $false)
        {
            $schemaIDGUID.Add($RightGUID,$RightName)
        }
    }
    $AllGUID = [System.GUID]"00000000-0000-0000-0000-000000000000"
    $schemaIDGUID.Add($AllGUID,"All")

    $GUIDCount = $schemaIDGUID.Count
    WriteLog "GUIDCount: $GUIDCount" $true
}

#############################################
### Write Tier 0 Distinguished Names File ###
#############################################
Function WriteTier0DistinguishedNamesFile
{
    WriteLog "Writing $Tier0DistinguishedNamesFile File." $true
    foreach ($Key in $dicTier0DistinguishedNames.keys)
    {
        $CurDistinguishedName=$Key
        $LineOut = '"' + $CurDistinguishedName  + '"'
        Add-Content -Path $Tier0DistinguishedNamesFile -Value $LineOut -Encoding Unicode
    }
}

####################################
### Write Tier 0 Containers File ###
####################################
Function WriteTier0ContainersFile
{
    WriteLog "Writing $Tier0ContainerDistinguishedNamesFile File." $true
    foreach ($Key in $dicTier0Containers.keys)
    {
        $CurDistinguishedName=$Key
        $LineOut = '"' + $CurDistinguishedName  + '"'
        Add-Content -Path $Tier0ContainerDistinguishedNamesFile -Value $LineOut -Encoding Unicode
    }
}

####################################################
### Get Tier 0 Security Principal AD Permissions ###
####################################################
Function GetTier0SecurityPrincipalADPermissions
{
    WriteLog "Getting Tier 0 Security Principal AD Permissions." $true
    Foreach ($Tier0DN in $dicTier0DistinguishedNames.Keys)
    {
        GetADACL $Tier0DN $Tier0SecurityPrincipalPermissionsFile $false

        if ($CurObjectClass -eq "computer")
        {
            $BitlockerDN = "cn=ms-FVE-RecoveryInformation,$Tier0DN"
            GetADACL $BitlockerDN $Tier0SecurityPrincipalPermissionsFile $true
        }
    }
    CombineCSVFiles $Tier0SecurityPrincipalPermissionsFile
}


########################################
### Get Tier 0 Container Permissions ###
########################################
Function GetTier0ContainerPermissions
{
    WriteLog "Getting Tier 0 Container AD Permissions." $true
    $Global:ObjectCount = 0
    Foreach ($Tier0DN in $dicTier0Containers.Keys)
    {
        GetADACL $Tier0DN $Tier0ContainerPermissionsFile $false
    }
    CombineCSVFiles $Tier0ContainerPermissionsFile
}


##########################################
### Get Tier 0 Domain Root Permissions ###
##########################################
Function GetTier0DomainRootPermissions
{
    WriteLog "Getting Tier 0 Domain Root AD Permissions." $true
    $Global:ObjectCount = 0
    $dicTempDomainLDAP = $dicDomainLDAP

    foreach ($Key in $dicTempDomainLDAP.keys)
    {
        if ($CollectionMode -eq "Forest" -or $DomainName -eq $Key -or $MasterRootDomain -eq $Key)
        {
            $Tier0DN = $dicTempDomainLDAP.$Key
            GetADACL $Tier0DN $Tier0DomainRootPermissionsFile $false
        }
    }
    $dicDomainLDAP = $dicTempDomainLDAP
    CombineCSVFiles $Tier0DomainRootPermissionsFile
}


############################################
### Get Tier 0 AdminSDHolder Permissions ###
############################################
Function GetTier0AdminSDHolderPermissions
{
    WriteLog "Getting Tier 0 Admin SD Holder Permissions." $true
    $Global:ObjectCount = 0
    foreach ($Key in $dicDomainLDAP.keys)
    {
        if ($CollectionMode -eq "Forest" -or $DomainName -eq $Key -or $MasterRootDomain -eq $Key)
        {
            $Tier0DN = $dicDomainLDAP.$Key
            $Tier0DN = "CN=AdminSDHolder,CN=System,$Tier0DN"
            GetADACL $Tier0DN $Tier0AdminSDHolderPermissionsFile $false
        }
    }
    CombineCSVFiles $Tier0AdminSDHolderPermissionsFile
}


###########################################################
### Get Tier 0 Configuration Naming Context Permissions ###
###########################################################
Function GetTier0ConfigurationNamingContextPermissions
{
    if ($SkipConfigAndSchema.IsPresent -eq $false) 
    {
        WriteLog "Getting Tier 0 Configuration Naming Context Permissions." $true
        $Global:ObjectCount = 0
        $Tier0DN = $ConfigPartition
        $CurObjectClass="container"
        GetADACL $Tier0DN $Tier0ConfigurationNCPermissionsFile $false "Config"

        $RootDSE = Get-ADRootDSE -erroraction SilentlyContinue
        $ConfigPartition = $RootDSE.configurationNamingContext
        $SchemaPartition = $RootDSE.schemaNamingContext
        $TargetObj = "CN=Sites,$ConfigPartition"
        Try
        {
            $Sites = Get-ADObject -Filter * -SearchBase $TargetObj -Properties DistinguishedName -erroraction SilentlyContinue
        } Catch {

        }
        foreach ($Site in $Sites)
        {
            $Tier0DN = $Site.DistinguishedName
            GetADACL $Tier0DN $Tier0ConfigurationNCPermissionsFile $false "Config"
        }

        $TargetObj = "CN=Services,$ConfigPartition"
        Try
        {
            $Services = Get-ADObject -Filter * -SearchBase $TargetObj -Properties DistinguishedName -ErrorAction SilentlyContinue
        } Catch {

        }
        foreach ($Service in $Services)
        {
            $Tier0DN = $Service.DistinguishedName
            GetADACL $Tier0DN $Tier0ConfigurationNCPermissionsFile $false "Config"
        }
        CombineCSVFiles $Tier0ConfigurationNCPermissionsFile
    }
}

####################################################
### Get Tier 0 Schema Naming Context Permissions ###
####################################################
Function GetTier0SchemaNamingContextPermissions
{

    if ($SkipConfigAndSchema.IsPresent -eq $false) 
    {
        WriteLog "Getting Tier 0 Schema Naming Context Permissions." $true
        $Global:ObjectCount = 0
        $TargetObj = $SchemaPartition
        Try
        {
            $SchemaDNs = Get-ADObject -Filter * -SearchBase $TargetObj -Properties DistinguishedName -ErrorAction SilentlyContinue
        } Catch {

        }
        foreach ($SchemaDN in $SchemaDNs)
        {
            $Tier0DN = $SchemaDN.DistinguishedName
            GetADACL $Tier0DN $Tier0SchemaNCPermissionsFile $false "Schema"
        }
        CombineCSVFiles $Tier0SchemaNCPermissionsFile
    }


}

###########################################
### Get GPOs Linked To Tier 0 Container ###
###########################################
Function GetGPOsLinkedToTier0Containers
{

    WriteLog "Getting GPOs linked to Tier 0 Containers." $true
    foreach ($container in $dicTier0Containers.Keys)
    {
        $TargetContainer = $container
        WriteLog "TargetContainer: $TargetContainer"
        if ($dicTargetContainers.ContainsKey($TargetContainer) -eq $false)
        {
            $dicTargetContainers.Add($TargetContainer,"")
        }
        $Done = $false
        Do
        {
            if ($TargetContainer.Substring(0,3) -eq "DC=")
            {
                $Done = $true
            } else {
                $Index = $TargetContainer.IndexOf(",OU=")
                if ($Index -eq -1) {$Index = $TargetContainer.IndexOf(",CN=")}
                if ($Index -eq -1) {$Index = $TargetContainer.IndexOf(",DC=")}
                $Length = $TargetContainer.Length
                $AppliedLength = $Length - ($Index + 1)
                $SubContainer = $TargetContainer.Substring($Index+1,$AppliedLength)
                WriteLog "SubContainer: $SubContainer"
                if ($dicTargetContainers.ContainsKey($SubContainer) -eq $false)
                {
                    $dicTargetContainers.Add($SubContainer,"")
                }
                $TargetContainer = $SubContainer
            }
        } while ($Done -eq $false)
    }
    foreach ($container in $dicTargetContainers.Keys)
    {
        if ($container -ne "" -and $container -ne $null)
        {
            $TargetContainer = $container
            $Index = $TargetContainer.IndexOf("DC=")
            $Length = $TargetContainer.Length + 1
            $AppliedLength = $Length - ($Index+1)
            $MemberDomainDN = $TargetContainer.Substring($Index,$AppliedLength)

            $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
            $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

            $TargetDC = $dicDomainDC.$MemberDomainFQDN
            $TargetLDAP = $dicDomainLDAP.$MemberDomainFQDN

            Try
            {
                $TargetContainer2 = EscapeSpecialCharacters $TargetContainer
                $objContainer = Get-ADObject -filter "DistinguishedName -eq '$TargetContainer2'" -server $TargetDC -Properties gpLink -ErrorAction SilentlyContinue
            } Catch {

            }
            $gpLink = $objContainer.gpLink
            if ($gpLink -ne $null)
            {
                WriteLog "gpLink: $gpLink"
                $Done = $false
                do
                {
                    $gpLink = $gpLink.Tostring()
                    $Index = $gpLink.IndexOf("]")
                    if ($Index -eq -1) 
                    {
                        $Done = $true
                    } else {
                        $Length = $gpLink.Length
                        $AppliedLength = $Length - ($Index + 1)
                        $TargetDN = $gpLink.Substring(0,$Index + 1)
                        $gpLink = $gpLink.Substring(($Index +1),$AppliedLength)

                        $Index = $TargetDN.IndexOf(";")
                        $Length = $TargetDN.Length
                        $TargetDN = $TargetDN.Substring(0,$Index)
                        $Length = $TargetDN.Length
                        $TargetDN = $TargetDN.Substring(8, $Length - 8)
                        WriteLog "TargetDN: $TargetDN"
                        if ($dicTier0GPOs.ContainsKey($TargetDN) -eq $false)
                        {
                            $dicTier0GPOs.Add($TargetDN,$TargetContainer2)
                        } else {
                            $Payload = $dicTier0GPOs.$TargetDN
                            $dicTier0GPOs.$TargetDN = $Payload + " " + $TargetContainer2
                        }
                    }

                } while ($Done -eq $false)
            }
        }
    }
    $objContainer = ""

    # Get GPOs link to all AD Sites
    WriteLog "Getting GPOs linked to Sites." $true
    $RootDSE = Get-ADRootDSE -ErrorAction SilentlyContinue
    $ConfigPartition = $RootDSE.configurationNamingContext
    $TargetObj = "CN=Sites,$ConfigPartition"
    Try
    {
        $Sites = Get-ADObject -Filter * -SearchBase $TargetObj -Properties DistinguishedName -SearchScope OneLevel -erroraction SilentlyContinue
    } Catch {

    }
    foreach ($Site in $Sites)
    {
        $TargetContainer = $Site.DistinguishedName

        $Index = $TargetContainer.IndexOf("DC=")
        $Length = $TargetContainer.Length + 1
        $AppliedLength = $Length - ($Index+1)
        $MemberDomainDN = $TargetContainer.Substring($Index,$AppliedLength)

        $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
        $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

        $TargetDC = $dicDomainDC.$MemberDomainFQDN
        $TargetLDAP = $dicDomainLDAP.$MemberDomainFQDN

        Try
        {
            $TargetContainer2 = EscapeSpecialCharacters $TargetContainer
            $objContainer = get-adobject -Searchbase "$ConfigPartition" -Filter "DistinguishedName -eq '$TargetContainer2'" -server $TargetDC -Properties gPLink -ErrorAction SilentlyContinue
        } Catch {

        }
        $gpLink = $objContainer.gPLink
        if ($gpLink -ne $null)
        {
            $Done = $false
            do
            {
                $gpLink = $gpLink.Tostring()
                $Index = $gpLink.IndexOf("]")
                if ($Index -eq -1) 
                {
                    $Done = $true
                } else {
                    $Length = $gpLink.Length
                    $AppliedLength = $Length - ($Index + 1)
                    $TargetDN = $gpLink.Substring(0,$Index + 1)
                    $gpLink = $gpLink.Substring(($Index +1),$AppliedLength)

                    $Index = $TargetDN.IndexOf(";")
                    $Length = $TargetDN.Length
                    $TargetDN = $TargetDN.Substring(0,$Index)
                    $Length = $TargetDN.Length
                    $TargetDN = $TargetDN.Substring(8, $Length - 8)
                    WriteLog "TargetDN: $TargetDN"
                    if ($dicTier0GPOs.ContainsKey($TargetDN) -eq $false)
                    {
                        $dicTier0GPOs.Add($TargetDN,$TargetContainer2)
                    } else {
                            $Payload = $dicTier0GPOs.$TargetDN
                            $dicTier0GPOs.$TargetDN = $Payload + " " + $TargetContainer2
                    }
                }

            } while ($Done -eq $false)
        }
    }



    foreach ($TargetDN in $dicTier0GPOs.keys)
    {
        $Index = $TargetDN.IndexOf("DC=")
        $Length = $TargetDN.Length + 1
        $AppliedLength = $Length - ($Index+1)
        $TargetDomainDN = $TargetDN.Substring($Index,$AppliedLength)

        $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
        $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""
        $MemberDomain = $TargetDomainFQDN
        $TargetDomainNetBIOSName = $dicDomainNetBIOSNameByDomain.$TargetDomainFQDN
    
        $TargetDC = $dicDomainDC.$TargetDomainFQDN
        $TargetLDAP = $dicDomainLDAP.$TargetDomainFQDN

        $RootDSE = Get-ADRootDSE -Server $TargetDC -ErrorAction SilentlyContinue
        $RootDomain = $RootDSE.rootDomainNamingContext
        $ConfigPartition = $RootDSE.configurationNamingContext
        $DefaultNamingContext = $RootDSE.defaultNamingContext
        $SchemaPartition = $RootDSE.schemaNamingContext

        if ($TargetNC -eq $null -or $TargetNC -eq "Domain")
        {
            $TargetNC = $DefaultNamingContext
        }
        if ($TargetNC -eq "Config")
        {
            $TargetNC = $ConfigPartition
        }
        if ($TargetNC -eq "Schema")
        {
            $TargetNC = $SchemaPartition
        }
        $obj = $null

        $Index = $TargetDN.IndexOf(",OU=")
        if ($Index -eq -1) {$Index = $TargetDN.IndexOf(",CN=")}
        if ($Index -eq -1) {$Index = $TargetDN.IndexOf(",DC=")}
        $Length = $TargetDN.Length
        $AppliedLength = $Length - ($Index + 1)
        $Container = $TargetDN.Substring($Index+1,$AppliedLength)

        Try
        {
            $TargetDN2 = EscapeSpecialCharacters $TargetDN
            $obj = Get-ADObject -filter "DistinguishedName -eq '$TargetDN2'" -server $TargetDC -Properties * -erroraction SilentlyContinue
        } Catch {

        }
        if ($obj)
        {
            $WhenChanged = $obj.WhenChanged
            $WhenCreated = $obj.WhenCreated
            $DisplayName = $obj.DisplayName

            $dicGPOName.add($TargetDN2,$DisplayName)
            $dicGPOWhenChanged.add($TargetDN2,$WhenChanged)
            $dicGPOWhenCreated.add($TargetDN2,$WhenCreated)
        }

        $LineOut = '"' + $TargetDN  + '",'`
                 + '"' + $dicGPOName.$TargetDN + '",'`
                 + '"' + $dicGPOWhenChanged.$TargetDN + '",'`
                 + '"' + $dicGPOWhenCreated.$TargetDN + '",'`
                 + '"' + $dicTier0GPOs.$TargetDN + '"'

        Add-Content -Path $Tier0GPOsFile -Value $LineOut -Encoding Unicode
    }
}


##################################
### Get Tier 0 GPO Permissions ###
##################################
Function GetTier0GPOPermissions
{
        
    WriteLog "Getting Tier 0 GPO Permissions." $true
    $Global:ObjectCount = 0
    Foreach ($Tier0DN in $dicTier0GPOs.Keys)
    {
        GetADACL $Tier0DN $Tier0GPOPermissionsFile $false $null "GPO"
    }
    CombineCSVFiles $Tier0GPOPermissionsFile

}

################################
### Get Non-Tier0 AdminCount ###
################################
Function GetNonTier0AdminCount
{
    WriteLog "Getting all Non Tier-0 Objects with AdminCount greater than 0." $true
    foreach ($Key in $dicDomainDC.Keys)
    {
        if ($CollectionMode -eq "Forest" -or $DomainName -eq $Key -or $MasterRootDomain -eq $Key)
        {
            $TargetDC = $dicDomainDC.$Key
            Try
            {
                $Objects = get-adObject -Filter "admincount -gt 0" -Properties adminCount, DistinguishedName, ObjectClass, LastLogonTimestamp, PwdLastSet, ObjectSID -ResultSetSize $null -Server $TargetDC -ErrorAction SilentlyContinue
            } Catch {

            }
    
            foreach ($obj in $Objects)
            {
                $CurDistinguishedName = $obj.DistinguishedName
                $CurAdminCount = $obj.AdminCount
                $CurObjectClass = $obj.ObjectClass
                $CurLastLogonTimestamp = $obj.LastLogonTimestamp
                $CurPwdLastSet = $obj.PwdLastSet
                $CurLastLogonTimestamp = [DateTime]::FromFileTimeutc($CurLastLogonTimestamp)
                $CurPasswordLastSet = [DateTime]::FromFileTimeutc($CurPwdLastSet)
                $CurSID = [String]$obj.ObjectSID

                $Index = $CurDistinguishedName.IndexOf("DC=")
                $Length = $CurDistinguishedName.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $MemberDomainDN = $CurDistinguishedName.Substring($Index,$AppliedLength)
                $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                $Index = $CurSID.LastIndexOf("-")
                $Length = $CurSID.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $CurrentRID = $CurSID.Substring($Index+1,$AppliedLength-1)
                $RidFound = $false
                $Tier0Object = ""

                if ($dicTier0RIDs.ContainsKey($CurrentRID) -eq $true)
                {
                    $RIDFound = $true
                    $Tier0Object = $dicTier0RIDs.$CurrentRID
                } 
                if ($dicTier0SIDs.ContainsKey($CurSID) -eq $true)
                {
                    $RIDFound = $true
                    $Tier0Object = $dicTier0IdentitiesBySID.$CurSID
                }
                $Reason = "Non-Tier 0 Identity With Non-Default Admincount value"

                if ($dicTier0DistinguishedNames.ContainsKey($CurDistinguishedName) -eq $false -and $RidFound -eq $false)
                {
                    $LineOut = '"' + $CurDistinguishedName + '",'`
                                + '"' + $MemberDomainFQDN  + '",'`
                                + '"' + $CurObjectClass  + '",'`
                                + '"' + $CurAdminCount  + '",'`
                                + '"' + $CurLastLogonTimestamp  + '",'`
                                + '"' + $CurPasswordLastSet  + '",'`
                                + '"' + $CurSID  + '",'`
                                + '"' + $Reason  + '"'

                    Add-Content -Path $NonTier0AdminCountFile -Value $LineOut -Encoding Unicode

                }
            }
        }
    }
}


####################################
### Get Objects With SID History ###
####################################
Function GetObjectsWithSIDHistory
{
    WriteLog "Getting all Objects with SID History." $true
    foreach ($Key in $dicDomainDC.Keys)
    {
        if ($CollectionMode -eq "Forest" -or $DomainName -eq $Key -or $MasterRootDomain -eq $Key)
        {
            $TargetDC = $dicDomainDC.$Key
            Try
            {
                $Objects =  Get-ADObject -Filter "SIDHistory -like '*'" -Properties SIDHistory, DistinguishedName, ObjectClass, LastLogonTimestamp, PwdLastSet -Server $TargetDC -erroraction SilentlyContinue
            } Catch {

            }

            foreach ($obj in $Objects)
            {
                $CurDistinguishedName = $obj.DistinguishedName
                $CurSIDHistory = [String]$obj.SidHistory
                $CurObjectClass = $obj.ObjectClass
                $CurLastLogonTimestamp = $obj.LastLogonTimestamp
                $CurPwdLastSet = $obj.PwdLastSet
                $CurLastLogonTimestamp = [DateTime]::FromFileTimeutc($CurLastLogonTimestamp)
                $CurPasswordLastSet = [DateTime]::FromFileTimeutc($CurPwdLastSet)

                $Index = $CurDistinguishedName.IndexOf("DC=")
                $Length = $CurDistinguishedName.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $MemberDomainDN = $CurDistinguishedName.Substring($Index,$AppliedLength)
                $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                $Index = $CurSIDHistory.LastIndexOf("-")
                $Length = $CurSIDHistory.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $CurrentRID = $CurSIDHistory.Substring($Index+1,$AppliedLength-1)
                $RidFound = $false
                $Tier0Object = ""
                $Reason = ""

                if ($dicTier0RIDs.ContainsKey($CurrentRID) -eq $true)
                {
                    $RIDFound = $true
                    $Tier0Object = $dicTier0RIDs.$CurrentRID
                } 
                if ($dicTier0SIDs.ContainsKey($CurSIDHistory) -eq $true)
                {
                    $RIDFound = $true
                    $Tier0Object = $dicTier0IdentitiesBySID.$CurSIDHistory
                }
                $Reason = "Non-Tier 0 Identity With A Tier-0 SID In SIDHistory"

                if ($RIDFound -eq $true)
                {
                    $LineOut = '"' + $CurDistinguishedName + '",'`
                                + '"' + $MemberDomainFQDN  + '",'`
                                + '"' + $CurObjectClass  + '",'`
                                + '"' + $CurSIDHistory  + '",'`
                                + '"' + $CurLastLogonTimestamp  + '",'`
                                + '"' + $CurPasswordLastSet  + '",'`
                                + '"' + $RIDFound  + '",'`
                                + '"' + $Tier0Object  + '",'`
                                + '"' + $Reason  + '"'

                    Add-Content -Path $Tier0SIDHistoryFile -Value $LineOut -Encoding Unicode
                }
            }
        }
    }
}


################################
### Get Registry Permissions ###
################################
Function GetRegistryPermissions
{
    WriteLog "Getting Registry Permissions." $true
    
    if ($RegistryFiles) 
    {
        foreach ($CSVFile in $RegistryFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {

                    WriteLog "Reading $CSVFile" $true
                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {

                        $CurServerFQDN = $Row.ServerFqdn

                        WriteLog "CurServerFQDN: $CurServerFQDN"

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServerFQDN) -eq $true -or $dicDcFQDN.ContainsKey($CurServerFQDN) -eq $true)
                        {

                            $IdentityReference = $Row.IdentityReference
                            $RegistryRights = $Row.RegistryRights
                            $AccessRuleProtected = $Row.AccessRulesProtected
                            $OwnerIdentityReference = $Row.OwnerIdentityReference
                            $AccessType = $Row.AccessType
                            $IsInherited = $Row.IsInherited
                            $InheritanceFlags = $Row.InheritanceFlags
                            $PropagationFlags = $Row.PropagationFlags
                            $RegistryKey = $Row.RegistryKey

                            WriteLog "IdentityReference: $IdentityReference"
                            WriteLog "RegistryRights: $RegistryRights"
                            WriteLog "AccessRuleProtected: $AccessRuleProtected"
                            WriteLog "OwnerIdentityReference: $OwnerIdentityReference"
                            WriteLog "AccessType: $AccessType"
                            WriteLog "IsInherited: $IsInherited"
                            WriteLog "PropagationFlags: $PropagationFlags"

                            $Index = $CurServerFQDN.IndexOf(".")
                            $Length = $CurServerFQDN.Length
                            $AppliedLength = $Length - ($Index + 1)
                            $CurServerDomain = $CurServerFQDN.Substring($Index+1,$AppliedLength)
                            $CurTargetDC = $dicDomainDC.$CurServerDomain

                            WriteLog "CurServerDomain: $CurServerDomain"
                            WriteLog "CurTargetDC: $CurTargetDC"

                            if ($IdentityReference.Contains("\") -eq $true)
                            {
                                $Index = $IdentityReference.IndexOf("\")
                                $Length = $IdentityReference.Length
                                $AppliedLength = $Length - ($Index)-1
                                $TargetIdentity = $IdentityReference.Substring($Index+1,$AppliedLength)
                                $TargetAuthority = $IdentityReference.Substring(0,$Index)
                            } else {
                                $TargetIdentity = $IdentityReference
                            }


                            $ADObject = GetADObject $TargetIdentity $CurTargetDC $CurServerDomain $false

                            

                            if ($ADObject)
                            {
                                $CurDistinguishedName = $ADObject.DistinguishedName

                                $MemberDisplayName = $ADObject.DisplayName
                                $MemberSamAccountName = $ADObject.SamAccountName

                                $Index = $CurDistinguishedName.IndexOf("DC=")
                                $Length = $CurDistinguishedName.Length + 1
                                $AppliedLength = $Length - ($Index+1)
                                $TargetDomainDN = $CurDistinguishedName.Substring($Index,$AppliedLength)

                                $MemberDomain = $TargetDomainDN -replace ",DC=", "."
                                $MemberDomain = $MemberDomain -replace "DC=", ""
                            
                                $CurAccessType = $AccessType
                                $CurAccess = $RegistryRights
                                $CurDomain = $MemberDomain
                                $CurObjectSID = [string]$ADObject.ObjectSID
                                $CurObjectClass = $ADObject.ObjectClass

                                #Get closest DC for LDAP Queries
                                $TargetDC = $dicDomainDC.$CurDomain

                                $Index = $CurObjectSID.LastIndexOf("-")
                                $Length = $CurObjectSID.Length + 1
                                $AppliedLength = $Length - ($Index+1)
                                $CurrentRID = $CurObjectSID.Substring($Index+1,$AppliedLength-1)
                                $RidFound = $false
                                $Tier0Object = ""

                                if ($dicTier0RIDs.ContainsKey($CurrentRID) -eq $true)
                                {
                                    $RIDFound = $true
                                    $Tier0Object = $dicTier0RIDs.$CurrentRID
                                } 
                                if ($dicTier0SIDs.ContainsKey($CurObjectSID) -eq $true)
                                {
                                    $RIDFound = $true
                                    $Tier0Object = $dicTier0IdentitiesBySID.$CurObjectSID
                                }

                                if ($CurDistinguishedName.contains("CN=Creator Owner,")) 
                                { 
                                    $IsCreatorOwner = $true 
                                } else {
                                    $IsCreatorOwner = $false
                                }
                                if ($CurDistinguishedName.contains("CN=Self,")) 
                                { 
                                    $IsSelf = $true 
                                } else {
                                    $IsSelf = $false
                                }
                                if ($CurDistinguishedName.contains("CN=Users,")) 
                                { 
                                    $IsUsers = $true 
                                } else {
                                    $IsUsers = $false
                                }
                                if ($CurObjectClass -eq "foreignSecurityPrincipal;top") 
                                { 
                                    $IsFSP = $true 
                                } else {
                                    $IsFSP = $false
                                }


                                if ($CurAccessType -eq "Allow")
                                {
                                    $Reason = ""
                                    $WriteAccess = $false
                                    if ($CurAccess.contains("Generic All")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("Generic Write")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("Generic Execute")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("Generic All")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("ChangePermissions")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("TakeOwnership")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("FullControl")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("WriteKey")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("CreateLink")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("CreateSubKey")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("SetValue")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("ExecuteKey")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("Notify")) { $WriteAccess = $true }
                                    if ($CurAccess.contains("Delete")) { $WriteAccess = $true }

                                    if ($WriteAccess -eq $true -and $dicTier0DistinguishedNames.ContainsKey($CurDistinguishedName) -eq $false -and $IsUsers -eq $false)
                                    {
                                        $Reason = "Non-Tier 0 Identity With Write Access To Registry"
                                    }

                                    if ($OwnerIdentityReference.Contains("\") -eq $true)
                                    {
                                        $Index = $OwnerIdentityReference.IndexOf("\")
                                        $Length = $OwnerIdentityReference.Length
                                        $AppliedLength = $Length - ($Index)-1
                                        $TargetIdentity = $OwnerIdentityReference.Substring($Index+1,$AppliedLength)
                                        $TargetAuthority = $OwnerIdentityReference.Substring(0,$Index)
                                    } else {
                                        $TargetIdentity = $OwnerIdentityReference
                                    }
                                
                                    $ADObject = GetADObject $TargetIdentity $CurTargetDC $CurServerDomain $false
                                    $ObjOwnerDistinguishedName = $ADObject.DistinguishedName
                                    $ObjOwnerObjectClass = $ADObject.ObjectClass
                                    $OwnerName = $ADObject.DisplayName

                                    if ($ObjOwnerDistinguishedName.length -gt 1)
                                    {
                                        $Index = $ObjOwnerDistinguishedName.IndexOf("DC=")
                                        $Length = $ObjOwnerDistinguishedName.Length + 1
                                        $AppliedLength = $Length - ($Index+1)
                                        $ObjOwnerDomainDN = $ObjOwnerDistinguishedName.Substring($Index,$AppliedLength)

                                        $ObjOwnerDomainFQDN = $ObjOwnerDomainDN -replace ",DC=", "."
                                        $ObjOwnerDomainFQDN = $ObjOwnerDomainFQDN -replace "DC=", ""
                                    } else {
                                        $ObjOwnerDomainFQDN = ""
                                    }
                                    if ($objOwnerDistinguishedName -ne "" -and $objOwnerDistinguishedName -ne $null)
                                    {

                                        if ($dicTier0DistinguishedNames.ContainsKey($ObjOwnerDistinguishedName) -eq $false) 
                                        { 
                                            $WriteAccess = $true
                                            $NonDefaultOwner = $true
                                            if ($Reason.length -eq 0)
                                            {
                                                $Reason = "Non-Tier0 Owner"
                                            } else {
                                                $Reason = ", Non-Tier0 Owner"
                                            }
                                        } else {
                                            $NonDefaultOwner = $false
                                        }
                                    }


                                    if ($Reason -ne "")
                                    {
                                        $LineOut = '"' + $CurServerFQDN + '",'`
                                                    + '"' + $MemberDisplayName  + '",'`
                                                    + '"' + $MemberSamAccountName  + '",'`
                                                    + '"' + $MemberDomain  + '",'`
                                                    + '"' + $CurObjectClass  + '",'`
                                                    + '"' + $CurDistinguishedName  + '",'`
                                                    + '"' + $RegistryKey  + '",'`
                                                    + '"' + $RegistryRights  + '",'`
                                                    + '"' + $AccessType  + '",'`
                                                    + '"' + $IsInherited  + '",'`
                                                    + '"' + $OwnerIdentityReference  + '",'`
                                                    + '"' + $OwnerName  + '",'`
                                                    + '"' + $ObjOwnerDistinguishedName  + '",'`
                                                    + '"' + $ObjOwnerObjectClass  + '",'`
                                                    + '"' + $ObjOwnerDomainFQDN  + '",'`
                                                    + '"Explicit",'`
                                                    + '"' + $Reason  + '"'

                                        Add-Content -Path $Tier0RegistryAccessFile -Value $LineOut -Encoding Unicode

                                        if ($CurObjectClass -eq "group" -and $IncludeNested -eq $true)
                                        {
                                            if ($dicIndirectGroups.ContainsKey($CurDistinguishedName) -eq $false)
                                            {
                                                $dicIndirectGroups.Add($CurDistinguishedName,"")
                                            }

                             
                                            #GetNestedMembers3 $CurDistinguishedName $Tier0RegistryAccessFile $CurServerFQDN $RegistryKey $AccessType $AccessType $IsInherited $OwnerIdentityReference $OwnerName $ObjOwnerDistinguishedName $ObjOwnerObjectClass $ObjOwnerDomainFQDN $Reason

                                        }
                                    }
                                }
                        
                            }
                        }
                    } 
                }
            }   
        }
    }
}


#############################
### Get Share Permissions ###
#############################
Function GetSharePermissions
{
    WriteLog "Getting Share Access On Tier 0 Machines." $true

    if ($ShareFiles)
    {
        foreach ($CSVFile in $ShareFiles)
        {
            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $true -or $dicMemberServerFQDN.ContainsKey($ServerName) -eq $true -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true
                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServerFQDN = $Row.ServerFqdn
                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServerFQDN) -eq $true -or $dicDcFQDN.ContainsKey($CurServerFQDN) -eq $true)
                        {
                            $ShareName = $Row.ShareName
                            $SharePath = $Row.SharePath
                            $IdentityReference = $Row.IdentityReference
                            $Domain = $Row.Domain
                            $SID = $Row.SID
                            $AccessMask = $Row.AccessMask
                            $AccessType = $Row.AccessType
                            $Access = $Row.Access

                            WriteLog "ShareName: $ShareName"
                            WriteLog "IdentityReference: $IdentityReference"
                            WriteLog "Domain: $Domain"
                            WriteLog "SID: $SID"
                            WriteLog "AccessMask: $AccessMask"
                            WriteLog "AccessType: $AccessType"
                            WriteLog "Access: $Access"

                            $Index = $CurServerFQDN.IndexOf(".")
                            $Length = $CurServerFQDN.Length
                            $AppliedLength = $Length - ($Index + 1)
                            $CurServerDomain = $CurServerFQDN.Substring($Index+1,$AppliedLength)
                            $CurTargetDC = $dicDomainDC.$CurServerDomain

                            WriteLog "CurServerDomain: $CurServerDomain"
                            WriteLog "CurTargetDC: $CurTargetDC"

                            $ADObject = GetADObject $SID $CurTargetDC $CurServerDomain $false

                            $CurDistinguishedName = $ADObject.DistinguishedName
                            $CurDisplayName = $ADObject.DisplayName
                            $CurObjectClass = $ADObject.ObjectClass
                            $CurSamAccountName = $ADObject.SamAccountName

                            WriteLog "CurDistinguishedName: $CurDistinguishedName"

                            if ($CurDistinguishedName -ne "" -and $CurDistinguishedName -ne $null)
                            {
                                if ($dicTier0DistinguishedNames.ContainsKey($CurDistinguishedName) -eq $false)
                                {

                                    $Index = $CurDistinguishedName.IndexOf("DC=")
                                    $Length = $CurDistinguishedName.Length + 1
                                    $AppliedLength = $Length - ($Index+1)
                                    $TargetDomainDN = $CurDistinguishedName.Substring($Index,$AppliedLength)

                                    $MemberDomain = $TargetDomainDN -replace ",DC=", "."
                                    $MemberDomain = $MemberDomain -replace "DC=", ""


                                    $CurObjectClass = $ADObject.ObjectClass

                                    $Index = $SID.LastIndexOf("-")
                                    $Length = $SID.Length + 1
                                    $AppliedLength = $Length - ($Index+1)
                                    $CurrentRID = $SID.Substring($Index+1,$AppliedLength-1)
                                    $RidFound = $false
                                    $Tier0Object = ""

                                    if ($dicTier0RIDs.ContainsKey($CurrentRID) -eq $true)
                                    {
                                        $RIDFound = $true
                                        $Tier0Object = $dicTier0RIDs.$CurrentRID
                                    } 
                                    if ($dicTier0SIDs.ContainsKey($SID) -eq $true)
                                    {
                                        $RIDFound = $true
                                        $Tier0Object = $dicTier0IdentitiesBySID.$SID
                                    }
                                    if ($CurDistinguishedName.contains("CN=Creator Owner,")) 
                                    { 
                                        $IsCreatorOwner = $true 
                                    } else {
                                        $IsCreatorOwner = $false
                                    }
                                    if ($CurDistinguishedName.contains("CN=Self,")) 
                                    { 
                                        $IsSelf = $true 
                                    } else {
                                        $IsSelf = $false
                                    }
                                    if ($CurDistinguishedName.contains("CN=Users,")) 
                                    { 
                                        $IsUsers = $true 
                                    } else {
                                        $IsUsers = $false
                                    }
                                    if ($CurObjectClass -eq "foreignSecurityPrincipal;top") 
                                    { 
                                        $IsFSP = $true 
                                    } else {
                                        $IsFSP = $false
                                    }

                                    if ($AccessType -eq "Allow")
                                    {
                                        $Reason = ""
                                        $WriteAccess = $false
                                        if ($Access.contains("CHANGE")) { $WriteAccess = $true }
                                        if ($Access.contains("FULL CONTROL")) { $WriteAccess = $true }

                                        if ($WriteAccess -eq $true)
                                        {
                                            $Reason = "Non-Tier 0 Identity With Write Access To Share"
                                        }

                                        if ($WriteAccess -eq $true -and $IsSelf -eq $false -and $IsCreatorOwner -eq $false -and $RidFound -eq $false -and $IsUsers -eq $false)
                                        {
                                            $LineOut = '"' + $CurServerFQDN + '",'`
                                                        + '"' + $CurDisplayName  + '",'`
                                                        + '"' + $CurSamAccountName  + '",'`
                                                        + '"' + $MemberDomain  + '",'`
                                                        + '"' + $CurObjectClass  + '",'`
                                                        + '"' + $CurDistinguishedName  + '",'`
                                                        + '"' + $ShareName  + '",'`
                                                        + '"' + $Access  + '",'`
                                                        + '"' + $AccessType  + '",'`
                                                        + '"' + $SharePath  + '",'`
                                                        + '"Explicit",'`
                                                        + '"' + $Reason  + '"'

                                            Add-Content -Path $Tier0ShareFile -Value $LineOut -Encoding Unicode

                                            if ($CurObjectClass -eq "group" -and $IncludeNested -eq $true)
                                            {

                                                if ($dicIndirectGroups.ContainsKey($CurDistinguishedName) -eq $false)
                                                {
                                                    $dicIndirectGroups.Add($CurDistinguishedName,"")
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


###############################
### Get Trust Relationships ###
###############################
Function GetTrustRelationships
{

    WriteLog "Getting Trust Relationship details." $true
    $dicTDO = @{}    			
    $domains= (Get-ADForest).Domains

    foreach($domain in $domains) 
    {
        if ($domain -NE "")
        {
            $dicTDO.Clear()
            $TargetDC = GetClosestDC $domain
            $TDOs = Get-ADObject -Filter 'ObjectClass -eq "trustedDomain"' -Property WhenChanged -Server $TargetDC | Select-Object Name, WhenChanged
            foreach ($TDO in $TDOs)
            {
                $TrustDomain = $TDO.Name
                $TrustChanged = $TDO.whenChanged
                $dicTDO.Add($TrustDomain,$TrustChanged)
            }

            $trusts= Get-ADTrust -Filter * -Server $domain -ErrorAction silentlycontinue
    
            foreach($trust in $trusts) 
            {
            
                $Reason = ""
                $Attributes = [int]$trust.TrustAttributes
                $SIDFilteringForestAware = $trust.SIDFilteringForestAware
                $SelectiveAuthentication = $trust.SelectiveAuthentication
                $SIDFilteringQuarantined = $trust.SIDFilteringQuarantined
                $TGTDelegation = $trust.TGTDelegation
                $Direction = $trust.Direction

                if ($attributes -band 8)
                {
            
                    if ($SelectiveAuthentication -eq $false) {
                        $Reason = "Forest trust without Selective Authentication ($($trust.Name))"
                    }

                    if($SIDFilteringQuarantined -eq $false) 
                    {
                        if ($Reason -eq "")
                        {
                            $Reason = "Forest trust without SID Filtering ($($trust.Name))"
                        } else {
                            $Reason = $Reason + ", Forest trust without SID Filtering ($($trust.Name))"
                        }
                    }

                }

                if (($attributes -band 8) -or $Direction -eq "Inbound")
                {

                    if($TGTDelegation -eq $true) 
                    {
                        if ($Reason -eq "")
                        {
                            $Reason = "Inbound trust with Unconstrained Kerberos Delegation enabled ($($trust.Name))"
                        } else {
                            $Reason = $Reason + ", Inbound trust with Unconstrained Kerberos Delegation enabled ($($trust.Name))"
                        }
                    }


                }
                $TrustTarget = $trust.Target
                $WhenChanged = $dicTDO.$TrustTarget

                $LineOut = '"' + $trust.Direction + '",'`
                            + '"' + $trust.DisallowTransivity  + '",'`
                            + '"' + $trust.DistinguishedName  + '",'`
                            + '"' + $trust.ForestTransitive  + '",'`
                            + '"' + $trust.IntraForest  + '",'`
                            + '"' + $trust.IsTreeParent  + '",'`
                            + '"' + $trust.Name  + '",'`
                            + '"' + $trust.ObjectClass  + '",'`
                            + '"' + $trust.ObjectGUID  + '",'`
                            + '"' + $trust.SelectiveAuthentication  + '",'`
                            + '"' + $trust.SIDFilteringForestAware  + '",'`
                            + '"' + $trust.SIDFilteringQuarantined  + '",'`
                            + '"' + $trust.Source  + '",'`
                            + '"' + $trust.Target  + '",'`
                            + '"' + $trust.TGTDelegation  + '",'`
                            + '"' + $trust.TrustAttributes  + '",'`
                            + '"' + $trust.TrustingPolicy  + '",'`
                            + '"' + $trust.TrustType  + '",'`
                            + '"' + $trust.UplevelOnly  + '",'`
                            + '"' + $trust.UsesAESKeys  + '",'`
                            + '"' + $trust.UsesRC4Encryption  + '",'`
                            + '"' + $Reason  + '",'`
                            + '"' + $WhenChanged  + '"'

                Add-Content -Path $Tier0TrustFile -Value $LineOut -Encoding Unicode

            }
        }
    }
}


####################
### Get Services ###
####################
Function GetServices
{
    if ($ServiceFiles) 
    {
        WriteLog "Getting Services On Tier 0 Machines." $true
        foreach ($CSVFile in $ServiceFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"



            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                    }

                    
                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {

                        $CurServer = $Row.ServerFqdn
                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $LineOut = '"' + $Row.ServerFqdn + '",'`
                                        + '"' + $Row.DisplayName  + '",'`
                                        + '"' + $Row.PathName  + '",'`
                                        + '"' + $Row.StartName  + '",'`
                                        + '"' + $MemberServerDistinguishedName + '",'`
                                        + '"' + $MemberServerApplication  + '",'`
                                        + '"' + $MemberServerRole  + '",'`
                                        + '"' + $Row.StartMode  + '",'`
                                        + '"' + $Row.State  + '"'


                            Add-Content -Path $Tier0ServicesFile -Value $LineOut -Encoding Unicode
                        } 
                    }
                }
            }
        }
    }
}

###########################
### Get Scheduled Tasks ###
###########################
Function GetScheduledTasks
{

    if ($ScheduledTaskFiles) 
    {
        WriteLog "Getting Scheduled Tasks On Tier 0 Machines." $true
        foreach ($CSVFile in $ScheduledTaskFiles)
        {
            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile

                    foreach ($Row in $CSV) 
                    {

                        $CurServer = $Row.ServerFqdn
                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $LineOut = '"' + $Row.ServerFqdn + '",'`
                                        + '"' + $Row.TaskName  + '",'`
                                        + '"' + $Row.Principal  + '",'`
                                        + '"' + $MemberServerDistinguishedName  + '",'`
                                        + '"' + $MemberServerApplication  + '",'`
                                        + '"' + $MemberServerRole  + '"'

                            Add-Content -Path $Tier0ScheduledTasksFile -Value $LineOut -Encoding Unicode
                        }
                    }
                }
            }
        }
    }
}


#############################
### Get Installed Softare ###
#############################
Function GetInstalledSoftware
{

    if ($InstalledSoftwareFiles) 
    {
        WriteLog "Getting Installed Software On Tier 0 Machines." $true
        foreach ($CSVFile in $InstalledSoftwareFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $Row.ServerFqdn

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $LineOut = '"' + $Row.ServerFQDN + '",'`
                                        + '"' + $Row.DisplayName  + '",'`
                                        + '"' + $Row.DisplayVersion  + '",'`
                                        + '"' + $Row.Publisher  + '",'`
                                        + '"' + $Row.InstallDate  + '",'`
                                        + '"' + $MemberServerDistinguishedName  + '",'`
                                        + '"' + $MemberServerApplication  + '",'`
                                        + '"' + $MemberServerRole  + '"'


                            Add-Content -Path $Tier0InstalledSoftwareFile -Value $LineOut -Encoding Unicode
                        }
                    }
                }
            }
        }
    }
}


############################
### Get Windows Features ###
############################
Function GetWindowsFeatures
{

    if ($WindowsFeaturesFiles) 
    {
        WriteLog "Getting Windows Features On Tier 0 Machines." $true
        foreach ($CSVFile in $WindowsFeaturesFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                        $MemberServerDistinguishedName = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $ServerName

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $FeatureName = $Row.Name
                            $FeatureDisplayName = $Row.DisplayName
                            $FeatureDescription = $Row.Description
                            $FeatureInstalled = $Row.Installed
                            $FeatureInstalledState = $Row.InstalledState
                            $FeatureType = $Row.Type
                            $FeaturePath = $Row.Path
                            $FeatureDepth = $Row.Depth
                            $FeatureDependsOn = $Row.DependsOn
                            $FeatureParent = $Row.Parent
                            $FeatureServerComponentDescriptor = $Row.ServerComponentDescriptor
                            $FeatureSubFeatures = $Row.SubFeatures
                            $FeatureSystemService = $Row.SystemService
                            $FeatureNotification = $Row.Notification
                            $FeatureBestPracticesNodeId = $Row.BestPracticesNodeId
                            $FeatureEventQuery = $Row.EventQuery
                            $FeaturePostConfigurationNeeded = $Row.PostConfigurationNeeded
                            $FeatureMajorVersion = $Row.MajorVersion
                            $FeatureMinorVersion = $Row.MinorVersion
                            $FeatureNumericId = $Row.NumericId
                            $FeatureInstallName = $Row.InstallName

                            $LineOut = '"' + $CurServer + '","'`
                                        + $FeatureName + '","'`
                                        + $FeatureDisplayName + '","'`
                                        + $FeatureDescription  + '","'`
                                        + $FeatureInstalled  + '","'`
                                        + $FeatureInstalledState  + '","'`
                                        + $FeatureType  + '","'`
                                        + $FeaturePath  + '","'`
                                        + $FeatureDepth  + '","'`
                                        + $FeatureDependsOn + '","'`
                                        + $FeatureParent  + '","'`
                                        + $FeatureServerComponentDescriptor  + '","'`
                                        + $FeatureSubFeatures  + '","'`
                                        + $FeatureSystemService  + '","'`
                                        + $FeatureNotification  + '","'`
                                        + $FeatureBestPracticesNodeId  + '","'`
                                        + $FeatureEventQuery  + '","'`
                                        + $FeaturePostConfigurationNeeded  + '","'`
                                        + $FeatureMajorVersion  + '","'`
                                        + $FeatureMinorVersion  + '","'`
                                        + $FeatureNumericId  + '","'`
                                        + $FeatureInstallName  + '","'`
                                        + $MemberServerDistinguishedName  + '","'`
                                        + $MemberServerApplication  + '","'`
                                        + $MemberServerRole  + '"'

                            Add-Content -Path $Tier0WindowsFeaturesFile -Value $LineOut -Encoding Unicode

                        }
                    }
                }
            }
        }
    }
}

####################
### Get Hotfixes ###
####################
Function GetHotfixes
{

    if ($HotfixFiles) 
    {
        WriteLog "Getting Hotfixes On Tier 0 Machines." $true
        foreach ($CSVFile in $HotfixFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"
            $OperatingSystem=""

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $OperatingSystem = $ADObject.OperatingSystem
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                        $MemberServerDistinguishedName = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $ServerName

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $Description = $Row.Description
                            $HotFixID = $Row.HotFixID
                            $InstalledBy = $Row.InstalledBy
                            $InstalledOn = $Row.InstalledOn

                            $LineOut = '"' + $CurServer + '","'`
                                        + $Description + '","'`
                                        + $HotFixID + '","'`
                                        + $InstalledBy  + '","'`
                                        + $InstalledOn  + '","'`
                                        + $OperatingSystem  + '","'`
                                        + $MemberServerDistinguishedName  + '","'`
                                        + $MemberServerApplication  + '","'`
                                        + $MemberServerRole  + '"'

                            Add-Content -Path $Tier0HotfixFilename -Value $LineOut -Encoding Unicode

                        }
                    }
                }
            }
        }
    }
}

#######################
### Get Local Users ###
#######################
Function GetLocalUsers
{

    if ($LocalUserFiles) 
    {
        WriteLog "Getting Local Users On Tier 0 Machines." $true
        foreach ($CSVFile in $LocalUserFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicMemberServerFQDN.ContainsKey($ServerName))
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                        $MemberServerDistinguishedName = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $ServerName

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $UserName = $Row.UserName
                            $PasswordLastSet = $Row.PasswordLastSet
                            $LastLogon = $Row.LastLogon
                            $AccountCreated = $Row.AccountCreated
                            $UserSID = $Row.UserSID
                            $Enabled = $Row.Enabled
                            $Description = $Row.Description
                            $FullName = $Row.FullName
                            $PrincipalSource = $Row.PrincipalSource


                            $LineOut = '"' + $CurServer + '","'`
                                        + $MemberServerApplication + '","'`
                                        + $MemberServerRole + '","'`
                                        + $MemberServerDistinguishedName  + '","'`
                                        + $UserName  + '","'`
                                        + $PasswordLastSet  + '","'`
                                        + $LastLogon  + '","'`
                                        + $AccountCreated  + '","'`
                                        + $UserSID  + '","'`
                                        + $Enabled  + '","'`
                                        + $Description  + '","'`
                                        + $FullName  + '","'`
                                        + $PrincipalSource  + '"'

                            Add-Content -Path $Tier0LocalUsersFilename -Value $LineOut -Encoding Unicode

                        }
                    }
                }
            }
        }
    }
}


#######################################
### Create Account Disposition File ###
#######################################
Function CreateAccountDispositionFile
{

    WriteLog "Creating Account Disposition File." $true
    foreach ($Key in $dicTrustByFQDN.Keys)
    {
        $TrustDomain = $Key
        $TrustDC = $dicTrustByFQDN.$Key

        if ($dicDomainDC.ContainsKey($TrustDomain) -eq $false)
        {
            $dicDomainDC.Add($TrustDomain,$TrustDC)
        }
    }


    foreach ($TargetDN in $dicTier0DistinguishedNames.Keys)
    {
    
        $Index = $TargetDN.IndexOf("DC=")
        $Length = $TargetDN.Length + 1
        $AppliedLength = $Length - ($Index+1)
        $TargetDomainDN = $TargetDN.Substring($Index,$AppliedLength)

        $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
        $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""
        $MemberDomain = $TargetDomainFQDN
        
        $TargetDC = $dicDomainDC.$TargetDomainFQDN

        if ($TargetDC -ne $null -and $TargetDC -ne "")
        {

            $RootDSE = Get-ADRootDSE -Server $TargetDC -ErrorAction silentlycontinue
            $RootDomain = $RootDSE.rootDomainNamingContext
            $ConfigPartition = $RootDSE.configurationNamingContext
            $DefaultNamingContext = $RootDSE.defaultNamingContext
            $SchemaPartition = $RootDSE.schemaNamingContext

            if ($TargetNC -eq $null -or $TargetNC -eq "Domain")
            {
                $TargetNC = $DefaultNamingContext
            }
            if ($TargetNC -eq "Config")
            {
                $TargetNC = $ConfigPartition
            }
            if ($TargetNC -eq "Schema")
            {
                $TargetNC = $SchemaPartition
            }
            $obj = $null

            $Index = $TargetDN.IndexOf(",OU=")
            if ($Index -eq -1) {$Index = $TargetDN.IndexOf(",CN=")}
            if ($Index -eq -1) {$Index = $TargetDN.IndexOf(",DC=")}
            $Length = $TargetDN.Length
            $AppliedLength = $Length - ($Index + 1)
            $Container = $TargetDN.Substring($Index+1,$AppliedLength)

            $TargetDN2 = EscapeSpecialCharacters $TargetDN
            if ($dicADObjects.ContainsKey($TargetDN2) -eq $true)
            {
                $Obj = $dicADObjects.$TargetDN2
            } else {
                Try
                {
                    $obj = Get-ADObject -filter "DistinguishedName -eq '$TargetDN2'" -server $TargetDC -Properties * -ErrorAction SilentlyContinue
                } Catch {
                    WriteLog "Couldn't find $TargetDN on $TargetDC"

                    $LineOut = '"' + $TargetDN + '",'`
                                + '"' + $Container  + '",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"",'`
                                + '"n/a",'`
                                + '"",'`
                                + '"",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`
                                + '"n/a",'`

                    Add-Content -Path $AccountDispositionFile -Value $LineOut -Encoding Unicode
                }
            }
            if ($obj)
            {

                $SamAccountName = ""
                $Name = ""
                $ObjectClass = ""
                $UserAccountControl = ""
                $PwdLastSet = ""
                $LastLogonTimestamp = ""
                $sn = ""
                $GivenName = ""
                $Title = ""
                $ManagerDN = ""
                $Company = ""
                $Department = ""
                $Description = ""
                $Mail = ""
                $info = ""
                $PwdLastSet = ""
                $LastLogonTimestamp = ""
                $UserPrincipalName = ""

                $MgrDisplayName = ""
                $MgrGivenName = ""
                $MgrSamAccountName = ""
                $MgrName = ""

                $OwnerDisplayName = ""
                $OwnerGivenName = ""
                $OwnerSamAccountName = ""
                $OwnerName = ""

                $Enabled = ""
                $SPN = ""
                $isSensitive = ""
                $isSmartCardRequired = ""
                $isPasswordNeverExpires = ""
                $CannotChangePassword = ""
                $isStorePasswordWithReversibleEncryption = ""
                $isDoNotRequireKerberosPreAuthentication = ""
                $AdminCount = ""
                $msDSSupportedEncryptionTypes = $null

                $SamAccountName = $obj.SamAccountName
                $Name = $obj.Name
                $ObjectClass = $obj.ObjectClass    
                $UserAccountControl = $obj.UserAccountControl
                $PwdLastSet = $obj.pwdLastSet
                $LastLogonTimestamp = $obj.LastLogonTimestamp
                $sn = $obj.sn
                $GivenName = $obj.GivenName
                $Title = $obj.Title
                $ManagerDN = $obj.Manager
                $Company = $obj.Company
                $Department = $obj.Department
                $Description = $obj.Description
                $Mail = $obj.Mail
                $info = $obj.Info
                $PwdLastSet = [DateTime]::FromFileTimeutc($PwdLastSet)
                $LastLogonTimestamp = [DateTime]::FromFileTimeutc($LastLogonTimestamp)
                $msDSSupportedEncryptionTypes = $Obj.'msDS-SupportedEncryptionTypes'
                if ($msDSSupportedEncryptionTypes)
                {
                    $msDSSupportedEncryptionTypesBinary = "00000000000000000000000000000000" + [convert]::ToString($msDSSupportedEncryptionTypes,2)
                    $Length = $msDSSupportedEncryptionTypesBinary.Length - 32
                    $msDSSupportedEncryptionTypesBinaryOut = $msDSSupportedEncryptionTypesBinary.Substring($Length,32)

                } else {
                    $msDSSupportedEncryptionTypesBinaryOut = ""
                }

                $EmployeeID = $obj.EmployeeID
                $EmployeeNumber = $obj.EmployeeNumber
                $UserPrincipalName = $obj.userPrincipalName
                $SPN = $obj.servicePrincipalName
                $AdminCount = $obj.AdminCount
                [String]$SID = $obj.ObjectSID
                $Index = $SID.LastIndexOf("-")
                $Length = $SID.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $RID = $SID.Substring($Index+1,$AppliedLength-1)


                $sn = $sn -replace '"', ''
                $GivenName = $GivenName -replace '"', ''
                $Title = $Title -replace '"', ''
                $Company = $Company -replace '"', ''
                $Department = $Department -replace '"', ''
                $Description = $Description -replace '"', ''
                $Mail = $Mail -replace '"', ''
                $info = $info -replace '"', ''
                $EmployeeID = $EmployeeID -replace '"', ''
                $EmployeeNumber = $EmployeeNumber -replace '"', ''

                $sn = $sn -replace "`r`n", " "
                $GivenName = $GivenName -replace "`r`n", " "
                $Title = $Title -replace "`r`n", " "
                $Company = $Company -replace "`r`n", " "
                $Department = $Department -replace "`r`n", " "
                $Description = $Description -replace "`r`n", " "
                $Mail = $Mail  -replace "`r`n", " "
                $info = $info -replace "`r`n", " "
                $EmployeeID = $EmployeeID -replace "`r`n", " "
                $EmployeeNumber = $EmployeeNumber -replace "`r`n", " "

                $sn = $sn -replace "`r", " "
                $GivenName = $GivenName -replace "`r", " "
                $Title = $Title -replace "`r", " "
                $Company = $Company -replace "`r", " "
                $Department = $Department -replace "`r", " "
                $Description = $Description -replace "`r", " "
                $Mail = $Mail  -replace "`r", " "
                $info = $info -replace "`r", " "
                $EmployeeID = $EmployeeID -replace "`r", " "
                $EmployeeNumber = $EmployeeNumber -replace "`r", " "

                $sn = $sn -replace "`n", " "
                $GivenName = $GivenName -replace "`n", " "
                $Title = $Title -replace "`n", " "
                $Company = $Company -replace "`n", " "
                $Department = $Department -replace "`n", " "
                $Description = $Description -replace "`n", " "
                $Mail = $Mail  -replace "`n", " "
                $info = $info -replace "`n", " "
                $EmployeeID = $EmployeeID -replace "`n", " "
                $EmployeeNumber = $EmployeeNumber -replace "`n", " "
 
                $ManagerDN2 = EscapeSpecialCharacters $ManagerDN

                if ($ManagerDN -ne $null)
                {
                        $Index = $ManagerDN.IndexOf("DC=")
                        $Length = $ManagerDN.Length + 1
                        $AppliedLength = $Length - ($Index+1)
                        $TargetDomainDN = $ManagerDN.Substring($Index,$AppliedLength)

                        $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
                        $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""
    
                        $TargetDC = $dicDomainDC.$TargetDomainFQDN
                        
                        if ($dicADObjects.ContainsKey($ManagerDN2) -eq $true)
                        {
                            $Mgr = $dicADObjects.$ManagerDN2
                        } else {
                            Try
                            {
                                $Mgr = Get-ADObject -filter "DistinguishedName -eq '$ManagerDN2'" -server $TargetDC -Properties DisplayName,GivenName,sn,SamAccountName,Name -ErrorAction SilentlyContinue
                            } Catch {

                            }
                        }
                        if ($Mgr)
                        {
                            if ($dicADObjects.ContainsKey($ManagerDN2) -eq $false)
                            {
                                $dicADObjects.Add($ManagerDN2,$Mgr)
                            }
                            $MgrDisplayName = $Mgr.DisplayName
                            $MgrGivenName = $Mgr.GivenName + " " + $Mgr.sn
                            $MgrSamAccountName = $Mgr.SamAccountName
                            $MgrName = $Mgr.Name
                        }
                }

                if ($dicTier0Owners.ContainsKey($TargetDN) -eq $true)
                {
                    $OwnerDN = $dicTier0Owners.$TargetDN

                    if ($OwnerDN -ne "" -and $OwnerDN -ne $null)
                    {
                        $Index = $OwnerDN.IndexOf("DC=")
                        $Length = $OwnerDN.Length + 1
                        $AppliedLength = $Length - ($Index+1)
                        $TargetDomainDN = $OwnerDN.Substring($Index,$AppliedLength)

                        $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
                        $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""
    
                        $TargetDC = $dicDomainDC.$TargetDomainFQDN
                        $OwnerDN2 = EscapeSpecialCharacters $OwnerDN
                        if ($dicADObjects.ContainsKey($OwnerDN2) -eq $true)
                        {
                            $Owner = $dicADObjects.$OwnerDN2
                        } else {
                            Try
                            {
                            
                                $Owner = Get-ADObject -filter "DistinguishedName -eq '$OwnerDN2'" -server $TargetDC -Properties DisplayName,GivenName,sn,SamAccountName,Name -erroraction SilentlyContinue
                            } Catch {

                            }
                        }
                        if ($Owner)
                        {
                            if ($dicADObjects.ContainsKey($OwnerDN2) -eq $false)
                            {
                                $dicADObjects.Add($OwnerDN2,$Owner)
                            }
                            $OwnerDisplayName = $Owner.DisplayName
                            $OwnerGivenName = $Owner.GivenName + " " + $Owner.sn
                            $OwnerSamAccountName = $Owner.SamAccountName
                            $OwnerName = $Owner.Name
                        }
                    }
                } else {
                    $OwnerDN = ""
                }

                if ($ObjectClass -eq "user" -or $ObjectClass -eq "computer" -or $ObjectClas -eq "msDS-GroupManagedServiceAccount")
                {
                    if (($UserAccountControl -band 2) -ne 2) {
                        $Enabled = "Enabled"
                    } else {
                        $Enabled = "Disabled"
                    }
                } else {
                    $UserAccountControl = ""
                    $Enabled = ""
                    $PwdLastSet = ""
                    $LastLogonTimestamp = ""
                }
                if ($ObjectClass -eq "user" -or $ObjectClass -eq "computer")
                {

                    if (($UserAccountControl -band 1048576) -eq 1048576) {
                        $isSensitive = "Enabled"
                    } else {
                        $isSensitive = "Disabled"
                    }
                    if (($UserAccountControl -band 262144) -eq 262144) {
                        $isSmartCardRequired = "Enabled"
                    } else {
                        $isSmartCardRequired = "Disabled"
                    }
                    if (($UserAccountControl -band 65536) -eq 65536) {
                        $isPasswordNeverExpires = "Enabled"
                    } else {
                        $isPasswordNeverExpires = "Disabled"
                    }
                    if (($UserAccountControl -band 128) -eq 128) {
                        $isStorePasswordWithReversibleEncryption = "Enabled"
                    } else {
                        $isStorePasswordWithReversibleEncryption = "Disabled"
                    }
                    if (($UserAccountControl -band 4194304) -eq 4194304) {
                        $isDoNotRequireKerberosPreAuthentication = "Enabled"
                    } else {
                        $isDoNotRequireKerberosPreAuthentication = "Disabled"
                    }


                } else {
                    $isSensitive = ""
                    $isSmartCardRequired = ""
                    $isPasswordNeverExpires = ""
                    $isStorePasswordWithReversibleEncryption = ""
                    $isDoNotRequireKerberosPreAuthentication = ""
                }
                if ($ObjectClass -eq "user")
                {
                    $UserObj = Get-ADUser -filter "DistinguishedName -eq '$TargetDN2'" -server $TargetDC -Properties CannotChangePassword -ErrorAction SilentlyContinue
                    if ($userObj.CannotChangePassword) {
                        $CannotChangePassword="Enabled"
                    } else {
                        $CannotChangePassword="Disabled"
                    }


                } else {
                    $CannotChangePassword=""    
                }
                if ($ObjectClass -eq "group")
                {
                    if ($dicIsTier0CustomGroup.ContainsKey($TargetDN) -eq $true)
                    {
                        $IsTier0CustomGroup = $dicIsTier0CustomGroup.$TargetDN
                    } else {
                        $IsTier0CustomGroup = "False"
                    }
                } else {
                    $IsTier0CustomGroup = ""
                }


                $LineOut = '"' + $TargetDN + '",'`
                            + '"' + $Container  + '",'`
                            + '"' + $SamAccountName  + '",'`
                            + '"' + $Name  + '",'`
                            + '"' + $ObjectClass  + '",'`
                            + '"' + $MemberDomain  + '",'`
                            + '"' + $UserAccountControl  + '",'`
                            + '"' + $Enabled  + '",'`
                            + '"' + $PwdLastSet  + '",'`
                            + '"' + $LastLogonTimestamp  + '",'`
                            + '"' + $GivenName  + '",'`
                            + '"' + $sn  + '",'`
                            + '"' + $Title  + '",'`
                            + '"' + $Department  + '",'`
                            + '"' + $Description  + '",'`
                            + '"' + $Mail  + '",'`
                            + '"' + $info  + '",'`
                            + '"' + $Company  + '",'`
                            + '"' + $ManagerDN  + '",'`
                            + '"' + $MgrDisplayName  + '",'`
                            + '"' + $MgrGivenName  + '",'`
                            + '"' + $MgrSamAccountName  + '",'`
                            + '"' + $MgrName  + '",'`
                            + '"' + $OwnerDN  + '",'`
                            + '"' + $OwnerDisplayName  + '",'`
                            + '"' + $OwnerGivenName  + '",'`
                            + '"' + $OwnerSamAccountName  + '",'`
                            + '"' + $OwnerName  + '",'`
                            + '"' + $EmployeeID  + '",'`
                            + '"' + $EmployeeNumber  + '",'`
                            + '"' + $UserPrincipalName  + '",'`
                            + '"' + $SPN  + '",'`
                            + '"' + $isSensitive  + '",'`
                            + '"' + $isSmartCardRequired  + '",'`
                            + '"' + $isPasswordNeverExpires  + '",'`
                            + '"' + $CannotChangePassword  + '",'`
                            + '"' + $isStorePasswordWithReversibleEncryption  + '",'`
                            + '"' + $isDoNotRequireKerberosPreAuthentication  + '",'`
                            + '"' + $AdminCount  + '",'`
                            + '"' + $SID  + '",'`
                            + '"' + $RID  + '",'`
                            + '"' + $msDSSupportedEncryptionTypes  + '",'`
                            + '"' + $IsTier0CustomGroup  + '"'

                Add-Content -Path $AccountDispositionFile -Value $LineOut -Encoding Unicode

            }
        }
    }
}


##############################
### Get Nested Members-NEW ###
##############################
Function GetNestedMembers-NEW
{
    param (
        $TargetGroupDistinguishedName,
        $OrigDN,
        $OutputFilename
    )

    $Index = $TargetGroupDistinguishedName.IndexOf("DC=")
    $Length = $TargetGroupDistinguishedName.Length + 1
    $AppliedLength = $Length - ($Index+1)
    $TargetDomainDN = $TargetGroupDistinguishedName.Substring($Index,$AppliedLength)

    $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
    $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""

    $Index = $TargetGroupDistinguishedName.IndexOf(",OU=")
    if ($Index -eq -1) {$Index = $TargetGroupDistinguishedName.IndexOf(",CN=")}
    if ($Index -eq -1) {$Index = $TargetGroupDistinguishedName.IndexOf(",DC=")}

    $Length = $TargetGroupDistinguishedName.Length
    $AppliedLength = $Length - ($Index + 1)
    $TargetContainer = $TargetGroupDistinguishedName.Substring($Index+1,$AppliedLength)
        
    if ($dicDomainDC.ContainsKey($TargetDomainDN) -eq $true) {
        $TargetDC = $dicDomainDC.$TargetDomainDN
    } else {
        $TargetDC = GetClosestDC $TargetDomainFQDN
    }

    if ($DebugFlag -eq $true)
    {
        write-host ""
        write-host "TargetGroupDistinguishedName: $TargetGroupDistinguishedName" -ForegroundColor Cyan
        write-host "TargetDomainFQDN: $TargetDomainFQDN" -ForegroundColor Cyan
        write-host "TargetDC: $TargetDC" -ForegroundColor Cyan
    }

    $TargetGroupDistinguishedName2 = EscapeSpecialCharacters $TargetGroupDistinguishedName
    if ($dicGroupObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $false)
    {
        
        if ($dicADObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $true)
        {
            $Group = $dicADObjects.$TargetGroupDistinguishedName2
        } else {
            try
            {
                $Group = Get-adobject -Filter "DistinguishedName -eq '$TargetGroupDistinguishedName2'" -Server $TargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
            } catch {
                WriteLog "Group: $TargetSID not found on TargetDC: $TargetDC"
            }
        }

        if ($DebugFlag -eq $true)
        {
            Write-host "Group: $Group" -ForegroundColor Cyan
        }

        WriteLog ""
        WriteLog "############################"
        WriteLog "### GetNestedMembers-NEW ###"
        WriteLog "############################"
        WriteLog "TargetGroupDistinguishedName: $TargetGroupDistinguishedName"

        If ($Group) 
        {
            if ($dicADObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $false)
            {
                $dicADObjects.add($TargetGroupDistinguishedName2,$Group)
            }
            if ($dicGroupObjects.ContainsKey($TargetGroupDistinguishedName2) -eq $false)
            {
                $dicGroupObjects.add($TargetGroupDistinguishedName2,$Group)
            }
            $GroupSamAccountName = $Group.SamAccountName
            $GroupDisplayName = $Group.Name
            $GroupDomain = $DomainFQDN
            $GroupType = $Group.GroupType
            $GroupSID = $Group.ObjectSID
            $GroupMemberDNs = $Group.Member
            $GroupDistinguishedName = $Group.DistinguishedName
            $Index = $GroupDistinguishedName.IndexOf(",")
            $Length = $GroupDistinguishedName.Length
            $AppliedLength = $Length - ($Index + 1)
            $GroupContainer = $GroupDistinguishedName.Substring($Index+1,$AppliedLength)

            $IsDomainLocal = ($GroupType -band 4) -ne 0
            $IsGlobal = ($GroupType -band 2) -ne 0
            $IsUniversal = ($GroupType -band 8) -ne 0
            $IsSecurity = ($GroupType -band 0x80000000) -ne 0

            if ($IsDomainLocal -eq $true) {$GroupScope = "DomainLocal"}
            if ($IsGlobal -eq $true) {$GroupScope = "Global"}
            if ($IsUniversal -eq $true) {$GroupScope = "Universal"}

            WriteLog ""
            WriteLog "GroupSamAccountName: $GroupSamAccountName"
            WriteLog "GroupDisplayName: $GroupDisplayName"
            WriteLog "GroupDomain: $GroupDomain"
            WriteLog "GroupType: $GroupType"
            WriteLog "IsDomainLocal: $IsDomainLocal"
            WriteLog "IsGlobal: $IsGlobal"
            WriteLog "IsUniversal: $IsUniversal"
            WriteLog "GroupScope: $GroupScope"
            WriteLog "GroupSID: $GroupSID"
            WriteLog "GroupDistinguishedName: $GroupDistinguishedName"
            WriteLog "GroupContainer: $GroupContainer"


            foreach ($MemberDN in $GroupMemberDNs) 
            {

                WriteLog "MemberDN: $MemberDN"

                if ($DebugFlag -eq $true)
                {
                    Write-host "MemberDN: $MemberDN" -ForegroundColor Cyan
                }


                $MemberDistinguishedName = $MemberDN

                $Index = $MemberDistinguishedName.IndexOf("DC=")
                $Length = $MemberDistinguishedName.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                $Index = $MemberDistinguishedName.IndexOf(",OU=")
                if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
                if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

                $Length = $MemberDistinguishedName.Length
                $AppliedLength = $Length - ($Index + 1)
                $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)
        
                if ($dicDomainDC.ContainsKey($MemberDomainDN) -eq $true) {
                    $MemberTargetDC = $dicDomainDC.$MemberDomainDN
                } else {
                    $MemberTargetDC = GetClosestDC $MemberDomainFQDN
                }

                if ($DebugFlag -eq $true)
                {
                    Write-host "MemberDomainFQDN: $MemberDomainFQDN" -ForegroundColor Cyan
                    Write-host "MemberTargetDC: $MemberTargetDC" -ForegroundColor Cyan
                }


                $MemberDistinguishedName2 = EscapeSpecialCharacters $MemberDistinguishedName
                if ($dicMemberDNs.ContainsKey($MemberDistinguishedName2) -eq $false) {
                    $dicMemberDNs.Add($MemberDistinguishedName2,"")

                    if ($dicGroupMembers.ContainsKey($MemberDistinguishedName2) -eq $false)
                    {
                        
                        if ($dicADObjects.ContainsKey($MemberDistinguishedName2) -eq $true)
                        {
                            $Member = $dicADObjects.$MemberDistinguishedName2
                        } else {
                            Try
                            {
                                $Member = Get-adobject -Filter "DistinguishedName -eq '$MemberDistinguishedName2'" -Server $MemberTargetDC -Properties * -ResultSetSize $ResultSetSize -ErrorAction SilentlyContinue
                            } Catch {
                                WriteLog "Ref4 - Could not find: $MemberDistinguishedName"
                            }
                        }
                    } else {
                        $Member = $dicGroupMembers.$MemberDistinguishedName2
                    }

                    if ($Member)
                    {
                        if ($dicADObjects.ContainsKey($MemberDistinguishedName2) -eq $false)
                        {
                            $dicADObjects.add($MemberDistinguishedName2,$Member)
                        }
                        if ($dicGroupMembers.ContainsKey($MemberDistinguishedName2) -eq $false)
                        {
                            $dicGroupMembers.add($MemberDistinguishedName2,$Member)
                        }
                        $MemberDisplayName = $Member.name
                        $MemberSID = [string]$Member.ObjectSID
                        $MemberSamAccountName = $Member.SamAccountName
                        $MemberObjectClass = $Member.objectClass

                        if ($MemberObjectClass -eq "user" -or $MemberObjectClass -eq "computer" -or $MemberObjectClass -eq "msDS-GroupManagedServiceAccount") {
                            $MemberUserAccountControl = $Member.UserAccountControl
                            if (($MemberUserAccountControl -band 2) -ne 2) {
                                $MemberState = "Enabled"
                            } else {
                                $MemberState = "Disabled"
                            }
                        } else {
                            $MemberState = ""
                            $MemberUserAccountControl = ""
                        }
                        if ($dicMemberState.ContainsKey($MemberDistinguishedName) -eq $false)
                        {
                            $dicMemberState.Add($MemberDistinguishedName,$MemberState)
                        }
                        if ($dicMemberUAC.ContainsKey($MemberDistinguishedName) -eq $false)
                        {
                            $dicMemberUAC.Add($MemberDistinguishedName,$MemberUserAccountControl)
                        }

                        WriteLog ""
                        WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                        WriteLog "MemberDisplayName: $MemberDisplayName"
                        WriteLog "MemberSID: $MemberSID"
                        WriteLog "MemberSamAccountName: $MemberSamAccountName"
                        WriteLog "MemberObjectClass: $MemberObjectClass"
                        WriteLog "MemberDomainDN: $MemberDomainDN"
                        WriteLog "MemberDomainFQDN: $MemberDomainFQDN"
                        WriteLog "MemberTargetDC: $MemberTargetDC"
                        WriteLog "MemberContainer: $MemberContainer"
                        WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                        WriteLog "MemberState: $MemberState"
                        WriteLog "MemberMemberShipType: Explicit"

                        $LineOut = '"' + $TargetGroupDistinguishedName + '",'`
                                    + '"' + $MemberDisplayName  + '",'`
                                    + '"' + $MemberSamAccountName  + '",'`
                                    + '"' + $MemberDomainFQDN  + '",'`
                                    + '"' + $MemberObjectClass  + '",'`
                                    + '"' + $MemberDistinguishedName  + '",'`
                                    + '"' + $MemberSID  + '",'`
                                    + '"Nested",'`
                                    + '"' + $MemberState  + '"'
                    
                        if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false -or $OutputFilename -eq $SpecialGroupsFilename)
                        {
                        
                            Add-Content -Path $OutputFilename -Value $LineOut -Encoding Unicode

                            if ($OrigDN)
                            {
                               
                                $LineOut = '"' + $OrigDN + '",'`
                                            + '"' + $MemberDisplayName  + '",'`
                                            + '"' + $MemberSamAccountName  + '",'`
                                            + '"' + $MemberDomainFQDN  + '",'`
                                            + '"' + $MemberObjectClass  + '",'`
                                            + '"' + $MemberDistinguishedName  + '",'`
                                            + '"' + $MemberSID  + '",'`
                                            + '"Nested",'`
                                            + '"' + $MemberState  + '"'

                                Add-Content -Path $OutputFilename -Value $LineOut -Encoding Unicode

                            }

                            if ($MemberObjectClass -eq "group" -and $IncludeNested -eq $true)
                            {
                                $NewDN = $Global:OrigTier0DistinguishedName
                                GetNestedMembers-NEW $MemberDistinguishedName $NewDN
                            }
                        }
                    }
                }
            }
        }
    } else {
        $Group = $dicGroupObjects.$TargetGroupDistinguishedName

        If ($Group) 
        {
            $GroupSamAccountName = $Group.SamAccountName
            $GroupDisplayName = $Group.Name
            $GroupDomain = $DomainFQDN
            $GroupType = $Group.GroupType
            $GroupSID = $Group.ObjectSID
            $GroupMemberDNs = $Group.Member
            $GroupDistinguishedName = $Group.DistinguishedName
            $Index = $GroupDistinguishedName.IndexOf(",")
            $Length = $GroupDistinguishedName.Length
            $AppliedLength = $Length - ($Index + 1)
            $GroupContainer = $GroupDistinguishedName.Substring($Index+1,$AppliedLength)

            $IsDomainLocal = ($GroupType -band 4) -ne 0
            $IsGlobal = ($GroupType -band 2) -ne 0
            $IsUniversal = ($GroupType -band 8) -ne 0
            $IsSecurity = ($GroupType -band 0x80000000) -ne 0

            if ($IsDomainLocal -eq $true) {$GroupScope = "DomainLocal"}
            if ($IsGlobal -eq $true) {$GroupScope = "Global"}
            if ($IsUniversal -eq $true) {$GroupScope = "Universal"}

            foreach ($MemberDN in $GroupMemberDNs) 
            {

                WriteLog "MemberDN: $MemberDN"

                $MemberDistinguishedName = $MemberDN

                $Index = $MemberDistinguishedName.IndexOf("DC=")
                $Length = $MemberDistinguishedName.Length + 1
                $AppliedLength = $Length - ($Index+1)
                $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                $Index = $MemberDistinguishedName.IndexOf(",OU=")
                if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
                if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

                $Length = $MemberDistinguishedName.Length
                $AppliedLength = $Length - ($Index + 1)
                $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)
        
                if ($dicDomainDC.ContainsKey($MemberDomainDN) -eq $true) {
                    $MemberTargetDC = $dicDomainDC.$MemberDomainDN
                } else {
                    $MemberTargetDC = GetClosestDC $MemberDomainFQDN
                }

                if ($dicMemberDNs.ContainsKey($MemberDistinguishedName) -eq $false) 
                {
                    $dicMemberDNs.Add($MemberDistinguishedName,"")

                    $Member = $dicGroupMembers.$MemberDistinguishedName

                    $MemberDisplayName = $Member.name
                    $MemberSID = [string]$Member.ObjectSID
                    $MemberSamAccountName = $Member.SamAccountName
                    $MemberObjectClass = $Member.objectClass

                    if ($MemberObjectClass -eq "user" -or $MemberObjectClass -eq "computer" -or $MemberObjectClass -eq "msDS-GroupManagedServiceAccount") {
                        $MemberUserAccountControl = $Member.UserAccountControl
                        if (($MemberUserAccountControl -band 2) -ne 2) {
                            $MemberState = "Enabled"
                        } else {
                            $MemberState = "Disabled"
                        }
                    } else {
                        $MemberState = ""
                        $MemberUserAccountControl = ""
                    }
                    if ($dicMemberState.ContainsKey($MemberDistinguishedName) -eq $false)
                    {
                        $dicMemberState.Add($MemberDistinguishedName,$MemberState)
                    }
                    if ($dicMemberUAC.ContainsKey($MemberDistinguishedName) -eq $false)
                    {
                        $dicMemberUAC.Add($MemberDistinguishedName,$MemberUserAccountControl)
                    }

                    WriteLog ""
                    WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                    WriteLog "MemberDisplayName: $MemberDisplayName"
                    WriteLog "MemberSID: $MemberSID"
                    WriteLog "MemberSamAccountName: $MemberSamAccountName"
                    WriteLog "MemberObjectClass: $MemberObjectClass"
                    WriteLog "MemberDomainDN: $MemberDomainDN"
                    WriteLog "MemberDomainFQDN: $MemberDomainFQDN"
                    WriteLog "MemberTargetDC: $MemberTargetDC"
                    WriteLog "MemberContainer: $MemberContainer"
                    WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                    WriteLog "MemberState: $MemberState"
                    WriteLog "MemberMemberShipType: Explicit"

                    $LineOut = '"' + $TargetGroupDistinguishedName + '",'`
                                + '"' + $MemberDisplayName  + '",'`
                                + '"' + $MemberSamAccountName  + '",'`
                                + '"' + $MemberDomainFQDN  + '",'`
                                + '"' + $MemberObjectClass  + '",'`
                                + '"' + $MemberDistinguishedName  + '",'`
                                + '"' + $MemberSID  + '",'`
                                + '"Nested",'`
                                + '"' + $MemberState  + '"'

                    if ($dicTier0DistinguishedNames.ContainsKey($MemberDistinguishedName) -eq $false -or $OutputFilename -eq $SpecialGroupsFilename)
                    {
                        
                        Add-Content -Path $OutputFilename -Value $LineOut -Encoding Unicode

                        if ($OrigDN)
                        {
 
                            $LineOut = '"' + $OrigDN + '",'`
                                        + '"' + $MemberDisplayName  + '",'`
                                        + '"' + $MemberSamAccountName  + '",'`
                                        + '"' + $MemberDomainFQDN  + '",'`
                                        + '"' + $MemberObjectClass  + '",'`
                                        + '"' + $MemberDistinguishedName  + '",'`
                                        + '"' + $MemberSID  + '",'`
                                        + '"Nested",'`
                                        + '"' + $MemberState  + '"'

                            Add-Content -Path $OutputFilename -Value $LineOut -Encoding Unicode

                        }


                        if ($MemberObjectClass -eq "group" -and $IncludeNested -eq $true)
                        {
                            $NewDN = $Global:OrigTier0DistinguishedName
                        
                            GetNestedMembers-NEW $MemberDistinguishedName $NewDN
                        }
                    }
                
                }
            }
        }
    }
}


###############################
### Expand Group Membership ###
###############################
Function ExpandGroupMembership
{
    Param (
        $OutputFilename
    )


    WriteLog "Expanding Group Membership." $true
    foreach ($GroupDN in $dicIndirectGroups.Keys)
    {
        if ($dicTier0DistinguishedNames.ContainsKey($GroupDN) -eq $false) 
        {
            WriteLog "Expanding Group: $GroupDN" $true
            $dicMemberDNs.Clear()
            $Global:OrigTier0DistinguishedName = $GroupDN
            GetNestedMembers-NEW $GroupDN "" $OutputFilename
        }
    }
}

##################################
### Scan Certificate Templates ###
##################################
Function ScanCertificateTemplates
{
    write-host "Getting Certificate Template Information."

    # Define the flag for "Subject Name Supplied in Request"
    $SUBJECT_NAME_SUPPLIED = 0x00000001

    # Get all certificate templates

    $CertDN = "CN=Certificate Templates,CN=Public Key Services,CN=Services,CN=Configuration," + $MasterRootDomainLDAP

    $templates = Get-ADObject -Filter 'ObjectClass -eq "pKICertificateTemplate"' -SearchBase "$CertDN" -Properties displayName,msPKI-Certificate-Name-Flag,msPKI-Certificate-Application-Policy

    # Get all Certificate Authorities
    $EnrollDN = "CN=Enrollment Services,CN=Public Key Services,CN=Services,CN=Configuration," + $MasterRootDomainLDAP
    $caConfigPath = $EnrollDN
    $cas = Get-ADObject -Filter * -SearchBase "$caConfigPath" -Properties dNSHostName,Name,certificateTemplates

    foreach ($template in $templates) 
    {
        $flags = $template.'msPKI-Certificate-Name-Flag'
        
        $CertTemplateName = $template.displayName

        if ($flags -band $SUBJECT_NAME_SUPPLIED) 
        {
            $CanSupplySubjectName = $True
        } else {
            $CanSuppySubjectName = $False
        }

        $CAIssuedBy = ""
        $CAIssuedByDNS = ""

        $msPKICertificateApplicationPolicy = $template.'msPKI-Certificate-Application-Policy'
        
        # Find which CA(s) issue this template
        foreach ($ca in $cas) 
        {
            if ($ca.certificateTemplates -contains $template.Name) 
            {
                $CAName = $ca.Name
                $CADNSHostname = $ca.dNSHostname

                If ($CAIssuedBy -eq "")
                {
                    $CAIssuedBy = $CAName
                    $CAIssuedByDNS = $CADNSHostName
                } else {
                    $CAIssuedBy = $CAIssuedBy + ", $CAName"
                    $CAIssuedByDNS = $CAIssuedByDNS + ", $CADNSHostName"
                }
            }
        }

        # Check permissions
        $entry = [ADSI]"LDAP://$($template.DistinguishedName)"
        $acl = $entry.psbase.ObjectSecurity.Access
        $Insecure = $false
        $InsecureDescription = ""
        $CanAnyoneEnroll = $false
        $EnrollDescription = ""

        foreach ($ace in $acl) 
        {

                $IdentityReference = $ace.IdentityReference
                $ActiveDirectoryRights = $ace.ActiveDirectoryRights

                $LineOut = '"' + $CertTemplateName + '",'`
                            + '"' + $CanSupplySubjectName  + '",'`
                            + '"' + $CAIssuedBy  + '",'`
                            + '"' + $CAIssuedByDNS  + '",'`
                            + '"' + $IdentityReference  + '",'`
                            + '"' + $ActiveDirectoryRights  + '",'`
                            + '"' + $msPKICertificateApplicationPolicy  + '"'

                Add-Content -Path $CertificateTemplateFilename -Value $LineOut -Encoding Unicode

        }


    }
}

###################
### Get OSInfo  ###
###################
Function GetOSInfo
{

    if ($OSInfoFiles) 
    {
        WriteLog "Getting OS Information On Tier 0 Machines." $true
        foreach ($CSVFile in $OSInfoFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"
            $OperatingSystem=""

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $OperatingSystem = $ADObject.OperatingSystem
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                        $MemberServerDistinguishedName = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $ServerName

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $Name = $Row.Name
                            $Value = $Row.Value

                            $LineOut = '"' + $CurServer + '","'`
                                        + $OperatingSystem  + '","'`
                                        + $Name  + '","'`
                                        + $Value  + '","'`
                                        + $MemberServerDistinguishedName  + '","'`
                                        + $MemberServerApplication  + '","'`
                                        + $MemberServerRole  + '"'

                            Add-Content -Path $Tier0OSInfoFilename -Value $LineOut -Encoding Unicode

                        }
                    }
                }
            }
        }
    }
}


#############################
### Get DC Registry Files ###
#############################
Function GetDCRegistryFiles
{

    if ($DCRegistryFiles) 
    {
        WriteLog "Getting Domain Controller Registry Information." $true
        foreach ($CSVFile in $DCRegistryFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"
            $OperatingSystem=""

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CurTargetDC = $dicDomainDC.$ServerDomain
                    $ADObject = GetADObject $ServerShortName $CurTargetDC $ServerDomain $false

                    if ($ADObject)
                    {
                        $OperatingSystem = $ADObject.OperatingSystem
                        $MemberServerDistinguishedName = $ADObject.DistinguishedName
                        if ($MemberServerDistinguishedName)
                        {
                            if ($dicMemberServerApplication.ContainsKey($MemberServerDistinguishedName) -eq $true)
                            {
                                $MemberServerApplication = $dicMemberServerApplication.$MemberServerDistinguishedName
                                $MemberServerRole = $dicMemberServerRole.$MemberServerDistinguishedName
                            } else {
                                $MemberServerApplication = "Active Directory"
                                $MemberServerRole = "Domain Controller"
                            }
                        } else {
                            $MemberServerApplication = "n/a"
                            $MemberServerRole = "n/a"
                        }
                    } else {
                        $MemberServerApplication = "n/a"
                        $MemberServerRole = "n/a"
                        $MemberServerDistinguishedName = "n/a"
                    }

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $ServerName

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $Name = $Row.Name
                            $Value = $Row.Value

                            $LineOut = '"' + $CurServer + '","'`
                                        + $OperatingSystem  + '","'`
                                        + $Name  + '","'`
                                        + $Value  + '","'`
                                        + $MemberServerDistinguishedName  + '","'`
                                        + $MemberServerApplication  + '","'`
                                        + $MemberServerRole  + '"'

                            Add-Content -Path $DCRegistryFilename -Value $LineOut -Encoding Unicode

                        }
                    }
                }
            }
        }
    }
}

############################
### Lookup Special Group ###
############################
Function GetSpecialGroup
{
    param (
        $TargetGroup,
        $OutputFilename
    )

    WriteLog "Looking up special group: $TargetGroup." $true
    foreach ($Domain in $dicDomainFQDN.Keys)
    {
        $CurTargetDC = GetClosestDC $Domain

        $ADObject = GetADObject $TargetGroup $CurTargetDC $Domain $false

        if ($ADObject)
        {
            $DN = $ADObject.DistinguishedName
            $dicMemberDNs.Clear()
            $Global:OrigTier0DistinguishedName = $DN
            GetNestedMembers-NEW $DN "" $OutputFilename
        }
    }

}




########################
### Get Forest Users ###
########################
Function GetForestUsers
{
    WriteLog "Getting Forest Users UserAccountControl attribute." $true

    
    $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
    $domains = $forest.Domains


    foreach ($domain in $domains) 
    {
        $DomainFQDN = $domain.Name

        WriteLog "Querying domain: $DomainFQDN" $true

        $TargetDC = GetClosestDC  $DomainFQDN
        #$users = Get-ADUser -Server $TargetDC -Filter * -Properties userAccountControl, LastLogonTimestamp, msDS-SupportedEncryptionTypes
        $users = Get-ADObject -filter "objectClass -eq 'user'" -server $TargetDC -Properties sAMAccountName, userAccountControl, name, LastLogonTimestamp, msDS-SupportedEncryptionTypes, objectClass, servicePrincipalName, msDS-AllowedToDelegateTo, primarygroupID, PwdLastSet, WhenCreated, WhenChanged, OperatingSystem -ErrorAction SilentlyContinue
        $UserCount = $users.Count
        writeLog "Total Users in domain: $UserCount" $true
        
        $Counter = 0

        foreach ($user in $users) {
            $Counter = $Counter +1

            Write-Host -NoNewline $("`rUsers Read: $UserCount")

            $SamAccountName = $user.sAMAccountName
            $UserAccountControl = $user.userAccountControl
            $UACBinary = [Convert]::ToString($UserAccountControl,2)
            $UserName = $user.Name
            $LastLogonTimestamp = $user.LastLogonTimestamp
            $LastLogonTimestamp = [DateTime]::FromFileTimeutc($LastLogonTimestamp)
            $msDSSupportedEncryptionTypes = $null
            $msDSSupportedEncryptionTypes = $user.'msDS-SupportedEncryptionTypes'
            $ObjectClass = $user.ObjectClass
            $SPN = $user.serviceprincipalname
            $msDSAllowedToDelegateTo = $user.'msDS-AllowedToDelegateTo'
            $PrimaryGroup = $user.PrimaryGroupID
            $PwdLastSet = $user.PwdLastSet
            $PwdLastSet = [DateTime]::FromFileTimeutc($PwdLastSet)
            $WhenCreated = $user.WhenCreated
            $WhenChanged = $user.WhenChanged
            $OperatingSystem = $user.OperatingSystem
            $msDSSupportedEncryptionTypesBinary = [Convert]::ToString($msDSSupportedEncryptionTypes,2)

            $LineOut = '"' + $DomainFQDN + '","'`
                        + $SamAccountName  + '","'`
                        + $UserName  + '","'`
                        + $UserAccountControl  + '","'`
                        + $UACBinary  + '","'`
                        + $LastLogonTimestamp  + '","'`
                        + $msDSSupportedEncryptionTypes  + '","'`
                        + $ObjectClass  + '","'`
                        + $SPN  + '","'`
                        + $msDSAllowedToDelegateTo  + '","'`
                        + $PrimaryGroup  + '","'`
                        + $PwdLastSet  + '","'`
                        + $WhenCreated  + '","'`
                        + $WhenChanged  + '","'`
                        + $OperatingSystem  + '","'`
                        + $msDSSupportedEncryptionTypesBinary  + '"'

            Add-Content -Path $ForestUsersFilename -Value $LineOut -Encoding Unicode

        }
        WriteLog "" $true
    }
}

#######################
### Get Domain Info ###
#######################
Function GetDomainInfo
{

    writeLog "Getting Domain Information." $True

    $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
    $domains = $forest.Domains

    foreach ($domain in $domains) 
    {
        $DomainFQDN = $domain.Name
        $DomainLDAP = $dicDomainLDAP.$DomainFQDN

        $TargetDC = GetClosestDC  $DomainFQDN

        $Obj = Get-ADObject -filter "DistinguishedName -eq '$DomainLDAP'" -server $TargetDC -Properties * -ErrorAction SilentlyContinue

        if ($obj)
        {

            $msDSMachineAccountQuota = $Obj.'ms-DS-MachineAccountQuota'

            $LineOut = '"' + $DomainFQDN + '","'`
                           + $msDSMachineAccountQuota  + '"'

            Add-Content -Path $DomainInformationFilename -Value $LineOut -Encoding Unicode

        }
    }
    

}

#########################
### Get Backup Status ###
#########################
Function GetBackupStatus
{

    WriteLog "Getting Active Directory Backup Status." $true

    $DCs = (Get-ADForest).domains | %{ Get-ADDomainController -Server $_ -filter *}

    $Partitions = @{}
    $DCInvocationIDs = @{}
    $DCStatus = @{}
    $DCFQDNs = @{}

    ForEach ($DC in $DCs)
    {
        $DCFQDN = $DC.Hostname
        $InvocationID = $DC.InvocationID
        $IsOnline = test-connection -buffersize 32 -count 1 -computername $DC.Hostname -quiet

        If ($IsOnline -eq $False)
        {
            #Do Nothing
        } Else {
            ForEach ($Partition in $DC.DefaultPartition)
            {
                if ($Partitions.ContainsKey($Partition))
                {
                    #do nothing
                }
                else
                {
                    $Partitions.Add($Partition,$DCFQDN)
                }
            }
        }
        if ($DCInvocationIDs.ContainsKey($DC))
        {
            #do nothing
        }
        else
        {
            $DCInvocationIDs.Add($DC,$InvocationID)
            $DCStatus.Add($DC,$IsOnline)
            $DCFQDNs.Add($DC,$DC.Hostname)
        }
    }

    #Get Remaining Partitions
    ForEach ($DC in $DCs)
    {
        $DCFQDN = $DC.Hostname
        $InvocationID = $DC.InvocationID
        $IsOnline = $DCStatus.$DC

        If ($IsOnline -eq $False)
        {
            #Do nothing
        } Else {
            ForEach ($Partition in $DC.Partitions)
            {
                if ($Partitions.ContainsKey($Partition))
                {
                    #do nothing
                }
                else
                {
                    $Partitions.Add($Partition,$DCFQDN)
                }
            }
        }
    }

    $Now=$(Get-Date)
    $OnlineDC = ""
    $Body=""
    $Priority = "Normal"
    $StatusOut = ""

    ForEach ($Partition in $Partitions.Keys)
    {
        $DCFQDN = $Partitions.$Partition

        $ReplMeta = get-adreplicationattributemetadata -object $Partition -Properties dsasignature -Server $DCFQDN -ErrorAction SilentlyContinue
        $BackupInvocationID = $ReplMeta.LastOriginatingChangeDirectoryServerInvocationId
        $BackupDate = $ReplMeta.LastOriginatingChangeTime
        $ElapsedTime = $Now - $BackupDate
        $DaysSinceBackup = $ElapsedTime.Days
        $HoursSinceBackup = $ElapsedTime.hours + ($DaysSinceBackup * 24)
        $Version = $ReplMeta.Version
        $Body = $Body + "-->InvocationID: $BackupInvocationID`n"
        $Body = $Body + "-->BackupDate: $BackupDate`n"
        $OrigDC = ""
    
        ForEach ($DC in $DCs)
        {
            if ($DCInvocationIDs.ContainsKey($DC))
            {
                $DCInvocationID = $DCInvocationIDs.$DC
                If ($DCInvocationID -eq $BackupInvocationID)
                {
                    $OrigDC = $DCFQDNs.$DC
                }
            }
        }

        if ($Version -EQ 1)
        {
            $HoursSinceBackup = "<Never>"
        } 

        If ($OrigDC -NE "")
        {
            $OriginatingDC = $OrigDC
        } Else {
            $OriginatingDC = "<Not Found>"
        }

        $LineOut = '"' + $Partition + '","'`
                    + $BackupInvocationID  + '","'`
                    + $BackupDate  + '","'`
                    + $Version  + '","'`
                    + $HoursSinceBackup  + '","'`
                    + $OriginatingDC  + '"'

        Add-Content -Path $BackupStatusFilename -Value $LineOut -Encoding Unicode
    }
}

#######################
### Get Forest Info ###
#######################
Function GetForestInfo
{
    WriteLog "Getting Forest Information." $true
    
    $Forest = Get-ADForest

    foreach ($AppPartition in $Forest.ApplicationPartitions)
    {
        $LineOut = '"ApplicationPartition","'`
                    + $AppPartition  + '"'
        Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    }
    foreach ($Domain in $Forest.Domains)
    {
        $LineOut = '"Domain","'`
                    + $Domain  + '"'
        Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    }
    foreach ($GC in $Forest.GlobalCatalogs)
    {
        $LineOut = '"GlobalCatalog","'`
                    + $GC  + '"'
        Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    }
    foreach ($Site in $Forest.Sites)
    {
        $LineOut = '"Site","'`
                    + $Site  + '"'
        Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    }
    foreach ($SpnSuffix in $Forest.SPNSuffixes)
    {
        $LineOut = '"SPNSuffix","'`
                    + $SpnSuffix  + '"'
        Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    }
    foreach ($UpnSuffix in $Forest.UPNSuffixes)
    {
        $LineOut = '"UPNSuffix","'`
                    + $UpnSuffix  + '"'
        Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    }

    $LineOut = '"DomainNamingMaster","'`
                + $Forest.DomainNamingMaster  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    $LineOut = '"ForestMode","'`
                + $Forest.ForestMode  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    $LineOut = '"Name","'`
                + $Forest.Name  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    $LineOut = '"PartitionsContainer","'`
                + $Forest.PartitionsContainer  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    $LineOut = '"RootDomain","'`
                + $Forest.RootDomain  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    $LineOut = '"SchemaMaster","'`
                + $Forest.SchemaMaster  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode

    $configNC = (Get-ADRootDSE).configurationNamingContext
    $dsPath = "CN=Directory Service,CN=Windows NT,CN=Services,$configNC"
    $dsObject = Get-ADObject -Identity $dsPath -Properties dSHeuristics

    if ($dsObject.dSHeuristics) {
        $DSHeuristics = $dsObject.dSHeuristics
    } else {
        $DSHeuristics = "<Not Set>"
    }
    $LineOut = '"DSHeuristics","'`
                + $DSHeuristics  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode

    $feature = Get-ADOptionalFeature -Filter 'Name -like "Recycle Bin Feature"'
    $status = Get-ADOptionalFeature -Identity $feature.DistinguishedName
    if ($status.EnabledScopes.Count -gt 0) {
        $RecycleBin="Enabled"
    } else {
        $RecycleBin="Disabled"
    }
    $LineOut = '"RecycleBin","'`
                + $RecycleBin  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode

    $RootDomain = $Forest.RootDomain
    $RootDC = GetClosestDC $RootDomain

    $LegacyLAPS = Get-ADObject -SearchBase (Get-ADRootDSE).schemaNamingContext -LDAPFilter "(cn=ms-Mcs-AdmPwd)" -Server $RootDC
    if ($LegacyLAPs)
    {
        $IsLegacyLAPS = $true
    } else {
        $IsLegacyLAPS = $false
    }

    $LegacyLAPS = Get-ADObject -SearchBase (Get-ADRootDSE).schemaNamingContext -LDAPFilter "(cn=ms-LAPS-Password)" -Server $RootDC
    if ($LegacyLAPs)
    {
        $IsWindowsLAPS = $true
    } else {
        $IsWindowsLAPS = $false
    }
    $LineOut = '"LegacyLAPS","'`
             + $IsLegacyLaps  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode
    $LineOut = '"WindowsLAPS","'`
             + $IsWindowsLAPS  + '"'
    Add-Content -Path $ForestInformationFilename -Value $LineOut -Encoding Unicode

}

######################
### Get Partitions ###
######################
Function GetPartitions
{
    $dicDNSZones = @{}

    $configNC = (Get-ADRootDSE).configurationNamingContext
    $partitionsDN = "CN=Partitions,$configNC"
    $crossRefs = Get-ADObject -SearchBase $partitionsDN -LDAPFilter "(objectClass=crossRef)" -Properties *
    Foreach ($Partition in $crossRefs)
    {
        $PartitionName = $Partition.name
        $PartitionNCName = $Partition.ncName
        $PartitionSystemFlags = $Partition.systemFlags
        $PartitionDNSRoot = $Partition.dnsRoot
        $PartitionNetbiosName = $Partition.netBIOSName
        $PartitionWhenCreated = $Partition.WhenCreated
        $PartitionWhenChanged = $Partition.WhenChanged

        $LineOut = '"' + $PartitionName + '","'`
                    + $PartitionNCName  + '","'`
                    + $PartitionSystemFlags  + '","'`
                    + $PartitionDNSRoot  + '","'`
                    + $PartitionNetbiosName  + '","'`
                    + $PartitionWhenCreated  + '","'`
                    + $PartitionWhenChanged  + '"'

        Add-Content -Path $PartitionsFilename -Value $LineOut -Encoding Unicode

        # Find any dnsZones in the partition and get permissions
        $dnsContainer = $PartitionNCName
        try
        {
            $dnsZones = Get-ADObject -searchBase $dnsContainer -LDAPFilter "(objectClass=dnsZone)" -Properties * -ErrorAction SilentlyContinue
        } catch {

        }

        foreach ($dnsZone in $dnsZones)
        {
            $dnsZoneDN = $dnsZone.DistinguishedName

            $IsTrustAnchor=$dnsZoneDN.Substring(0,18)
            
            if ($dicDNSZones.ContainsKey($dnsZoneDN) -eq $false -and $IsTrustAnchor -NE "DC=..TrustAnchors,")
            {
                $dicDNSZones.Add($dnsZoneDN,"")
                
                # Check permissions
                $entry = [ADSI]"LDAP://$dnsZoneDN"
                $acl = $entry.psbase.ObjectSecurity.Access

                foreach ($ace in $acl) 
                {

                        $IdentityReference = $ace.IdentityReference
                        $ActiveDirectoryRights = $ace.ActiveDirectoryRights

                        $LineOut = '"' + $dnsContainer + '",'`
                                    + '"' + $dnsZoneDN  + '",'`
                                    + '"' + $IdentityReference  + '",'`
                                    + '"' + $ActiveDirectoryRights  + '"'

                        Add-Content -Path $DNSZonesFilename -Value $LineOut -Encoding Unicode

                }
            }
        }

    }
}

####################################
### Get Credential Guard Status  ###
####################################
Function GetCredentialGuardStatus
{

    if ($CredGuardFiles) 
    {
        WriteLog "Getting Credential Guard Status On Tier 0 Machines." $true
        foreach ($CSVFile in $CredGuardFiles)
        {

            $CSVFilename = $CSVFile.Name
            $Index = $CSVFilename.IndexOf("-")
            $Length = $CSVFilename.Length
            $AppliedLength = $Length - ($Index + 1)
            $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

            $Index1 = $ServerName.IndexOf(".")
            $Index2 = $ServerName.LastIndexOf(".")
            $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

            $Length = $ServerName.Length
            $ServerName = $ServerName.Substring(0,($Length-4))

            $Index = $ServerName.IndexOf(".")
            $ServerShortName = $ServerName.Substring(0,$Index) + "$"
            $CredGuardStatus=""

            if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain -or $MasterRootDomain -eq $ServerDomain)
            {
                if ($dicDcFQDN.ContainsKey($ServerName) -eq $True -or $dicMemberServerFQDN.ContainsKey($ServerName) -or $IncludeAllServers.IsPresent -eq $true)
                {
                    WriteLog "Reading $CSVFile" $true

                    $CSV = Import-Csv $CSVFile
                    foreach ($Row in $CSV) 
                    {
                        $CurServer = $ServerName

                        if ($IncludeAllServers.IsPresent -eq $true -or $dicMemberServerFQDN.ContainsKey($CurServer) -eq $true -or $dicDcFQDN.ContainsKey($CurServer) -eq $true)
                        {

                            $CredGuardStatus = $Row.CredentialGuardEnabled

                            $LineOut = '"' + $CurServer + '","'`
                                        + $CredGuardStatus  + '"'

                            Add-Content -Path $CredGuardFilename -Value $LineOut -Encoding Unicode

                        }
                    }
                }
            }
        }
    }
}


############
### Main ###
############
WriteLog "" $true
WriteLog "CollectionMode: $CollectionMode" $true
WriteLog "IncludeNested: $IncludeNested" $true
if ($ResultSetSize -eq $null)
{
    WriteLog "ResultSetSize: null" $true
} else {
    WriteLog "ResultSetSize: $ResultSetSize" $true
}

DetermineIfPreferredDCsHaveBeenDefined
ReadTier0GroupRIDsFile


########################
### Read DCINFO File ###
########################
WriteLog "Reading $DCInfoFile" $true
$CSV = Import-Csv $DCInfoFile

foreach ($DC in $CSV)
{
    $DomainControllerFQDN = $DC.DomainControllerFQDN
    $DomainControllerDistinguishedName = $DC.DomainControllerDistinguishedName
    $DomainControllerContainer = $DC.DomainControllerContainer
    $DomainControllerShortName = $DC.DomainControllerShortName
    $DomainFQDN = $DC.DomainFQDN
    $DomainLDAP = $DC.DomainLDAP
    $DomainNetBIOSName = $DC.DomainNetBIOSName
    $DCSID = $DC.DomainControllerSID
    $IsRootDomain = $DC.DomainRoot

    $Index = $DCSID.LastIndexOf("-")
    $Length = $DCSID.Length + 1
    $AppliedLength = $Length - ($Index+1)
    $DomainSID = $DCSID.Substring(0,$Index)
    
    if ($IsRootDomain -eq $true)
    {
        $MasterRootDomain = $DomainFQDN
        $MasterRootDomainLDAP = $DomainLDAP
    }
   
    WriteLog "DomainControllerFQDN: $DomainControllerFQDN"
    WriteLog "DomainControllerDistinguishedName: $DomainControllerDistinguishedName"
    WriteLog "DomainControllerContainer: $DomainControllerContainer"
    WriteLog "DomainControllerShortName: $DomainControllerShortName"
    WriteLog "DomainFQDN: $DomainFQDN"
    WriteLog "DomainLDAP: $DomainLDAP"
    WriteLog "DomainNetBIOSName: $DomainNetBIOSName"
    
    if ($dicDomainFQDN.ContainsKey($DomainFQDN) -eq $false) 
    {
        $dicDomainFQDN.Add($DomainFQDN,$DomainLDAP)
    }
    if ($dicDomainLDAP.ContainsKey($DomainFQDN) -eq $false) 
    {
        $dicDomainLDAP.Add($DomainFQDN,$DomainLDAP)
    }
    if ($dicDcDistinguishedName.ContainsKey($DomainControllerDistinguishedName) -eq $false) 
    {
        $dicDcDistinguishedName.Add($DomainControllerDistinguishedName,$DomainControllerContainer)
    }
    if ($dicDcFQDN.ContainsKey($DomainControllerFQDN) -eq $false) 
    {
        $dicDcFQDN.Add($DomainControllerFQDN,$DomainControllerShortName)
    }
    if ($dicTier0Containers.ContainsKey($DomainControllerContainer) -eq $false) 
    {
        $dicTier0Containers.Add($DomainControllerContainer,"container")
    }
    if ($dicTier0DistinguishedNames.ContainsKey($DomainControllerDistinguishedName) -eq $false) 
    {
        $dicTier0DistinguishedNames.Add($DomainControllerDistinguishedName,"computer")
    }

    if ($dicDomainDC.ContainsKey($DomainFQDN) -eq $false) 
    {
        $TargetDC = GetClosestDC $DomainFQDN

        $TargetDCFQDN = $TargetDC
        WriteLog "TargetDC: $TargetDC"
        WriteLog "TargetDCFQDN: $TargetDCFQDN"
        $dictmpDCs.Add($DomainFQDN,$TargetDCFQDN)
        $dicDomainSIDs.Add($DomainSID,$TargetDCFQDN)



        if ($dicADDriveMapping.ContainsKey($DomainFQDN) -eq $false)
        {

            $ADDriveNumber = $ADDriveNumber + 1

            switch ($ADDriveNumber) {
                2 { New-PSDrive -Name AD2 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                3 { New-PSDrive -Name AD3 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                4 { New-PSDrive -Name AD4 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                5 { New-PSDrive -Name AD5 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                6 { New-PSDrive -Name AD6 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                7 { New-PSDrive -Name AD7 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                8 { New-PSDrive -Name AD8 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                9 { New-PSDrive -Name AD9 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                10 { New-PSDrive -Name AD10 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                11 { New-PSDrive -Name AD11 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                12 { New-PSDrive -Name AD12 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                13 { New-PSDrive -Name AD13 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                14 { New-PSDrive -Name AD14 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                15 { New-PSDrive -Name AD15 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                16 { New-PSDrive -Name AD16 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                17 { New-PSDrive -Name AD17 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                18 { New-PSDrive -Name AD18 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                19 { New-PSDrive -Name AD19 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                20 { New-PSDrive -Name AD20 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                21 { New-PSDrive -Name AD21 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                22 { New-PSDrive -Name AD22 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                23 { New-PSDrive -Name AD23 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                24 { New-PSDrive -Name AD24 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                25 { New-PSDrive -Name AD25 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                26 { New-PSDrive -Name AD26 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                27 { New-PSDrive -Name AD27 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                28 { New-PSDrive -Name AD28 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                29 { New-PSDrive -Name AD29 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                30 { New-PSDrive -Name AD30 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                31 { New-PSDrive -Name AD31 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                32 { New-PSDrive -Name AD32 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                33 { New-PSDrive -Name AD33 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                34 { New-PSDrive -Name AD34 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                35 { New-PSDrive -Name AD35 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                36 { New-PSDrive -Name AD36 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                37 { New-PSDrive -Name AD37 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                38 { New-PSDrive -Name AD38 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                39 { New-PSDrive -Name AD39 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                40 { New-PSDrive -Name AD40 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                41 { New-PSDrive -Name AD41 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                42 { New-PSDrive -Name AD42 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                43 { New-PSDrive -Name AD43 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                44 { New-PSDrive -Name AD44 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                45 { New-PSDrive -Name AD45 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                46 { New-PSDrive -Name AD46 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                47 { New-PSDrive -Name AD47 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                48 { New-PSDrive -Name AD48 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                49 { New-PSDrive -Name AD49 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                50 { New-PSDrive -Name AD50 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                51 { New-PSDrive -Name AD51 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                52 { New-PSDrive -Name AD52 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                53 { New-PSDrive -Name AD53 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                54 { New-PSDrive -Name AD54 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                55 { New-PSDrive -Name AD55 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                56 { New-PSDrive -Name AD56 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                57 { New-PSDrive -Name AD57 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                58 { New-PSDrive -Name AD58 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                59 { New-PSDrive -Name AD59 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                60 { New-PSDrive -Name AD60 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                61 { New-PSDrive -Name AD61 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                62 { New-PSDrive -Name AD62 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                63 { New-PSDrive -Name AD63 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                64 { New-PSDrive -Name AD64 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                65 { New-PSDrive -Name AD65 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                66 { New-PSDrive -Name AD66 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                67 { New-PSDrive -Name AD67 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                68 { New-PSDrive -Name AD68 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                69 { New-PSDrive -Name AD69 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                70 { New-PSDrive -Name AD70 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                71 { New-PSDrive -Name AD71 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                72 { New-PSDrive -Name AD72 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                73 { New-PSDrive -Name AD73 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                74 { New-PSDrive -Name AD74 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                75 { New-PSDrive -Name AD75 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                76 { New-PSDrive -Name AD76 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                77 { New-PSDrive -Name AD77 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                78 { New-PSDrive -Name AD78 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                79 { New-PSDrive -Name AD79 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                80 { New-PSDrive -Name AD80 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                81 { New-PSDrive -Name AD81 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                82 { New-PSDrive -Name AD82 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                83 { New-PSDrive -Name AD83 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                84 { New-PSDrive -Name AD84 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                85 { New-PSDrive -Name AD85 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                86 { New-PSDrive -Name AD86 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                87 { New-PSDrive -Name AD87 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                88 { New-PSDrive -Name AD88 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                89 { New-PSDrive -Name AD89 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                90 { New-PSDrive -Name AD90 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                91 { New-PSDrive -Name AD91 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                92 { New-PSDrive -Name AD92 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                93 { New-PSDrive -Name AD93 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                94 { New-PSDrive -Name AD94 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                95 { New-PSDrive -Name AD95 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                96 { New-PSDrive -Name AD96 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                97 { New-PSDrive -Name AD97 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                98 { New-PSDrive -Name AD98 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                99 { New-PSDrive -Name AD99 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                100 { New-PSDrive -Name AD100 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                101 { New-PSDrive -Name AD101 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                102 { New-PSDrive -Name AD102 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                103 { New-PSDrive -Name AD103 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                104 { New-PSDrive -Name AD104 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                105 { New-PSDrive -Name AD105 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                106 { New-PSDrive -Name AD106 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                107 { New-PSDrive -Name AD107 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                108 { New-PSDrive -Name AD108 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                109 { New-PSDrive -Name AD109 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                110 { New-PSDrive -Name AD110 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                111 { New-PSDrive -Name AD111 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                112 { New-PSDrive -Name AD112 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                113 { New-PSDrive -Name AD113 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                114 { New-PSDrive -Name AD114 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                115 { New-PSDrive -Name AD115 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                116 { New-PSDrive -Name AD116 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                117 { New-PSDrive -Name AD117 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                118 { New-PSDrive -Name AD118 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                119 { New-PSDrive -Name AD119 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                120 { New-PSDrive -Name AD120 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                121 { New-PSDrive -Name AD121 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                122 { New-PSDrive -Name AD122 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                123 { New-PSDrive -Name AD123 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                124 { New-PSDrive -Name AD124 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                125 { New-PSDrive -Name AD125 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                126 { New-PSDrive -Name AD126 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                127 { New-PSDrive -Name AD127 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                128 { New-PSDrive -Name AD128 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                129 { New-PSDrive -Name AD129 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                130 { New-PSDrive -Name AD130 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                131 { New-PSDrive -Name AD131 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                132 { New-PSDrive -Name AD132 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                133 { New-PSDrive -Name AD133 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                134 { New-PSDrive -Name AD134 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                135 { New-PSDrive -Name AD135 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                136 { New-PSDrive -Name AD136 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                137 { New-PSDrive -Name AD137 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                138 { New-PSDrive -Name AD138 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                139 { New-PSDrive -Name AD139 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                140 { New-PSDrive -Name AD140 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                141 { New-PSDrive -Name AD141 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                142 { New-PSDrive -Name AD142 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                143 { New-PSDrive -Name AD143 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                144 { New-PSDrive -Name AD144 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                145 { New-PSDrive -Name AD145 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                146 { New-PSDrive -Name AD146 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                147 { New-PSDrive -Name AD147 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                148 { New-PSDrive -Name AD148 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                149 { New-PSDrive -Name AD149 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                150 { New-PSDrive -Name AD150 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                151 { New-PSDrive -Name AD151 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                152 { New-PSDrive -Name AD152 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                153 { New-PSDrive -Name AD153 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                154 { New-PSDrive -Name AD154 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                155 { New-PSDrive -Name AD155 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                156 { New-PSDrive -Name AD156 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                157 { New-PSDrive -Name AD157 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                158 { New-PSDrive -Name AD158 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                159 { New-PSDrive -Name AD159 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                160 { New-PSDrive -Name AD160 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                161 { New-PSDrive -Name AD161 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                162 { New-PSDrive -Name AD162 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                163 { New-PSDrive -Name AD163 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                164 { New-PSDrive -Name AD164 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                165 { New-PSDrive -Name AD165 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                166 { New-PSDrive -Name AD166 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                167 { New-PSDrive -Name AD167 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                168 { New-PSDrive -Name AD168 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                169 { New-PSDrive -Name AD169 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                170 { New-PSDrive -Name AD170 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                171 { New-PSDrive -Name AD171 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                172 { New-PSDrive -Name AD172 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                173 { New-PSDrive -Name AD173 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                174 { New-PSDrive -Name AD174 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                175 { New-PSDrive -Name AD175 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                176 { New-PSDrive -Name AD176 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                177 { New-PSDrive -Name AD177 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                178 { New-PSDrive -Name AD178 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                179 { New-PSDrive -Name AD179 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                180 { New-PSDrive -Name AD180 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                181 { New-PSDrive -Name AD181 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                182 { New-PSDrive -Name AD182 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                183 { New-PSDrive -Name AD183 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                184 { New-PSDrive -Name AD184 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                185 { New-PSDrive -Name AD185 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                186 { New-PSDrive -Name AD186 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                187 { New-PSDrive -Name AD187 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                188 { New-PSDrive -Name AD188 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                189 { New-PSDrive -Name AD189 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                190 { New-PSDrive -Name AD190 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                191 { New-PSDrive -Name AD191 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                192 { New-PSDrive -Name AD192 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                193 { New-PSDrive -Name AD193 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                194 { New-PSDrive -Name AD194 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                195 { New-PSDrive -Name AD195 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                196 { New-PSDrive -Name AD196 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                197 { New-PSDrive -Name AD197 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                198 { New-PSDrive -Name AD198 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                199 { New-PSDrive -Name AD199 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                200 { New-PSDrive -Name AD200 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                201 { New-PSDrive -Name AD201 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                202 { New-PSDrive -Name AD202 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                203 { New-PSDrive -Name AD203 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                204 { New-PSDrive -Name AD204 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                205 { New-PSDrive -Name AD205 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                206 { New-PSDrive -Name AD206 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                207 { New-PSDrive -Name AD207 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                208 { New-PSDrive -Name AD208 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                209 { New-PSDrive -Name AD209 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                210 { New-PSDrive -Name AD210 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                211 { New-PSDrive -Name AD211 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                212 { New-PSDrive -Name AD212 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                213 { New-PSDrive -Name AD213 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                214 { New-PSDrive -Name AD214 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                215 { New-PSDrive -Name AD215 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                216 { New-PSDrive -Name AD216 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                217 { New-PSDrive -Name AD217 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                218 { New-PSDrive -Name AD218 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                219 { New-PSDrive -Name AD219 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                220 { New-PSDrive -Name AD220 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                221 { New-PSDrive -Name AD221 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                222 { New-PSDrive -Name AD222 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                223 { New-PSDrive -Name AD223 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                224 { New-PSDrive -Name AD224 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                225 { New-PSDrive -Name AD225 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                226 { New-PSDrive -Name AD226 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                227 { New-PSDrive -Name AD227 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                228 { New-PSDrive -Name AD228 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                229 { New-PSDrive -Name AD229 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                230 { New-PSDrive -Name AD230 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                231 { New-PSDrive -Name AD231 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                232 { New-PSDrive -Name AD232 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                233 { New-PSDrive -Name AD233 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                234 { New-PSDrive -Name AD234 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                235 { New-PSDrive -Name AD235 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                236 { New-PSDrive -Name AD236 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                237 { New-PSDrive -Name AD237 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                238 { New-PSDrive -Name AD238 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                239 { New-PSDrive -Name AD239 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                240 { New-PSDrive -Name AD240 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                241 { New-PSDrive -Name AD241 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                242 { New-PSDrive -Name AD242 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                243 { New-PSDrive -Name AD243 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                244 { New-PSDrive -Name AD244 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                245 { New-PSDrive -Name AD245 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                246 { New-PSDrive -Name AD246 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                247 { New-PSDrive -Name AD247 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                248 { New-PSDrive -Name AD248 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                249 { New-PSDrive -Name AD249 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                250 { New-PSDrive -Name AD250 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                251 { New-PSDrive -Name AD251 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                252 { New-PSDrive -Name AD252 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                253 { New-PSDrive -Name AD253 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                254 { New-PSDrive -Name AD254 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                255 { New-PSDrive -Name AD255 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                256 { New-PSDrive -Name AD256 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                257 { New-PSDrive -Name AD257 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                258 { New-PSDrive -Name AD258 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                259 { New-PSDrive -Name AD259 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                260 { New-PSDrive -Name AD260 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                261 { New-PSDrive -Name AD261 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                262 { New-PSDrive -Name AD262 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                263 { New-PSDrive -Name AD263 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                264 { New-PSDrive -Name AD264 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                265 { New-PSDrive -Name AD265 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                266 { New-PSDrive -Name AD266 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                267 { New-PSDrive -Name AD267 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                268 { New-PSDrive -Name AD268 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                269 { New-PSDrive -Name AD269 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                270 { New-PSDrive -Name AD270 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                271 { New-PSDrive -Name AD271 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                272 { New-PSDrive -Name AD272 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                273 { New-PSDrive -Name AD273 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                274 { New-PSDrive -Name AD274 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                275 { New-PSDrive -Name AD275 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                276 { New-PSDrive -Name AD276 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                277 { New-PSDrive -Name AD277 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                278 { New-PSDrive -Name AD278 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                279 { New-PSDrive -Name AD279 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                280 { New-PSDrive -Name AD280 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                281 { New-PSDrive -Name AD281 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                282 { New-PSDrive -Name AD282 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                283 { New-PSDrive -Name AD283 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                284 { New-PSDrive -Name AD284 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                285 { New-PSDrive -Name AD285 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                286 { New-PSDrive -Name AD286 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                287 { New-PSDrive -Name AD287 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                288 { New-PSDrive -Name AD288 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                289 { New-PSDrive -Name AD289 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                290 { New-PSDrive -Name AD290 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                291 { New-PSDrive -Name AD291 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                292 { New-PSDrive -Name AD292 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                293 { New-PSDrive -Name AD293 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                294 { New-PSDrive -Name AD294 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                295 { New-PSDrive -Name AD295 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                296 { New-PSDrive -Name AD296 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                297 { New-PSDrive -Name AD297 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                298 { New-PSDrive -Name AD298 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                299 { New-PSDrive -Name AD299 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                300 { New-PSDrive -Name AD300 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                301 { New-PSDrive -Name AD301 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                302 { New-PSDrive -Name AD302 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                303 { New-PSDrive -Name AD303 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                304 { New-PSDrive -Name AD304 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                305 { New-PSDrive -Name AD305 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                306 { New-PSDrive -Name AD306 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                307 { New-PSDrive -Name AD307 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                308 { New-PSDrive -Name AD308 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                309 { New-PSDrive -Name AD309 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                310 { New-PSDrive -Name AD310 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                311 { New-PSDrive -Name AD311 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                312 { New-PSDrive -Name AD312 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                313 { New-PSDrive -Name AD313 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                314 { New-PSDrive -Name AD314 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                315 { New-PSDrive -Name AD315 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                316 { New-PSDrive -Name AD316 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                317 { New-PSDrive -Name AD317 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                318 { New-PSDrive -Name AD318 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                319 { New-PSDrive -Name AD319 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                320 { New-PSDrive -Name AD320 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                321 { New-PSDrive -Name AD321 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                322 { New-PSDrive -Name AD322 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                323 { New-PSDrive -Name AD323 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                324 { New-PSDrive -Name AD324 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                325 { New-PSDrive -Name AD325 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                326 { New-PSDrive -Name AD326 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                327 { New-PSDrive -Name AD327 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                328 { New-PSDrive -Name AD328 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                329 { New-PSDrive -Name AD329 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                330 { New-PSDrive -Name AD330 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                331 { New-PSDrive -Name AD331 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                332 { New-PSDrive -Name AD332 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                333 { New-PSDrive -Name AD333 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                334 { New-PSDrive -Name AD334 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                335 { New-PSDrive -Name AD335 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                336 { New-PSDrive -Name AD336 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                337 { New-PSDrive -Name AD337 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                338 { New-PSDrive -Name AD338 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                339 { New-PSDrive -Name AD339 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                340 { New-PSDrive -Name AD340 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                341 { New-PSDrive -Name AD341 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                342 { New-PSDrive -Name AD342 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                343 { New-PSDrive -Name AD343 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                344 { New-PSDrive -Name AD344 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                345 { New-PSDrive -Name AD345 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                346 { New-PSDrive -Name AD346 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                347 { New-PSDrive -Name AD347 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                348 { New-PSDrive -Name AD348 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                349 { New-PSDrive -Name AD349 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                350 { New-PSDrive -Name AD350 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                351 { New-PSDrive -Name AD351 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                352 { New-PSDrive -Name AD352 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                353 { New-PSDrive -Name AD353 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                354 { New-PSDrive -Name AD354 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                355 { New-PSDrive -Name AD355 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                356 { New-PSDrive -Name AD356 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                357 { New-PSDrive -Name AD357 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                358 { New-PSDrive -Name AD358 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                359 { New-PSDrive -Name AD359 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                360 { New-PSDrive -Name AD360 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                361 { New-PSDrive -Name AD361 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                362 { New-PSDrive -Name AD362 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                363 { New-PSDrive -Name AD363 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                364 { New-PSDrive -Name AD364 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                365 { New-PSDrive -Name AD365 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                366 { New-PSDrive -Name AD366 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                367 { New-PSDrive -Name AD367 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                368 { New-PSDrive -Name AD368 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                369 { New-PSDrive -Name AD369 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                370 { New-PSDrive -Name AD370 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                371 { New-PSDrive -Name AD371 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                372 { New-PSDrive -Name AD372 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                373 { New-PSDrive -Name AD373 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                374 { New-PSDrive -Name AD374 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                375 { New-PSDrive -Name AD375 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                376 { New-PSDrive -Name AD376 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                377 { New-PSDrive -Name AD377 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                378 { New-PSDrive -Name AD378 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                379 { New-PSDrive -Name AD379 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                380 { New-PSDrive -Name AD380 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                381 { New-PSDrive -Name AD381 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                382 { New-PSDrive -Name AD382 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                383 { New-PSDrive -Name AD383 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                384 { New-PSDrive -Name AD384 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                385 { New-PSDrive -Name AD385 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                386 { New-PSDrive -Name AD386 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                387 { New-PSDrive -Name AD387 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                388 { New-PSDrive -Name AD388 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                389 { New-PSDrive -Name AD389 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                390 { New-PSDrive -Name AD390 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                391 { New-PSDrive -Name AD391 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }

                392 { New-PSDrive -Name AD392 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                393 { New-PSDrive -Name AD393 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                394 { New-PSDrive -Name AD394 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                395 { New-PSDrive -Name AD395 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                396 { New-PSDrive -Name AD396 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                397 { New-PSDrive -Name AD397 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                398 { New-PSDrive -Name AD398 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                399 { New-PSDrive -Name AD399 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                400 { New-PSDrive -Name AD400 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }
                401 { New-PSDrive -Name AD401 -PSProvider ActiveDirectory -Server $TargetDCFQDN -root "//RootDSE/" }


            }

            $dicADDriveMapping.add($DomainFQDN, $ADDriveNumber)
        }
        
    }
    if ($dicDomainNetBIOSNameByDomain.ContainsKey($DomainFQDN) -eq $false)
    {
        $dicDomainNetBIOSNameByDomain.Add($DomainFQDN,$DomainNetBIOSName)
    }
    if ($dicDomainNetBIOSNameByNetBIOSName.ContainsKey($DomainNetBIOSName) -eq $false)
    {
        $dicDomainNetBIOSNameByNetBIOSName.Add($DomainNetBIOSName,$TargetDCFQDN)
    }
    write-host ""
}

DetermineTrustRelationships
LookupKrbTGTAccount
ReadTier0MemberServersCSVFile
ReadTier0CustomGroups
GetTier0MemberServerGroupMembership
ReadTier0WellKnownGroupMembership
ReadTier0URAFile
ReadTier0GroupDNFile
QuerySchemaRights
WriteTier0DistinguishedNamesFile
WriteTier0ContainersFile
GetTier0SecurityPrincipalADPermissions           
GetTier0ContainerPermissions                     
GetTier0DomainRootPermissions                    
GetTier0AdminSDHolderPermissions                 
GetTier0ConfigurationNamingContextPermissions    
GetTier0SchemaNamingContextPermissions           
GetGPOsLinkedToTier0Containers                   
GetTier0GPOPermissions                           
GetNonTier0AdminCount
GetObjectsWithSIDHistory
GetRegistryPermissions                           
GetSharePermissions                              
GetTrustRelationships
GetServices
GetScheduledTasks
GetInstalledSoftware
GetWindowsFeatures
GetHotfixes
GetLocalUsers
ScanCertificateTemplates
GetOSInfo
GetDCRegistryFiles
ExpandGroupMembership $IndirectGroupsFilename
GetSpecialGroup "Protected Users" $SpecialGroupsFilename
GetSpecialGroup "Guests" $SpecialGroupsFilename
CreateAccountDispositionFile
GetForestUsers
GetDomainInfo
GetBackupStatus
GetForestInfo
GetPartitions
GetCredentialGuardStatus


$EndTime = Get-Date
$ElapsedTime = $EndTime - $StartTime
WriteLog "Elapsed time: $ElapsedTime" $true
WriteLog "" $true



# SIG # Begin signature block
# MIIoPAYJKoZIhvcNAQcCoIIoLTCCKCkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBsFa+kqJFz5R55
# y3Jq5EkCw5fttXaSeU0xJktDZPXXPaCCDYUwggYDMIID66ADAgECAhMzAAAEhJji
# EuB4ozFdAAAAAASEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM1WhcNMjYwNjE3MTgyMTM1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDtekqMKDnzfsyc1T1QpHfFtr+rkir8ldzLPKmMXbRDouVXAsvBfd6E82tPj4Yz
# aSluGDQoX3NpMKooKeVFjjNRq37yyT/h1QTLMB8dpmsZ/70UM+U/sYxvt1PWWxLj
# MNIXqzB8PjG6i7H2YFgk4YOhfGSekvnzW13dLAtfjD0wiwREPvCNlilRz7XoFde5
# KO01eFiWeteh48qUOqUaAkIznC4XB3sFd1LWUmupXHK05QfJSmnei9qZJBYTt8Zh
# ArGDh7nQn+Y1jOA3oBiCUJ4n1CMaWdDhrgdMuu026oWAbfC3prqkUn8LWp28H+2S
# LetNG5KQZZwvy3Zcn7+PQGl5AgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUBN/0b6Fh6nMdE4FAxYG9kWCpbYUw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwNTM2MjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGLQps1XU4RTcoDIDLP6QG3NnRE3p/WSMp61Cs8Z+JUv3xJWGtBzYmCINmHVFv6i
# 8pYF/e79FNK6P1oKjduxqHSicBdg8Mj0k8kDFA/0eU26bPBRQUIaiWrhsDOrXWdL
# m7Zmu516oQoUWcINs4jBfjDEVV4bmgQYfe+4/MUJwQJ9h6mfE+kcCP4HlP4ChIQB
# UHoSymakcTBvZw+Qst7sbdt5KnQKkSEN01CzPG1awClCI6zLKf/vKIwnqHw/+Wvc
# Ar7gwKlWNmLwTNi807r9rWsXQep1Q8YMkIuGmZ0a1qCd3GuOkSRznz2/0ojeZVYh
# ZyohCQi1Bs+xfRkv/fy0HfV3mNyO22dFUvHzBZgqE5FbGjmUnrSr1x8lCrK+s4A+
# bOGp2IejOphWoZEPGOco/HEznZ5Lk6w6W+E2Jy3PHoFE0Y8TtkSE4/80Y2lBJhLj
# 27d8ueJ8IdQhSpL/WzTjjnuYH7Dx5o9pWdIGSaFNYuSqOYxrVW7N4AEQVRDZeqDc
# fqPG3O6r5SNsxXbd71DCIQURtUKss53ON+vrlV0rjiKBIdwvMNLQ9zK0jy77owDy
# XXoYkQxakN2uFIBO1UNAvCYXjs4rw3SRmBX9qiZ5ENxcn/pLMkiyb68QdwHUXz+1
# fI6ea3/jjpNPz6Dlc/RMcXIWeMMkhup/XEbwu73U+uz/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAASEmOIS4HijMV0AAAAA
# BIQwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJqf
# b4rH7o0Erz4cgnqvuZr8U1n6cF9kJ1OBvsOS6NOrMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAFKE/ic3rxGfEPo3QlPRzHvRfc28Bs/cEizKJ
# 6g5YmP0fXGifDa0pA/ROUy0CQOXXlPU2gqZKnxQboheopRkOP/aFO2OQO4XmJvaC
# bwcDNeRepgFOi16w/1jyoQHhhKppoIiQqJaol5OK1PJas+vdXPnjESQNcMB+MqOu
# moJIukm1YiSqDcXueZaytVaK6ZHJQoNJ7SHNSlA+XkWoyjrLIly/Iz8/AcjaTJCu
# oaiwjAGjCG5gVgtN2DXabcOV87Mr6bovuuf5plOislw0lqPueKAejHL4nr99BXAo
# 1CHmSUH46yxlM4zs2sm0kCPdxMqA7Rxc1YDlyG17Rdb6f3tZeqGCF5cwgheTBgor
# BgEEAYI3AwMBMYIXgzCCF38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFSBgsqhkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCB0fumBslmu5SyiTTHCf7Qa9YKZwl5qfnC2
# BezVFeeGFQIGaErhv1mPGBMyMDI1MDcyOTE4MjgzMi45MzRaMASAAgH0oIHRpIHO
# MIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxk
# IFRTUyBFU046QTAwMC0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFNlcnZpY2WgghHtMIIHIDCCBQigAwIBAgITMwAAAgh4nVhdksfZUgAB
# AAACCDANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDAeFw0yNTAxMzAxOTQyNTNaFw0yNjA0MjIxOTQyNTNaMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046QTAwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC1y3AI5lIz3Ip1nK5BMUUb
# GRsjSnCz/VGs33zvY0NeshsPgfld3/Z3/3dS8WKBLlDlosmXJOZlFSiNXUd6DTJx
# A9ik/ZbCdWJ78LKjbN3tFkX2c6RRpRMpA8sq/oBbRryP3c8Q/gxpJAKHHz8cuSn7
# ewfCLznNmxqliTk3Q5LHqz2PjeYKD/dbKMBT2TAAWAvum4z/HXIJ6tFdGoNV4WUR
# ZswCSt6ROwaqQ1oAYGvEndH+DXZq1+bHsgvcPNCdTSIpWobQiJS/UKLiR02KNCqB
# 4I9yajFTSlnMIEMz/Ni538oGI64phcvNpUe2+qaKWHZ8d4T1KghvRmSSF4YF5DNE
# JbxaCUwsy7nULmsFnTaOjVOoTFWWfWXvBuOKkBcQKWGKvrki976j4x+5ezAP36fq
# 3u6dHRJTLZAu4dEuOooU3+kMZr+RBYWjTHQCKV+yZ1ST0eGkbHXoA2lyyRDlNjBQ
# coeZIxWCZts/d3+nf1jiSLN6f6wdHaUz0ADwOTQ/aEo1IC85eFePvyIKaxFJkGU2
# Mqa6Xzq3qCq5tokIHtjhogsrEgfDKTeFXTtdhl1IPtLcCfMcWOGGAXosVUU7G948
# F6W96424f2VHD8L3FoyAI9+r4zyIQUmqiESzuQWeWpTTjFYwCmgXaGOuSDV8cNOV
# QB6IPzPneZhVTjwxbAZlaQIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFKMx4vfOqcUT
# gYOVB9f18/mhegFNMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQBRszKJKwAfswqd
# aQPFiaYB/ZNAYWDa040XTcQsCaCua5nsG1IslYaSpH7miTLr6eQEqXczZoqeOa/x
# vDnMGifGNda0CHbQwtpnIhsutrKO2jhjEaGwlJgOMql21r7Ik6XnBza0e3hBOu4U
# BkMl/LEX+AURt7i7+RTNsGN0cXPwPSbTFE+9z7WagGbY9pwUo/NxkGJseqGCQ/9K
# 2VMU74bw5e7+8IGUhM2xspJPqnSeHPhYmcB0WclOxcVIfj/ZuQvworPbTEEYDVCz
# SN37c0yChPMY7FJ+HGFBNJxwd5lKIr7GYfq8a0gOiC2ljGYlc4rt4cCed1XKg83f
# 0l9aUVimWBYXtfNebhpfr6Lc3jD8NgsrDhzt0WgnIdnTZCi7jxjsIBilH99pY5/h
# 6bQcLKK/E6KCP9E1YN78fLaOXkXMyO6xLrvQZ+uCSi1hdTufFC7oSB/CU5RbfIVH
# XG0j1o2n1tne4eCbNfKqUPTE31tNbWBR23Yiy0r3kQmHeYE1GLbL4pwknqaip1BR
# n6WIUMJtgncawEN33f8AYGZ4a3NnHopzGVV6neffGVag4Tduy+oy1YF+shChoXdM
# qfhPWFpHe3uJGT4GJEiNs4+28a/wHUuF+aRaR0cN5P7XlOwU1360iUCJtQdvKQaN
# AwGI29KOwS3QGriR9F2jOGPUAlpeEzCCB3EwggVZoAMCAQICEzMAAAAVxedrngKb
# SZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIy
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXI
# yjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjo
# YH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1y
# aa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v
# 3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pG
# ve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viS
# kR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYr
# bqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlM
# jgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSL
# W6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AF
# emzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIu
# rQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIE
# FgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWn
# G1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEW
# M2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5
# Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBi
# AEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV
# 9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3Js
# Lm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv
# 6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZn
# OlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1
# bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4
# rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU
# 6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDF
# NLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/
# HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdU
# CbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKi
# excdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTm
# dHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZq
# ELQdVTNYs6FwZvKhggNQMIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJp
# Y2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkEwMDAtMDVF
# MC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMK
# AQEwBwYFKw4DAhoDFQCNkvu0NKcSjdYKyrhJZcsyXOUTNKCBgzCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7DNSiDAi
# GA8yMDI1MDcyOTE0MDA0MFoYDzIwMjUwNzMwMTQwMDQwWjB3MD0GCisGAQQBhFkK
# BAExLzAtMAoCBQDsM1KIAgEAMAoCAQACAg9gAgH/MAcCAQACAhIrMAoCBQDsNKQI
# AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSCh
# CjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBAJ9QozNzB7TXhCmNvIAegmai
# 1BZZpaKt/9jATSgJK+6lb8DiPg0UxR+Rw1xn/C4VafwDzTkqWLMHU1lIcSntiP78
# 4iiC1k3JtWu+OIbEjSTG56ibMLfKSIp5TMGc+8cqNKUrkPdeK37eqJKVkA4G5snH
# fdGqILXNC7Plp0aB8fyES5cGoApu4TjHf3fHOL6cDK5iBta9eTTCHuyZPag+iWE7
# cWIQNgN2XsW+HLEHqQvqtMEqs4RMaCWjPcTiXllh6UF+W/A6tvP+2OLUINjUv723
# VZyO+3Nsr0s3vcR4kqgw7SuoQE/p5BDnXVukZydfRdu0sZ0Sr4eXfi5XMxMyvYsx
# ggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# Agh4nVhdksfZUgABAAACCDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCdH5P8JEHunN45xahl/Hdo
# liVw5De6MSqx7lafeaJ5mzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EII//
# jm8JHa2W1O9778t9+Ft2Z5NmKqttPk6Q+9RRpmepMIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAIIeJ1YXZLH2VIAAQAAAggwIgQg13YR
# a3i6ESI/t87/AM3mpsa7j9NxqWGCOnvDr0YpzicwDQYJKoZIhvcNAQELBQAEggIA
# JwOz/mQfSKErjmE/oFdCozZbJPlMz8zUPju9mJhHuV1FF+HwJ9hwNLe42hTENWde
# KcvH+/TFfGGR9YDC2hdnSkiGrHX1Ke8oigPBh8wHsRrBsT+bbt/MN9wjORZ3CSlf
# TB8wuTq3wxHuDVPXFMfDTgCDaEzADbhfLAgiNYQ2kbchx586GAOwnHIcEJeoYOyr
# RU8Je/jMMQb11asx71tSZkDYgpYxiM5u0yN7lqPg0JhRJADeztp0qpWUF27XcV9b
# FdGhT4rBn+I4Mg+JwpNi6i6aDyUDXt1yLC/hKylUzsoFJWpMU2PMLxfretjjoAqh
# o8yW0qCLa7RGa/hUD3XiUe+u2nQU7Y6H+V1FLgO31udbdgpruq24JeSrbnU5C0zy
# 72gzF23DTz/F7LhKgv5Ug0V2Z7/+cd/Dl9kUrEwN5KHEYLeNh6SRmqKv0rZiJm2l
# xtrEh+Cg/myyejPZRYvW3VDnHOFuvYncehV3jOQNXz5J8EWFo+v0CymOfL3c1dlu
# 7hxO7kQvXdpzWrah2PSwkGJgWsEjIslU5onSFxyb3gOcnQ12YW7qlP8pwW9JlhtQ
# Lt8kC47qq12HS1fumNGv8PvCkLz8icwG9BRCbcGw4vNJfOMt4SVu5D10e4LDuHVd
# dE5faewiKtJIAwbwXN0i1s/cE8wkIITabnryea5VM5g=
# SIG # End signature block
