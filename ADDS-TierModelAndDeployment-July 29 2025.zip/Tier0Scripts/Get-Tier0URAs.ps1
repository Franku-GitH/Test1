﻿# Written by Kip Gumenberg, Microsoft Security Enterprise Services, February 2024
############
### Init ###
############
param (
    $DomainName,
    [switch]$DistDataFolder,
    [switch]$Debug,
    [switch]$IncludeAllServers    
)


if ($DistDataFolder.IsPresent -eq $false) {
    Write-Host "Syntax: .\Get-Tier0URAs.ps1 -DistDataFolder [-DomainName <DomainName>]"
    write-Host
    Write-Host "I.e.:   .\Get-Tier0URAs.ps1 -DistDataFolder"
    Write-Host "I.e.:   .\Get-Tier0URAs.ps1 -DistDataFolder -DomainName na.contoso.local"
    exit
}

if ($DomainName -eq $null)
{
    $CollectionMode = "Forest"
} else {
    $CollectionMode = "Domain"
}

$StartTime = Get-Date
$FileTime = get-date -format "MM-dd-yyyy-HH-mm"
$ScriptRoot = $PSScriptRoot
$CurFolder = $PSScriptRoot + "\Reports"
$DistDataPath = $PSScriptRoot + "\DistData"

###################
### Hash Tables ###
###################
$dicPreferredDCs = @{}                   # Key = Domain DNS Name,                                             Item = Preferred Domain Controller FQDN
$dicMemberDNs = @{}                      # Key = Security Principal Distinguished Name,                       Item = <Not Used>
$dicADObjects = @{}                      # Key = AD Object Distinguished Name,                                Item = AD Object Attributes
$dicServerFQDNs = @{}                    # Key = Domain Controller FQDN,                                      Item = Domain Controller Distinguished Name
$dicDomainDC = @{}                       # Key = Domain FQDN,                                                 Item = Domain Controller FQDN
$dictmpDCs = @{}                         # Key = Domain FQDN,                                                 Item = Domain Controller FQDN
$dicDomainLDAP = @{}                     # Key = Domain FQDN,                                                 Item = Domain LDAP
$dicDomainSIDs = @{}                     # Key = Domain SID,                                                  Item = Domain Controller FQDN
$dicTrustByFQDN = @{}                    # Key = Trust Domain DNS Name,                                       Item = Domain Controller DNS Name
$dicTrustBySID = @{}                     # Key = Trust Domain SID,                                            Item = Trust Domain DNS Name
$dicAvoidTrust = @{}                     # Key = Trust Domain DNS Name OR Trust Domain Controller DNS Name,   Item = <Not Used>
$dicMemberDNs = @{}                      # Key = Security Principal Distinguished Name,                       Item = <Not Used>
$dicMemberState = @{}                    # Key = Member Distinguished Name,                                   Item = Member State
$dicMemberUAC = @{}                      # Key = Member Distinguished Name,                                   Item = Member UserAccountControl
$dicTier0URAInternalNames = @{}          # Key = URA Internal Name,                                           Item = <Not Used>
$dicAllServers = @{}                     # Key = Server FQDN,                                                 Item = Server Distinguished Name
$dicLinesOut = @{}                       # Key = DistinguishedName + ServerFQDN + URAInternalName,            Item = <Not Used>
$dicTmpMemberDistinguishedName = @{}     # Key = Group Member Distinguished Name,                             Item = Member Distinguished Name
$dicTmpGroupSamAccountName = @{}         # Key = Group Member Distinguished Name,                             Item = Group SamAccountName
$dicTmpGroupDisplayName = @{}            # Key = Group Member Distinguished Name,                             Item = Group DisplayName
$dicTmpGroupDomain = @{}                 # Key = Group Member Distinguished Name,                             Item = Group Domain DNS Name
$dicTmpGroupScope = @{}                  # Key = Group Member Distinguished Name,                             Item = Group Scope
$dicTmpGroupSID = @{}                    # Key = Group Member Distinguished Name,                             Item = Group SID
$dicTmpGroupDistinguishedName = @{}      # Key = Group Member Distinguished Name,                             Item = Group DistinguishedName
$dicTmpGroupContainer = @{}              # Key = Group Member Distinguished Name,                             Item = Group Container
$dicTmpdicMemberDNs = @{}                # Key = Group Member Distinguished Name,                             Item = Hash Table of Member DNs
$dicTmpURAInternalName = @{}             # Key = Group Member Distinguished Name,                             Item = URA Internal Name
$dicTmpServerFQDN = @{}                  # Key = Group Member Distinguished Name,                             Item = Server FQDN
$dicTmpServerDistinguishedName = @{}     # Key = Group Member Distinguished Name,                             Item = Server Distinguished Name
$dicTmpServerContainer = @{}             # Key = Group Member Distinguished Name,                             Item = Server Container
$dicTmpInfo = @{}                        # Key = Group Member Distinguished Name,                             Item = Info



########################
### Global Variables ###
########################
$Global:DomainRoot = ""
$Global:DomainRootSID = ""


###################
### Input Files ###
###################
$PreferredDomainControllersFile = $ScriptRoot + "\PreferredDomainControllers.CSV"
$DCInfoFile = gci $CurFolder\DCINFO*.csv | sort LastWriteTime | select -last 1
$URAFileIn = gci $DistDataPath\UserRightsAssignment-*.CSV
$Tier0MemberServerFile = $ScriptRoot + "\" + "Tier0MemberServers.CSV"
$Tier0URAInternalNameFile = $ScriptRoot + "\" + "Tier0URAInternalNames.CSV"

####################
### Output Files ###
####################
$LogFile = $CurFolder + "\" + "Get-Tier0URAs-$FileTime.LOG"
$Tier0URAOutFile = $CurFolder + "\" + "Tier0UserRightsAssignments-$FileTime.CSV"
$AllURAOutFile = $CurFolder + "\" + "AllServerUserRightsAssignments-$FileTime.CSV"

if ($Debug.IsPresent -eq $true) {
    $DebugFlag="on"
}

$LineOut = '"SamAccountName",'`
            + '"DisplayName",'`
            + '"DomainName",'`
            + '"SID",'`
            + '"DistinguishedName",'`
            + '"State",'`
            + '"ObjectClass",'`
            + '"UserAccountControl",'`
            + '"MembershipType",'`
            + '"MemberContainer",'`
            + '"UserRightInternalName",'`
            + '"ServerFQDN",'`
            + '"ServerDistinguishedName",'`
            + '"ServerContainer",'`
            + '"UserRightAssignment"'

Set-Content -Path $Tier0URAOutFile -Value $LineOut -Encoding Unicode
Set-Content -Path $AllURAOutFile -Value $LineOut -Encoding Unicode


#################
### Write Log ###
#################
Function WriteLog
{
    param (
        $LineIn,
        $WriteToScreen,
        $Color
    )

    $CurTime =  get-date -UFormat "%m/%d/%Y %T"
    $LineOut = "$CurTime $LineIn"

    if ($WriteToScreen -eq $true)
    {
        if ($Color)
        {
            write-host $LineIn -ForegroundColor $Color
        } else {
            write-host $LineIn
        }
    }
    if ($DebugFlag -eq "on") {
        Add-Content -Path $LogFile -Value $LineOut -Encoding Unicode
    }
}

$StartTime = Get-Date
$LineOut = "Starting."  
if ($DebugFlag -eq "on") {
    WriteLog "Starting Get-Tier0GroupMembership.ps1." $False
}

#################################
### Escape Special Characters ###
#################################
Function EscapeSpecialCharacters
{
    param 
    (
        $TargetDN
    )
    $TargetDN = $TargetDN -replace "'", "''"
    
    return $TargetDN
}

####################################################
### Determine If Preferred DCs Have Been Defined ###
####################################################
Function DetermineIfPreferredDCsHaveBeenDefined
{
    WriteLog ""
    WriteLog "####################################################"
    WriteLog "### Determine If Preferred DCs Have Been Defined ###"
    WriteLog "####################################################"

    WriteLog "Checking for entries in $PreferredDomainControllersFile" $true
    $CSV = Import-Csv $PreferredDomainControllersFile
    foreach ($Row in $CSV)
    {    
        $DomainControllerFQDN = $Row.PreferredDomainControllerFQDN

        $Index = $DomainControllerFQDN.IndexOf(".")
        $Length = $DomainControllerFQDN.Length

        $DCDomain = $DomainControllerFQDN.Substring($Index+1,$Length-($Index+1))
        if ($dicPreferredDCs.ContainsKey($DCDomain) -eq $false)
        {
            $dicPreferredDCs.Add($DCDomain,$DomainControllerFQDN)
        }

        WriteLog "Preferred Domain Controller for $DCDomain found: $DomainControllerFQDN" $true Green
    }
    $PrefDCCount = $dicPreferredDCs.Count
    WriteLog "Number of Preferred Domain Controllers Found: $PrefDCCount" $true

}

######################
### Get Closest DC ###
######################
Function GetClosestDC
{
    param 
    (
        $TargetDomain
    )
    writeLog ""
    WriteLog "######################"
    WriteLog "### Get Closest DC ###"
    WriteLog "######################"
    WriteLog "GetClosestDC: $TargetDomain"

    if ($dicPreferredDCs.ContainsKey($TargetDomain) -eq $true)
    {
        $ClosestDC = $dicPreferredDCs.$TargetDomain
        WriteLog "Using preffered DC: $ClosestDC"
        if ($dicDomainDC.ContainsKey($TargetDomain) -eq $false)
        {
            $dicDomainDC.add($TargetDomain,$ClosestDC)
        }
    } else {
        if ($dicDomainDC.ContainsKey($TargetDomain) -eq $true)
        {
            $ClosestDC = $dicDomainDC.$TargetDomain
            WriteLog "Using cached DC $ClosestDC for Domain: $TargetDomain" 
       
        } else {
        
            WriteLog "Discovering Domain Controller for domain: $TargetDomain"
            $DCObj = Get-ADDomainController -Discover -Domain $TargetDomain -ErrorAction SilentlyContinue
            if ($DCObj)
            {
                $ClosestDC = [string]$DCObj.HostName
                $dicDomainDC.Add($TargetDomain,$ClosestDC)
                WriteLog "Using discovered DC: $ClosestDC"
            } else {
                WriteLog "The following error occured trying to discover a DC in $TargetDomain : $Error"
            }
        }
    }
    WriteLog ""

    return $ClosestDC
}


########################
### Read DCINFO File ###
########################
Function ReadDCINFOFile
{
    $RootDomain = ""
    $CSV = Import-Csv $DCInfoFile
    foreach ($Row in $CSV)
    {
    
        $DomainControllerFQDN = $Row.DomainControllerFQDN
        $DomainControllerDistinguishedName = $Row.DomainControllerDistinguishedName
        $DomainFQDN = $Row.DomainFQDN
        $DomainLDAP = $Row.DomainLDAP
        $DCSID = $Row.DomainControllerSID
        $IsRootDomain = $Row.DomainRoot

        if ($CollectionMode -eq "Forest" -or $DomainName -eq $DomainFQDN)
        {

            WriteLog "DomainControllerFQDN: $DomainControllerFQDN"
            WriteLog "DomainControllerDistinguishedName: $DomainControllerDistinguishedName"
            WriteLog "DomainFQDN: $DomainFQDN"
            WriteLog "DomainLDAP: $DomainLDAP"

            $Index = $DCSID.LastIndexOf("-")
            $Length = $DCSID.Length + 1
            $AppliedLength = $Length - ($Index+1)
            $DomainSID = $DCSID.Substring(0,$Index)

            if ($dicServerFQDNs.ContainsKey($DomainControllerFQDN) -eq $false)
            {
                $dicServerFQDNs.Add($DomainControllerFQDN,$DomainControllerDistinguishedName)
            }

            if ($IsRootDomain -eq $true)
            {
                $RootDomain = $DomainFQDN
            }

            $TargetDC = GetClosestDC $DomainFQDN

            if ($TargetDC)
            {
                    
                WriteLog "TargetDC: $TargetDC"

                if ($dicTmpDCs.ContainsKey($DomainFQDN) -eq $false)
                {
                    $dicTmpDCs.Add($DomainFQDN,$TargetDC)
                }
                if ($dicDomainLDAP.ContainsKey($DomainFQDN) -eq $false)
                {
                    $dicDomainLDAP.Add($DomainFQDN,$DomainLDAP)
                }
                if ($dicDomainSIDs.ContainsKey($DomainSID) -eq $false)
                {
                    $dicDomainSIDs.Add($DomainSID,$TargetDC)
                }
            }

            WriteLog ""
        }
    }
}

#####################################
### Determine Trust Relationships ###
#####################################
Function DetermineTrustRelationships
{
    WriteLog ""
    WriteLog "#####################################"
    WriteLog "### Determine Trust Relationships ###"
    WriteLog "#####################################"

    WriteLog "Getting Trust Relationships to remote domains." $true
    $error.clear()
    foreach ($Domain in $dicTmpDCs.Keys)
    {
        WriteLog "Domain: $Domain" $true
    }

    foreach ($Domain in $dicTmpDCs.Keys)
    {
        WriteLog "Enumerating trusts for: $Domain" $true

        $trusts= Get-ADTrust -Filter * -Server $Domain -ErrorAction SilentlyContinue

        foreach($trust in $trusts) 
        {
            $TrustDomain = $trust.Name
            $Direction = $trust.Direction
            $IsSelective = $trust.SelectiveAuthentication

            if ($dicTmpDCs.ContainsKey($TrustDomain) -eq $false -and $dicAvoidTrust.ContainsKey($TrustDomain) -eq $false)
            {

                WriteLog "TrustDomain: $TrustDomain  Direction: $Direction  SelectiveAuthentication: $IsSelective" $true

                if ($IsSelective -eq $false -and $Direction -ne "Outbound")
                {

                    WriteLog "Getting Domain Controllers for: $TrustDomain" $true

                    $Error.Clear()
                    $TrustDCs = Get-ADDomainController -Discover -DomainName $TrustDomain -ErrorAction SilentlyContinue
                    if ($Error)
                    {
                        if ($dicAvoidTrust.ContainsKey($TrustDomain) -eq $False)
                        {
                            $dicAvoidTrust.Add($TrustDomain,"")
                        }

                    }
                    if ($dicAvoidTrust.ContainsKey($TrustDomain) -eq $false)
                    {
                        if ($TrustDCs)
                        {
                            $TrustDC = $TrustDCs.Hostname[0]

                            WriteLog "Testing Connectivity for: $TrustDC" $true

                            $OriginalPref = $ProgressPreference # Default is 'Continue'
                            $global:ProgressPreference = "SilentlyContinue"
                            $Error.Clear()
                            $tnc = tnc $TrustDC -port 3268 -ErrorAction SilentlyContinue
                            $global:ProgressPreference = $OriginalPref

                            $isAvailable = $tnc.TcpTestSucceeded

                           WriteLog "isAvailable: $isAvailable" $true

                            if ($isAvailable -eq $false)
                            {
                                if ($dicAvoidTrust.ContainsKey($TrustDC) -eq $False)
                                {
                                    $dicAvoidTrust.Add($TrustDC,"")
                                }

                            }

                            if ($isAvailable -eq $true -and $dicAvoidTrust.ContainsKey($TrustDomain) -eq $false -and $dicAvoidTrust.ContainsKey($TrustDC) -eq $false)
                            {
                                WriteLog "Getting Domain: $TrustDomain on DC: $TrustDC" $true

                                $Error.Clear()
                                $objTrustDomain = Get-ADDomain -identity $TrustDomain -server $TrustDC -ErrorAction SilentlyContinue

                                if ($Error)
                                {
                                    if ($dicAvoidTrust.ContainsKey($TrustDomain) -eq $False)
                                    {
                                        $dicAvoidTrust.Add($TrustDomain,"")
                                    }
                                    if ($dicAvoidTrust.ContainsKey($TrustDC) -eq $False)
                                    {
                                        $dicAvoidTrust.Add($TrustDC,"")
                                    }
                                }


                                if ($objTrustDomain)
                                {
                                    $TrustDomainFQDN = $objTrustDomain.DNSRoot
                                    $TrustDomainLDAP = $objTrustDomain.DistinguishedName
                                    $TrustDomainSID = [string]$objTrustDomain.DomainSID
                                    $TrustDomainNetBIOSName = $objTrustDomain.NetBIOSName
                                
                                    if ($dicAvoidTrust.ContainsKey($TrustDomainFQDN) -eq $false)
                                    {

                                        WriteLog "Adding DC to hash tables: $TrustDC" $true

                                        if ($dicTrustByFQDN.ContainsKey($TrustDomain) -eq $false)
                                        {
                                            $dicTrustByFQDN.Add($TrustDomain,$TrustDC)
                                        }
                                        if ($dicTrustBySID.ContainsKey($TrustDomainSID) -eq $false)
                                        {
                                            $dicTrustBySID.Add($TrustDomainSID,$TrustDomain)
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    $ValidTrustCount = $dicTrustByFQDN.Count
    WriteLog "Number of valid trusts found: $ValidTrustCount" $true


    foreach($Key in $dicTrustBySID.keys)
    {
        $TrustDomain = $dicTrustBySID.$Key
        $TrustDC = $dicTrustByFQDN.$TrustDomain
        WriteLog "TrustFound: $TrustDomain TrustDC: $TrustDC" $true

    }

}

######################
### Get AD Object2 ###
######################
Function GetADObject2
{
    Param
    (
        $IdentityReference,
        $TargetDC,
        $CacheObject
    )
    WriteLog ""
    WriteLog "######################"
    WriteLog "### Get AD Object2 ###"
    WriteLog "######################"
    WriteLog "IdentityReference: $IdentityReference"
    WriteLog "TargetDC: $TargetDC"

    $ADObj = ""

    $IdentityReference2 = EscapeSpecialCharacters $IdentityReference
    $IsSid = $IdentityReference2.Substring(0,2)

    if ($dicADObjects.ContainsKey($IdentityReference2) -eq $true)
    {
        WriteLog "Using Cached Object with IdentityReference: $IdentityReference"
        $ADObj = $dicADObjects.$IdentityReference2
    } else {

        If ($IsSid -eq "S-") 
        {
            try 
            {
                $ADObj = Get-adobject -Filter "ObjectSID -eq '$IdentityReference2'" -Server $TargetDC -Properties * -ErrorAction SilentlyContinue
            } catch {
                WriteLog "Check1: ObjectSID not found for $IdentityReference2 on TargetDC: $TargetDC"
            }
        } 

        if ($ADObj)
        {
            if ($CacheObject -eq $true)
            {
                $dicADObjects.Add($IdentityReference2,$ADObj)
            }
        } else {
            try
            {
                $ADObj = Get-adobject -Filter "SamAccountName -eq '$IdentityReference2'" -Server $TargetDC -Properties * -ErrorAction SilentlyContinue
            } catch {
                WriteLog "Check2: SamAccountName not found for $IdentityReference2 on TargetDC: $TargetDC"
            }

            if ($ADObj)
            {
                if ($CacheObject -eq $true)
                {
                    $dicADObjects.Add($IdentityReference2,$ADObj)
                }
            } else {
                try
                {
                    $ADObj = Get-adobject -Filter "DistinguishedName -eq '$IdentityReference2'" -Server $TargetDC -Properties * -ErrorAction SilentlyContinue
                } catch {
                    WriteLog "Check3: DistinguishedName not found for $IdentityReference2 on TargetDC: $TargetDC"
                }
                if ($ADObj)
                {
                    if ($CacheObject -eq $true)
                    {
                        $dicADObjects.Add($IdentityReference2,$ADObj)
                    }
                }
            }
        }
    }
    if ($ADObj)
    {
        $DN = $ADObj.DistinguishedName
        if ($dicADObjects.ContainsKey($DN) -eq $false)
        {
            if ($CacheObject -eq $true)
            {
                $dicADObjects.Add($DN,$ADObj)
            }
        }
        WriteLog "Found $IdentityReference2 with a Distinguished Name of $DN"
        WriteLog "Exiting GetADObject2"
        WriteLog ""
        Return $ADObj
    } else {
        WriteLog "Didn't find $IdentityReference2" $true red
    }
}



##########################
### Get Nested Members ###
##########################
Function GetNestedMembers
{

    param (
        $TargetGroupDistinguishedName, 
        $OrigGroupSamAccountName,
        $OrigGroupDisplayName,
        $OrigGroupDomain,
        $OrigGroupScope,
        $OrigGroupSID,
        $OrigGroupDistinguishedName,
        $OrigGroupContainer,
        $OrigURAInternalName,
        $OrigServerFQDN,
        $OrigServerDistinguishedName,
        $OrigServerContainer,
        $OrigInfo

    )

    $Index = $TargetGroupDistinguishedName.IndexOf("DC=")
    $Length = $TargetGroupDistinguishedName.Length + 1
    $AppliedLength = $Length - ($Index+1)
    $TargetDomainDN = $TargetGroupDistinguishedName.Substring($Index,$AppliedLength)

    $TargetDomainFQDN = $TargetDomainDN -replace ",DC=", "."
    $TargetDomainFQDN = $TargetDomainFQDN -replace "DC=", ""

    $Index = $TargetGroupDistinguishedName.IndexOf(",OU=")
    if ($Index -eq -1) {$Index = $TargetGroupDistinguishedName.IndexOf(",CN=")}
    if ($Index -eq -1) {$Index = $TargetGroupDistinguishedName.IndexOf(",DC=")}

    $Length = $TargetGroupDistinguishedName.Length
    $AppliedLength = $Length - ($Index + 1)
    $TargetContainer = $TargetGroupDistinguishedName.Substring($Index+1,$AppliedLength)

    if ($dicADObjects.ContainsKey($TargetGroupDistinguishedName) -eq $true)
    {
        $Group = $dicADObjects.$TargetGroupDistinguishedName

    } else {

        $TargetDC = GetClosestDC $TargetDomainFQDN

        $Group = GetADObject2 $TargetGroupDistinguishedName $TargetDC $true

    }

    WriteLog ""
    WriteLog "########################"
    WriteLog "### GetNestedMembers ###"
    WriteLog "########################"
    WriteLog "TargetGroupDistinguishedName: $TargetGroupDistinguishedName"
    WriteLog "OrigGroupSamAccountName: $OrigGroupSamAccountName"
    WriteLog "OrigGroupDisplayName: $OrigGroupDisplayName"
    WriteLog "OrigGroupDomain: $OrigGroupDomain"
    WriteLog "OrigGroupScope: $OrigGroupScope"
    WriteLog "OrigGroupSID: $OrigGroupSID"
    WriteLog "OrigGroupDistinguishedName: $OrigGroupDistinguishedName"
    WriteLog "OrigGroupContainer: $OrigGroupContainer"

    If ($Group) {

        $GroupSamAccountName = $Group.SamAccountName
        $GroupDisplayName = $Group.Name
        $GroupDomain = $DomainFQDN
        $GroupType = $Group.GroupType
        $GroupSID = $Group.ObjectSID
        $GroupMemberDNs = $Group.Member
        $GroupDistinguishedName = $Group.DistinguishedName
        $Index = $GroupDistinguishedName.IndexOf(",")
        $Length = $GroupDistinguishedName.Length
        $AppliedLength = $Length - ($Index + 1)
        $GroupContainer = $GroupDistinguishedName.Substring($Index+1,$AppliedLength)

        $IsDomainLocal = ($GroupType -band 4) -ne 0
        $IsGlobal = ($GroupType -band 2) -ne 0
        $IsUniversal = ($GroupType -band 8) -ne 0
        $IsSecurity = ($GroupType -band 0x80000000) -ne 0

        if ($IsDomainLocal -eq $true) {$GroupScope = "DomainLocal"}
        if ($IsGlobal -eq $true) {$GroupScope = "Global"}
        if ($IsUniversal -eq $true) {$GroupScope = "Universal"}

        WriteLog ""
        WriteLog "GroupSamAccountName: $GroupSamAccountName"
        WriteLog "GroupDisplayName: $GroupDisplayName"
        WriteLog "GroupDomain: $GroupDomain"
        WriteLog "GroupType: $GroupType"
        WriteLog "IsDomainLocal: $IsDomainLocal"
        WriteLog "IsGlobal: $IsGlobal"
        WriteLog "IsUniversal: $IsUniversal"
        WriteLog "GroupScope: $GroupScope"
        WriteLog "GroupSID: $GroupSID"
        WriteLog "GroupDistinguishedName: $GroupDistinguishedName"
        WriteLog "GroupContainer: $GroupContainer"

        foreach ($MemberDN in $GroupMemberDNs) 
        {

            WriteLog "MemberDN: $MemberDN"

            $MemberDistinguishedName = $MemberDN

            $Index = $MemberDistinguishedName.IndexOf("DC=")
            $Length = $MemberDistinguishedName.Length + 1
            $AppliedLength = $Length - ($Index+1)
            $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

            $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
            $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

            $Index = $MemberDistinguishedName.IndexOf(",OU=")
            if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
            if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

            $Length = $MemberDistinguishedName.Length
            $AppliedLength = $Length - ($Index + 1)
            $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)
        
            $MemberTargetDC = GetClosestDC $MemberDomainFQDN    

            if ($dicMemberDNs.ContainsKey($MemberDistinguishedName) -eq $false) {
                $dicMemberDNs.Add($MemberDistinguishedName,"")

                if ($dicADObjects.ContainsKey($MemberDistinguishedName) -eq $true)
                {
                    $Member = $dicADObjects.$MemberDistinguishedName

                } else {

                    $Member = GetADObject2 $MemberDistinguishedName $MemberTargetDC $true
                }

                $MemberDisplayName = $Member.name
                $MemberSID = $Member.ObjectSID
                $MemberSamAccountName = $Member.SamAccountName
                $MemberObjectClass = $Member.objectClass

                if ($MemberObjectClass -eq "user" -or $MemberObjectClass -eq "computer" -or $MemberObjectClass -eq "msDS-GroupManagedServiceAccount") {
                    $MemberUserAccountControl = $Member.UserAccountControl
                    if (($MemberUserAccountControl -band 2) -ne 2) {
                        $MemberState = "Enabled"
                    } else {
                        $MemberState = "Disabled"
                    }
                } else {
                    $MemberState = ""
                    $MemberUserAccountControl = ""
                }



                WriteLog ""
                WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                WriteLog "MemberDisplayName: $MemberDisplayName"
                WriteLog "MemberSID: $MemberSID"
                WriteLog "MemberSamAccountName: $MemberSamAccountName"
                WriteLog "MemberObjectClass: $MemberObjectClass"
                WriteLog "MemberDomainDN: $MemberDomainDN"
                WriteLog "MemberDomainFQDN: $MemberDomainFQDN"
                WriteLog "MemberTargetDC: $MemberTargetDC"
                WriteLog "MemberContainer: $MemberContainer"
                WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                WriteLog "MemberState: $MemberState"
                WriteLog "MemberMemberShipType: Explicit"

                $DetectDuplicates = $MemberDistinguishedName + $OrigServerFQDN + $OrigURAInternalName

                $DupFound=$false

                if ($dicLinesOut.ContainsKey($DetectDuplicates) -eq $false)
                {
                    $dicLinesOut.Add($DetectDuplicates,"")
                } else {
                    $DupFound=$true
                }


                $LineOut = '"' + $MemberSamAccountName + '",'`
                            + '"' + $MemberDisplayName  + '",'`
                            + '"' + $MemberDomainFQDN  + '",'`
                            + '"' + $MemberSID  + '",'`
                            + '"' + $MemberDistinguishedName  + '",'`
                            + '"' + $MemberState  + '",'`
                            + '"' + $MemberObjectClass  + '",'`
                            + '"' + $MemberUserAccountControl  + '",'`
                            + '"Nested",'`
                            + '"' + $MemberContainer  + '",'`
                            + '"' + $OrigURAInternalName  + '",'`
                            + '"' + $OrigServerFQDN  + '",'`
                            + '"' + $OrigServerDistinguishedName  + '",'`
                            + '"' + $OrigServerContainer  + '",'`
                            + '"' + $OrigInfo  + '"'


                if ($dicServerFQDNs.ContainsKey($OrigServerFQDN) -eq $true -and $dicTier0URAInternalNames.ContainsKey($OrigURAInternalName) -eq $true -and $DupFound -eq $false)
                {
                    Add-Content -Path $Tier0URAOutFile -Value $LineOut -Encoding Unicode
                }
                if ($DupFound -eq $false)
                {
                    Add-Content -Path $AllURAOutFile -Value $LineOut -Encoding Unicode
                }

                if ($MemberObjectClass -eq "group")
                {
                    GetNestedMembers $MemberDistinguishedName $OrigGroupSamAccountName $OrigGroupDisplayName $OrigGroupDomain $OrigGroupScope $OrigGroupSID $OrigGroupDistinguishedName $OrigGroupContainer $OrigURAInternalName $OrigServerFQDN $OrigServerDistinguishedName $OrigServerContainer $OrigInfo
                }
            }
        }
    }
}

#####################
### Get AD Object ###
#####################
function GetADObject
{
    param( 
        $CurIdentityReference, 
        $CurTargetDC,
        $CurServerDomain,
        $CacheObject
    )
    try 
    {
        $RootDSE = Get-ADRootDSE -Server $CurTargetDC -ErrorAction SilentlyContinue
    } catch {

    }
    if ($RootDSE)
    {
        $RootDomain = $RootDSE.rootDomainNamingContext
        $ConfigPartition = $RootDSE.configurationNamingContext
        $DefaultNamingContext = $RootDSE.defaultNamingContext
        $SchemaPartition = $RootDSE.schemaNamingContext

        $Key = $CurServerDomain + $CurIdentityReference
        $CurIdentityReference2 = EscapeSpecialCharacters $CurIdentityReference

        if ($dicADObjects.ContainsKey($Key) -eq $true)
        {
            $ADObject = $dicADObjects.$Key

        } else {
        
            try
            {
                
                $ADObject = get-adobject -Searchbase "$ConfigPartition" -Filter "ObjectSID -eq '$CurIdentityReference'" -server $CurTargetDC -Properties * -ErrorAction SilentlyContinue
            } Catch {}

            if ($ADObject -eq $Null)
            {
                try
                {
                    $ADObject = Get-adobject -Searchbase "$DefaultNamingContext" -Filter "ObjectSID -eq '$CurIdentityReference2'" -Server $CurTargetDC -Properties * -ErrorAction SilentlyContinue
                } catch {}
            }
            if ($ADObject -eq $Null)
            {
                try
                {
                    $ADObject = Get-adobject -Searchbase "$DefaultNamingContext" -Filter "SamAccountName -eq '$CurIdentityReference2'" -Server $CurTargetDC -Properties * -ErrorAction SilentlyContinue
                } catch {}
            }
            if ($ADObject -eq $Null)
            {
                if ($CurIdentityReference.Contains("-") -eq $true)
                {
                    $Index = $CurIdentityReference.LastIndexOf("-")
                    $Length = $CurIdentityReference.Length + 1
                    $AppliedLength = $Length - ($Index+1)
                    $TargetDomainSID = $CurIdentityReference.Substring(0,$Index)
                    if ($dicDomainSIDs.ContainsKey($TargetDomainSID) -eq $true)
                    {
                        $CurTargetDC = $dicDomainSIDs.$TargetDomainSID
                        try
                        {
                            $RootDSE = Get-ADRootDSE -Server $CurTargetDC -ErrorAction SilentlyContinue
                        } catch {

                        }
                        if ($RootDSE)
                        {
                            $DefaultNamingContext = $RootDSE.defaultNamingContext
                        }
                    }

                }
            
                try
                {
                    $ADObject = Get-adobject -Searchbase "$DefaultNamingContext" -Filter "ObjectSID -eq '$CurIdentityReference2'" -Server $CurTargetDC -Properties * -ErrorAction SilentlyContinue
                } catch {}
            }
    
            if (($ADObject -eq $null -and $CurIdentityReference.contains("S-1-5-21-")) -or ($ADObject.ObjectClass -eq "foreignSecurityPrincipal"))
            {
                $RemoteMemberSID = $CurIdentityReference
                $Index = $RemoteMemberSID.LastIndexOf("-")
                $RemoteDomainSID = $RemoteMemberSID.Substring(0,$Index)

                if ($dicTrustBySID.ContainsKey($RemoteDomainSID) -eq $true)
                {
                
                    $RemoteDomainFQDN = $dicTrustBySID.$RemoteDomainSID
                    $RemoteDomainDC = $dicTrustByFQDN.$RemoteDomainFQDN

                    Try
                    {
                        $ADObject = Get-adobject -Filter "ObjectSID -eq '$RemoteMemberSID'" -Server $RemoteDomainDC -Properties * -ErrorAction SilentlyContinue
                    } Catch {
                        write-host "Could not find1: $RemoteMemberSID on $RemoteDomainDC"
                    }

                }
            }
    
            if ($ADObject)
            {
                if ($CacheObject -eq $true)
                {
                    $dicADObjects.Add($Key,$ADObject)
                }

                if ($ADObject)
                {
                    $DN = $ADObject.DistinguishedName
                    if ($dicADObjects.ContainsKey($DN) -eq $false)
                    {
                        if ($CacheObject -eq $true)
                        {
                            $dicADObjects.add($DN,$ADObject)
                        }
                    }
                }
            }

        }
    }
    Return $ADObject
}

######################################
### Read Tier 0 Member Server File ###
######################################
Function ReadTier0MemberServerFile
{

    WriteLog "Reading $Tier0MemberServerFile File" $true
    $CheckFile = Test-Path $Tier0MemberServerFile -PathType Leaf
    WriteLog "CheckFile: $CheckFile"

    if ($CheckFile -eq $True)
    {
        $CSV = Import-Csv $Tier0memberServerFile
        foreach ($Row in $CSV)
        {
            $MemberServer = $Row.Tier0MemberServerFQDN
            WriteLog "MemberServer: $MemberServer"

            $Index = $MemberServer.IndexOf(".")
            $Length = $MemberServer.Length
            $AppliedLength = $Length - ($Index + 1)
            $MemberServerDomain = $MemberServer.Substring($Index+1,$AppliedLength)

            WriteLog "MemberServerDomain: $MemberServerDomain"

            $TargetDC = GetClosestDC $MemberServerDomain
            $TargetLDAP = $dicDomainLDAP.$MemberServerDomain
            WriteLog "TargetDC: $TargetDC"
            WriteLog "TargetLDAP: $TargetLDAP"
            try
            {
                $objMemberServer = Get-ADComputer -ldapfilter "(dNSHostname=$MemberServer)" -SearchBase $TargetLDAP -searchscope Subtree -Server "$TargetDC" -ErrorAction SilentlyContinue
            } catch {

            }
            if ($objMemberServer) {
                $MemberServerDistinguishedName = $objMemberServer.DistinguishedName
                WriteLog "MemberServerDistinguishedName: $MemberServerDistinguishedName"

                if ($dicServerFQDNs.ContainsKey($MemberServer) -eq $false) {
                    $dicServerFQDNs.Add($MemberServer,$MemberServerDistinguishedName)
                }
            }

        }
    }
    $MSCount = $dicServerFQDNs.Count
    WriteLog "Tier 0 Servers Found: $MSCount" $true

}

#####################
### Read URA File ###
#####################
Function ReadURAInternalNameFile
{
    $CSV = Import-Csv $Tier0URAInternalNameFile
    foreach ($Row in $CSV)
    {
        $URAName = $Row.Tier0URAInternalNames
        $dicTier0URAInternalNames.Add($URAName,"")
    }
}

###############################
### Produce Tier 0 URA File ###
###############################
Function ProduceTier0URAFile
{
    WriteLog "Producing Tier0URAs.CSV file." $true

    foreach ($CSVFile in $URAFileIn)
    {
        $CSVFilename = $CSVFile.Name
        $Index = $CSVFilename.IndexOf("-")
        $Length = $CSVFilename.Length
        $AppliedLength = $Length - ($Index + 1)
        $ServerName = $CSVFilename.Substring($Index+1,$AppliedLength)

        $Index1 = $ServerName.IndexOf(".")
        $Index2 = $ServerName.LastIndexOf(".")
        $ServerDomain = $ServerName.Substring($Index1+1,$Index2 - ($Index1 + 1))

        $Length = $ServerName.Length
        $ServerName = $ServerName.Substring(0,($Length-4))

        if ($CollectionMode -eq "Forest" -or $DomainName -eq $ServerDomain)
        {
            if ($dicServerFQDNs.ContainsKey($ServerName) -eq $True -or $IncludeAllServers.IsPresent -eq $true)
            {
            
                WriteLog "Reading $CSVFile" $true
                $CSV = Import-Csv $CSVFile

                foreach ($Row in $CSV)
                {
                    $ADObject = $null

                    $CurServerFQDN = $Row.ServerFqdn
                    $CurURAInternalName = $Row.UserRightInternalName
                    $CurServerDistinguishedName = $dicServerFQDNs.$CurServerFQDN
                    $CurIdentityReference = $Row.IdentityReference

                    $Index = $CurServerFQDN.IndexOf(".")
                    $Length = $CurServerFQDN.Length
                    $AppliedLength = $Length - ($Index + 1)
                    $CurServerDomain = $CurServerFQDN.Substring($Index+1,$AppliedLength)

                    $CurTargetDC = GetClosestDC $CurServerDomain

                    try
                    {
                        $ADObject = GetADObject $CurIdentityReference $CurTargetDC $CurServerDomain $false
                    } catch {

                    }
                    if ($ADObject)
                    {
                        $CurDistinguishedName = $ADObject.DistinguishedName

                        if ($IncludeAllServers.IsPresent -eq $true -and ($CurServerDistinguishedName -eq $null -or $CurServerDistinguishedName -eq ""))
                        {
                            if ($dicAllServers.ContainsKey($CurServerFQDN) -eq $true)
                            {
                                $CurServerDistinguishedName = $dicAllServers.$CurServerFQDN
                            } else {
                                $TargetLDAP = $dicDomainLDAP.$CurServerDomain
                                try
                                {
                                    $objMemberServer = Get-ADComputer -ldapfilter "(dNSHostname=$CurServerFQDN)" -SearchBase $TargetLDAP -searchscope Subtree -Server "$CurTargetDC" -ErrorAction SilentlyContinue
                                } catch {

                                }

                                if ($objMemberServer) 
                                {
                                    $CurServerDistinguishedName = $objMemberServer.DistinguishedName
                                    $dicAllServers.Add($CurServerFQDN,$CurServerDistinguishedName)
                                }
                            }
                        }
                    }

                    if ($CurServerDistinguishedName -ne "" -and $CurServerDistinguishedName -ne $null -and $CurDistinguishedName -ne "" -and $CurDistinguishedName -ne $null)
                    {

                        $Index = $CurDistinguishedName.IndexOf("DC=")
                        $Length = $CurDistinguishedName.Length + 1
                        $AppliedLength = $Length - ($Index+1)
                        $TargetDomainDN = $CurDistinguishedName.Substring($Index,$AppliedLength)

                        $CurDomain = $TargetDomainDN -replace ",DC=", "."
                        $CurDomain = $CurDomain -replace "DC=", ""

                        $Index = $CurServerDistinguishedName.IndexOf(",")
                        $Length = $CurServerDistinguishedName.Length
                        $AppliedLength = $Length - ($Index + 1)
                        $CurServerContainer = $CurServerDistinguishedName.Substring($Index+1,$AppliedLength)

                        WriteLog ""
                        WriteLog "CurServerFQDN: $CurServerFQDN"
                        WriteLog "CurURAInternalName: $CurURAInternalName"
                        WriteLog "CurServerDistinguishedName: $CurServerDistinguishedName"
                        WriteLog "CurServerContainer: $CurServerContainer"


                        if ($IncludeAllServers.IsPresent -eq $true -or $dicServerFQDNs.ContainsKey($CurServerFQDN) -eq $true)
                        {
                            if ($IncludeAllServers.IsPresent -eq $true -or $dicTier0URAInternalNames.ContainsKey($CurURAInternalName) -eq $true) 
                            {
                        
                                $CurObjectClass = $ADObject.ObjectClass
                                $CurSamAccountName = $ADObject.SamAccountName
                                $CurDisplayName = $ADObject.Name
                                $CurSID = $ADObject.ObjectSID
                                $CurInfo = $Row.UserRightDisplayName

                                $Index = $CurDistinguishedName.IndexOf(",")
                                $Length = $CurDistinguishedName.Length
                                $AppliedLength = $Length - ($Index + 1)
                                $CurContainer = $CurDistinguishedName.Substring($Index+1,$AppliedLength)

                                $TargetDC = GetClosestDC $CurDomain
                                $TargetLDAP = $dicDomainLDAP.$CurDomain

                                WriteLog "TargetDC: $TargetDC"
                                WriteLog "TargetLDAP: $TargetLDAP"
                                WriteLog "CurDistinguishedName: $CurDistinguishedName"
                                WriteLog "CurDomain: $CurDomain"
                                WriteLog "CurObjectClass: $CurObjectClass"
                                WriteLog "CurSamAccountName: $CurSamAccountName"
                                WriteLog "CurDisplayName: $CurDisplayName"
                                WriteLog "CurSID: $CurSID"
                                WriteLog "CurContainer: $CurContainer"
                                WriteLog "CurInfo: $CurInfo"

                                if ($dicMemberDNs.ContainsKey($CurDistinguishedName) -eq $false)
                                {
                                    if ($CurObjectClass -ne "group" -and $CurObjectClass -ne "foreignSecurityPrincipal;top")
                                    {
                                        $MemberUserAccountControl = $ADObject.UserAccountControl
                                        if (($MemberUserAccountControl -band 2) -ne 2) {
                                            $MemberState = "Enabled"
                                        } else {
                                            $MemberState = "Disabled"
                                        }
                                    } else {
                                        $MemberUserAccountControl = ""
                                        $MemberState = ""
                                    }
                                    WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                                    WriteLog "MemberState: $MemberState"

                                    if ($dicMemberDNs.ContainsKey($CurDistinguishedName) -eq $false) {$dicMemberDNs.Add($CurDistinguishedName,"")}
                                    if ($dicMemberState.ContainsKey($CurDistinguishedName) -eq $false) {$dicMemberState.Add($CurDistinguishedName,$MemberState)}
                                    if ($dicMemberUAC.ContainsKey($CurDistinguishedName) -eq $false) {$dicMemberUAC.Add($CurDistinguishedName,$MemberUserAccountControl)}
                                }
                                $CurState = $dicMemberState.$CurDistinguishedName
                                $CurUAC = $dicMemberUAC.$CurDistinguishedName

                                WriteLog "CurState: $CurState"
                                WriteLog "CurUAC: $CurUAC"

                                $DetectDuplicates = $CurDistinguishedName + $CurServerFQDN + $CurURAInternalName

                                $DupFound=$false

                                if ($dicLinesOut.ContainsKey($DetectDuplicates) -eq $false)
                                {
                                    $dicLinesOut.Add($DetectDuplicates,"")
                                } else {
                                    $DupFound=$true
                                }


                                $LineOut = '"' + $CurSamAccountName + '",'`
                                            + '"' + $CurDisplayName  + '",'`
                                            + '"' + $CurDomain  + '",'`
                                            + '"' + $CurSID  + '",'`
                                            + '"' + $CurDistinguishedName  + '",'`
                                            + '"' + $CurState  + '",'`
                                            + '"' + $CurObjectClass  + '",'`
                                            + '"' + $CurUAC  + '",'`
                                            + '"Explicit",'`
                                            + '"' + $CurContainer  + '",'`
                                            + '"' + $CurURAInternalName  + '",'`
                                            + '"' + $CurServerFQDN  + '",'`
                                            + '"' + $CurServerDistinguishedName  + '",'`
                                            + '"' + $CurServerContainer  + '",'`
                                            + '"' + $CurInfo  + '"'

                                if ($dicServerFQDNs.ContainsKey($CurServerFQDN) -eq $true -and $dicTier0URAInternalNames.ContainsKey($CurURAInternalName) -eq $true -and $DupFound -eq $false)
                                {
                                    Add-Content -Path $Tier0URAOutFile -Value $LineOut -Encoding Unicode
                                }

                                if ($DupFound -eq $false)
                                {
                                    Add-Content -Path $AllURAOutFile -Value $LineOut -Encoding Unicode
                                }

                                if ($CurObjectClass -eq "group")
                                {
                                    Try
                                    {
                                        $Group = $ADObject
                                    } catch {
                                        WriteLog "Group: $CurDistinguishedName not found on TargetDC: $TargetDC"
                                    }

                                    if ($Group)
                                    {

                                        $GroupSamAccountName = $Group.SamAccountName
                                        $GroupDisplayName = $Group.Name
                                        $GroupDomain = $DomainFQDN
                                        $GroupType = $Group.GroupType
                                        $GroupSID = $Group.ObjectSID
                                        $GroupMemberDNs = $Group.Member
                                        $GroupDistinguishedName = $Group.DistinguishedName
                                        $Index = $GroupDistinguishedName.IndexOf(",")
                                        $Length = $GroupDistinguishedName.Length
                                        $AppliedLength = $Length - ($Index + 1)
                                        $GroupContainer = $GroupDistinguishedName.Substring($Index+1,$AppliedLength)

                                        $IsDomainLocal = ($GroupType -band 4) -ne 0
                                        $IsGlobal = ($GroupType -band 2) -ne 0
                                        $IsUniversal = ($GroupType -band 8) -ne 0
                                        $IsSecurity = ($GroupType -band 0x80000000) -ne 0

                                        if ($IsDomainLocal -eq $true) {$GroupScope = "DomainLocal"}
                                        if ($IsGlobal -eq $true) {$GroupScope = "Global"}
                                        if ($IsUniversal -eq $true) {$GroupScope = "Universal"}

                                        $Index = $CurDistinguishedName.IndexOf("DC=")
                                        $Length = $CurDistinguishedName.Length + 1
                                        $AppliedLength = $Length - ($Index+1)
                                        $DomainDN = $CurDistinguishedName.Substring($Index,$AppliedLength)

                                        #Get Explicit Membership
                                        $dicMemberDNs.Clear()
                                        $dicTmpMemberDistinguishedName.Clear()
                                        $dicTmpGroupSamAccountName.Clear()
                                        $dicTmpGroupDisplayName.Clear()
                                        $dicTmpGroupDomain.Clear()
                                        $dicTmpGroupScope.Clear()
                                        $dicTmpGroupSID.Clear()
                                        $dicTmpGroupDistinguishedName.Clear()
                                        $dicTmpGroupContainer.Clear()
                                        $dicTmpdicMemberDNs.Clear()
                                        $dicTmpURAInternalName.Clear()
                                        $dicTmpServerFQDN.Clear()
                                        $dicTmpServerDistinguishedName.Clear()
                                        $dicTmpServerContainer.Clear()
                                        $dicTmpInfo.Clear()


                                        foreach ($MemberDN in $GroupMemberDNs) 
                                        {

                                            WriteLog "MemberDN: $MemberDN"

                                            $MemberDistinguishedName = $MemberDN

                                            $Index = $MemberDistinguishedName.IndexOf("DC=")
                                            $Length = $MemberDistinguishedName.Length + 1
                                            $AppliedLength = $Length - ($Index+1)
                                            $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                                            $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                                            $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                                            $Index = $MemberDistinguishedName.IndexOf(",OU=")
                                            if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
                                            if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

                                            $Length = $MemberDistinguishedName.Length
                                            $AppliedLength = $Length - ($Index + 1)
                                            $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)
        
                                            $MemberTargetDC = GetClosestDC $MemberDomainFQDN

                                            if ($dicADObjects.ContainsKey($MemberDistinguishedName) -eq $true)
                                            {
                                                $Member = $dicADObjects.$MemberDistinguishedName
                                            } else {
                                                $Member = GetADObject2 $MemberDistinguishedName $MemberTargetDC $true
                                            }

                                            $MemberDisplayName = $Member.name
                                            $MemberObjectClass = $Member.objectClass

                                            if ($MemberDisplayName -ne $null -and $MemberDisplayName -ne "" -and $MemberObjectClass -ne $null -and $MemberObjectClass -ne "")
                                            {

                                                if ($MemberDisplayName.contains("S-1-5-21-") -and $MemberObjectClass -eq "foreignSecurityPrincipal")
                                                {
                                                    $RemoteMemberSID = $MemberDisplayName

                                                    $Index = $RemoteMemberSID.LastIndexOf("-")
                                                    $RemoteDomainSID = $RemoteMemberSID.Substring(0,$Index)

                                                    if ($dicTrustBySID.ContainsKey($RemoteDomainSID) -eq $true)
                                                    {
                
                                                        $RemoteDomainFQDN = $dicTrustBySID.$RemoteDomainSID
                                                        $RemoteDomainDC = $dicTrustByFQDN.$RemoteDomainFQDN

                                                        if ($dicADObjects.ContainsKey($RemoteMemberSID) -eq $true)
                                                        {
                                                            $Member = $dicADObjects.$RemoteMemberSID
                                                        } else {
                                                            $Member = GetADObject2 $RemoteMemberSID $RemoteDomainDC $false
                                                        }
                                                        $MemberDistinguishedName=$Member.DistinguishedName
                                                        $Index = $MemberDistinguishedName.IndexOf("DC=")
                                                        $Length = $MemberDistinguishedName.Length + 1
                                                        $AppliedLength = $Length - ($Index+1)
                                                        $MemberDomainDN = $MemberDistinguishedName.Substring($Index,$AppliedLength)

                                                        $MemberDomainFQDN = $MemberDomainDN -replace ",DC=", "."
                                                        $MemberDomainFQDN = $MemberDomainFQDN -replace "DC=", ""

                                                        $Index = $MemberDistinguishedName.IndexOf(",OU=")
                                                        if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",CN=")}
                                                        if ($Index -eq -1) {$Index = $MemberDistinguishedName.IndexOf(",DC=")}

                                                        $Length = $MemberDistinguishedName.Length
                                                        $AppliedLength = $Length - ($Index + 1)
                                                        $MemberContainer = $MemberDistinguishedName.Substring($Index+1,$AppliedLength)

                                                    }
                                                }
                                            }


                                            $MemberDisplayName = $Member.name
                                            $MemberSID = $Member.ObjectSID
                                            $MemberSamAccountName = $Member.SamAccountName
                                            $MemberObjectClass = $Member.objectClass

                                            if ($MemberObjectClass -eq "user" -or $MemberObjectClass -eq "computer" -or $MemberObjectClass -eq "msDS-GroupManagedServiceAccount") {
                                                $MemberUserAccountControl = $Member.UserAccountControl
                                                if (($MemberUserAccountControl -band 2) -ne 2) {
                                                    $MemberState = "Enabled"
                                                } else {
                                                    $MemberState = "Disabled"
                                                }
                                            } else {
                                                $MemberState = ""
                                                $MemberUserAccountControl = ""
                                            }

                                            if ($dicMemberDNs.ContainsKey($MemberDistinguishedName) -eq $false) {
                                                $dicMemberDNs.Add($MemberDistinguishedName,"")


                                                $DetectDuplicates = $MemberDistinguishedName + $CurServerFQDN + $CurURAInternalName

                                                $DupFound=$false

                                                if ($dicLinesOut.ContainsKey($DetectDuplicates) -eq $false)
                                                {
                                                    $dicLinesOut.Add($DetectDuplicates,"")
                                                    
                                                } else {
                                                    $DupFound=$true
                                                }
            

                                                WriteLog ""
                                                WriteLog "MemberDistinguishedName: $MemberDistinguishedName"
                                                WriteLog "MemberDisplayName: $MemberDisplayName"
                                                WriteLog "MemberSID: $MemberSID"
                                                WriteLog "MemberSamAccountName: $MemberSamAccountName"
                                                WriteLog "MemberObjectClass: $MemberObjectClass"
                                                WriteLog "MemberDomainDN: $MemberDomainDN"
                                                WriteLog "MemberDomainFQDN: $MemberDomainFQDN"
                                                WriteLog "MemberTargetDC: $MemberTargetDC"
                                                WriteLog "MemberContainer: $MemberContainer"
                                                WriteLog "MemberUserAccountControl: $MemberUserAccountControl"
                                                WriteLog "MemberState: $MemberState"
                                                WriteLog "MemberMemberShipType: Explicit"

                                                $LineOut = '"' + $MemberSamAccountName + '",'`
                                                            + '"' + $MemberDisplayName  + '",'`
                                                            + '"' + $MemberDomainFQDN  + '",'`
                                                            + '"' + $MemberSID  + '",'`
                                                            + '"' + $MemberDistinguishedName  + '",'`
                                                            + '"' + $MemberState  + '",'`
                                                            + '"' + $MemberObjectClass  + '",'`
                                                            + '"' + $MemberUserAccountControl  + '",'`
                                                            + '"Nested",'`
                                                            + '"' + $MemberContainer  + '",'`
                                                            + '"' + $CurURAInternalName  + '",'`
                                                            + '"' + $CurServerFQDN  + '",'`
                                                            + '"' + $CurServerDistinguishedName  + '",'`
                                                            + '"' + $CurServerContainer  + '",'`
                                                            + '"' + $CurInfo  + '"'

                                                if ($dicServerFQDNs.ContainsKey($CurServerFQDN) -eq $true -and $dicTier0URAInternalNames.ContainsKey($CurURAInternalName) -eq $true -and $DupFound -eq $false)
                                                {
                                                    Add-Content -Path $Tier0URAOutFile -Value $LineOut -Encoding Unicode
                                                }

                                                Add-Content -Path $AllURAOutFile -Value $LineOut -Encoding Unicode
        
                                                if ($MemberObjectClass -eq "group")
                                                {
                                                    $dicTmpMemberDistinguishedName.add($MemberDistinguishedName,$MemberDistinguishedName)
                                                    $dicTmpGroupSamAccountName.add($MemberDistinguishedName,$GroupSamAccountName)
                                                    $dicTmpGroupDisplayName.add($MemberDistinguishedName,$GroupDisplayName)
                                                    $dicTmpGroupDomain.add($MemberDistinguishedName,$GroupDomain)
                                                    $dicTmpGroupScope.add($MemberDistinguishedName,$GroupScope)
                                                    $dicTmpGroupSID.add($MemberDistinguishedName,$GroupSID)
                                                    $dicTmpGroupDistinguishedName.add($MemberDistinguishedName,$GroupDistinguishedName)
                                                    $dicTmpGroupContainer.add($MemberDistinguishedName,$GroupContainer)
                                                    $dicTmpdicMemberDNs.add($MemberDistinguishedName,$dicMemberDNs)

                                                    $dicTmpURAInternalName.add($MemberDistinguishedName,$CurURAInternalName)
                                                    $dicTmpServerFQDN.add($MemberDistinguishedName,$CurServerFQDN)
                                                    $dicTmpServerDistinguishedName.add($MemberDistinguishedName,$CurServerDistinguishedName)
                                                    $dicTmpServerContainer.add($MemberDistinguishedName,$CurServerContainer)
                                                    $dicTmpInfo.add($MemberDistinguishedName,$CurInfo)

                                                }

                                            }
                                        }
                                    }
                                    foreach ($Key in $dicTmpMemberDistinguishedName.Keys)
                                    {
                                        $MemberDistinguishedName = $dicTmpMemberDistinguishedName.$Key
                                        $GroupSamAccountName = $dicTmpGroupSamAccountName.$Key
                                        $GroupDisplayName = $dicTmpGroupDisplayName.$Key
                                        $GroupDomain = $dicTmpGroupDomain.$Key
                                        $GroupScope = $dicTmpGroupScope.$Key
                                        $GroupSID = $dicTmpGroupSID.$Key
                                        $GroupDistinguishedName = $dicTmpGroupDistinguishedName.$Key
                                        $GroupContainer = $dicTmpGroupContainer.$Key
                                        $dicMemberDNs = $dicTmpdicMemberDNs.$Key

                                        $URAInternalName = $dicTmpURAInternalName.$Key
                                        $ServerFQDN = $dicTmpServerFQDN.$Key
                                        $ServerDistinguishedName = $dicTmpServerDistinguishedName.$Key
                                        $ServerContainer = $dicTmpServerContainer.$Key
                                        $Info = $dicTmpInfo.$Key

                                        GetNestedMembers $MemberDistinguishedName $GroupSamAccountName $GroupDisplayName $GroupDomain $GroupScope $GroupSID $GroupDistinguishedName $GroupContainer $URAInternalName $ServerFQDN $ServerDistinguishedName $ServerContainer $Info
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }    
    }
}

############
### Main ###
############

WriteLog "" $True
WriteLog "CollectionMode: $CollectionMode"

DetermineIfPreferredDCsHaveBeenDefined
ReadDCINFOFile
DetermineTrustRelationships
ReadTier0MemberServerFile
ReadURAInternalNameFile
ProduceTier0URAFile

WriteLog "Done.  File saved to $Tier0URAOutFile." $true
$EndTime = Get-Date
$ElapsedTime = $EndTime - $StartTime
WriteLog "Elapsed time: $ElapsedTime" $true
WriteLog "" $true

# SIG # Begin signature block
# MIIoRgYJKoZIhvcNAQcCoIIoNzCCKDMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBgJdfMLG2wxpp7
# F6iHpmUcJaMZEVRsxcZHwgCnDsphkaCCDXYwggX0MIID3KADAgECAhMzAAAEhV6Z
# 7A5ZL83XAAAAAASFMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM3WhcNMjYwNjE3MTgyMTM3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDASkh1cpvuUqfbqxele7LCSHEamVNBfFE4uY1FkGsAdUF/vnjpE1dnAD9vMOqy
# 5ZO49ILhP4jiP/P2Pn9ao+5TDtKmcQ+pZdzbG7t43yRXJC3nXvTGQroodPi9USQi
# 9rI+0gwuXRKBII7L+k3kMkKLmFrsWUjzgXVCLYa6ZH7BCALAcJWZTwWPoiT4HpqQ
# hJcYLB7pfetAVCeBEVZD8itKQ6QA5/LQR+9X6dlSj4Vxta4JnpxvgSrkjXCz+tlJ
# 67ABZ551lw23RWU1uyfgCfEFhBfiyPR2WSjskPl9ap6qrf8fNQ1sGYun2p4JdXxe
# UAKf1hVa/3TQXjvPTiRXCnJPAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuCZyGiCuLYE0aU7j5TFqY05kko0w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwNTM1OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBACjmqAp2Ci4sTHZci+qk
# tEAKsFk5HNVGKyWR2rFGXsd7cggZ04H5U4SV0fAL6fOE9dLvt4I7HBHLhpGdE5Uj
# Ly4NxLTG2bDAkeAVmxmd2uKWVGKym1aarDxXfv3GCN4mRX+Pn4c+py3S/6Kkt5eS
# DAIIsrzKw3Kh2SW1hCwXX/k1v4b+NH1Fjl+i/xPJspXCFuZB4aC5FLT5fgbRKqns
# WeAdn8DsrYQhT3QXLt6Nv3/dMzv7G/Cdpbdcoul8FYl+t3dmXM+SIClC3l2ae0wO
# lNrQ42yQEycuPU5OoqLT85jsZ7+4CaScfFINlO7l7Y7r/xauqHbSPQ1r3oIC+e71
# 5s2G3ClZa3y99aYx2lnXYe1srcrIx8NAXTViiypXVn9ZGmEkfNcfDiqGQwkml5z9
# nm3pWiBZ69adaBBbAFEjyJG4y0a76bel/4sDCVvaZzLM3TFbxVO9BQrjZRtbJZbk
# C3XArpLqZSfx53SuYdddxPX8pvcqFuEu8wcUeD05t9xNbJ4TtdAECJlEi0vvBxlm
# M5tzFXy2qZeqPMXHSQYqPgZ9jvScZ6NwznFD0+33kbzyhOSz/WuGbAu4cHZG8gKn
# lQVT4uA2Diex9DMs2WHiokNknYlLoUeWXW1QrJLpqO82TLyKTbBM/oZHAdIc0kzo
# STro9b3+vjn2809D0+SOOCVZMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiYwghoiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAASFXpnsDlkvzdcAAAAABIUwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINe9VH29shwaz3tLrLXLijDm
# tMOw/YUIyjf8mwW5y76QMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAaj+ZrOQ9yCn4MOR8LfmhAl169pxMi38+f6nuWTm3iGQI3WSmXKtu3s2i
# 7T0uDbubP9WycRYTDI3OKzQpjNjdIvtKJnhDHNjmZCxNRtN1lg09G4g5CWdSyOXR
# /n8nEytCT2uTK8UNq/7Ag1SZPloS3gvmNssM1Dt6itoQ2xbsjPmUQGGHqLGt/rSB
# Lxr40TjOdfWvQOcOD5CFxBc5julyoj5JmvDpnUXdzck0omxj+R9oCti88gr1vDSD
# MmJ7n7aphAo3mUwU+BUbhZWMmnHufydFpohvwMAI7i5ujOg360VwvpMFHFwCx0Gb
# KVIl0Rn1f6qlcBi+l2qzJe8gSVIebKGCF7AwghesBgorBgEEAYI3AwMBMYIXnDCC
# F5gGCSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCZCXfVDsGoKgDw4y+tBuK6ZUncxA/dSR3PQq6RI8288wIGaHpQLYkg
# GBMyMDI1MDcyOTE4Mjg0NC43MTRaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo0MDFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEf4wggcoMIIFEKADAgECAhMzAAAB/tCowns0IQsBAAEAAAH+MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzExOFoXDTI1MTAyMjE4MzExOFowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjQwMUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvLwhFxWlqA43olsE4PCe
# gZ4mSfsH2YTSKEYv8Gn3362Bmaycdf5T3tQxpP3NWm62YHUieIQXw+0u4qlay4AN
# 3IonI+47Npi9fo52xdAXMX0pGrc0eqW8RWN3bfzXPKv07O18i2HjDyLuywYyKA9F
# mWbePjahf9Mwd8QgygkPtwDrVQGLyOkyM3VTiHKqhGu9BCGVRdHW9lmPMrrUlPWi
# YV9LVCB5VYd+AEUtdfqAdqlzVxA53EgxSqhp6JbfEKnTdcfP6T8Mir0HrwTTtV2h
# 2yDBtjXbQIaqycKOb633GfRkn216LODBg37P/xwhodXT81ZC2aHN7exEDmmbiWss
# jGvFJkli2g6dt01eShOiGmhbonr0qXXcBeqNb6QoF8jX/uDVtY9pvL4j8aEWS49h
# KUH0mzsCucIrwUS+x8MuT0uf7VXCFNFbiCUNRTofxJ3B454eGJhL0fwUTRbgyCbp
# LgKMKDiCRub65DhaeDvUAAJT93KSCoeFCoklPavbgQyahGZDL/vWAVjX5b8Jzhly
# 9gGCdK/qi6i+cxZ0S8x6B2yjPbZfdBVfH/NBp/1Ln7xbeOETAOn7OT9D3UGt0q+K
# iWgY42HnLjyhl1bAu5HfgryAO3DCaIdV2tjvkJay2qOnF7Dgj8a60KQT9QgfJfwX
# nr3ZKibYMjaUbCNIDnxz2ykCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBRvznuJ9SU2
# g5l/5/b+5CBibbHF3TAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAiT4NUvO2lw+0
# dDMtsBuxmX2o3lVQqnQkuITAGIGCgI+sl7ZqZOTDd8LqxsH4GWCPTztc3tr8AgBv
# sYIzWjFwioCjCQODq1oBMWNzEsKzckHxAzYo5Sze7OPkMA3DAxVq4SSR8y+TRC2G
# cOd0JReZ1lPlhlPl9XI+z8OgtOPmQnLLiP9qzpTHwFze+sbqSn8cekduMZdLyHJk
# 3Niw3AnglU/WTzGsQAdch9SVV4LHifUnmwTf0i07iKtTlNkq3bx1iyWg7N7jGZAB
# RWT2mX+YAVHlK27t9n+WtYbn6cOJNX6LsH8xPVBRYAIRVkWsMyEAdoP9dqfaZzwX
# GmjuVQ931NhzHjjG+Efw118DXjk3Vq3qUI1re34zMMTRzZZEw82FupF3viXNR3DV
# OlS9JH4x5emfINa1uuSac6F4CeJCD1GakfS7D5ayNsaZ2e+sBUh62KVTlhEsQRHZ
# RwCTxbix1Y4iJw+PDNLc0Hf19qX2XiX0u2SM9CWTTjsz9SvCjIKSxCZFCNv/zpKI
# lsHx7hQNQHSMbKh0/wwn86uiIALEjazUszE0+X6rcObDfU4h/O/0vmbF3BMR+45r
# AZMAETJsRDPxHJCo/5XGhWdg/LoJ5XWBrODL44YNrN7FRnHEAAr06sflqZ8eeV3F
# uDKdP5h19WUnGWwO1H/ZjUzOoVGiV3gwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo0MDFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAhGNHD/a7Q0bQLWVG9JuGxgLRXseggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOwzTmgwIhgPMjAyNTA3MjkxMzQzMDRaGA8yMDI1MDczMDEzNDMwNFowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA7DNOaAIBADAKAgEAAgIP0QIB/zAHAgEAAgIS
# VDAKAgUA7DSf6AIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQARqCun8ESZ
# /t2r/hITWHimPgRMJLdxJhkdrujpRSLT/JON+HOBI1G1AO0xPHmkXSzQu8Wkmnq9
# 0XN5OX72p1L+p0Yr6gvG3dEQmF2noEGNmlaSENbyyn4d9TxYPSVtZw+eZ1bb6Yi7
# 5Jj1zKPqwwydjEImIyNTPQVG3iKgBvNTsJ2Mucmtcic/rs1Xj5SdPoeMUB5hMqbs
# dEQctOPZMpBpy1pLkMZ+A2l5m1YnGRitokF7LXW0PYNDAicSxxhqSCKOthXI7H6k
# 2j3BzFypSk6mteJk+LTT/IW66lTKbMlFk/ale2DcBiHAP8ZnsMjphx0GdphYmWe0
# mnBuE5QxBvC1MYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAH+0KjCezQhCwEAAQAAAf4wDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgg0xo0bVl
# acwMtwgwOPCqxim5SXuk8AKWR3oLJB4nuhkwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCARhczd/FPInxjR92m2hPWqc+vGOG1+/I0WtkCstyh0eTCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB/tCowns0IQsBAAEA
# AAH+MCIEIKDiKxWL3EcpSWLprZB19J/KYtUelswosTCm2Rnmi2jmMA0GCSqGSIb3
# DQEBCwUABIICADpD0pXrJNcnWKmf0w9MeFrsccY9FAEzTQvH74dHysfleWbB0NmK
# bCac9g2FME8HtDO8WeXf1EbwRfQ+yX/YoUE3cLgIFEns8W5j68CIHq9XmBSjrNns
# vzvAIF45Vc1uPDDRyq2aEP5M5vtnrGdNDxT3HyHUX2xUSBsbU35OueUrpNk1JC6w
# YvOWQlt5Kkr8pY0cfoi1nP2ddcDMI9knVEP9m88zGbiOlPns4OfWiGdmjGC4JbfZ
# 53+CGBJtYuJ54beSoAmwI/6yGHaicdZP+TQiu1KaBHj8EOg/AGF90p0aB7mb1THK
# v/iFkV5kBsPyL1cgsuSk1FpItMOZB0peKYoyYYOKcLGbv4H0bkUyS1TI4f0XrC/g
# UZaJzJLQUH5EjkqiGp3PXc2BFh/P/de4HmC9hxEjdGvcYER3O5OgLUboYGIGyH6F
# 6jP0UeggpkKRm3esKnter7rmAmOw/hCuedhPwux/raEienaxu/TfkKe0BnYRqKr3
# Xj9pLlHLXV7lpdzWIDLHkIO3yBU3uN6HEMS4kP7futrZoJ1/BnnbHcovLCwpkizZ
# BYb057Qf2Wnz7OS/cy2OYGgnN1qm+Qa+nhEmpdMW+MDdDqddw2B684FxPuhQ/XG+
# O3PI9O22/R82UGzoarG06eg4xLC0ZpsqrjbhNm+vl5uW3w3KHzBF9hsx
# SIG # End signature block
