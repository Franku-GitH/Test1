﻿# Written by Kip Gumenberg, Microsoft Security Enterprise Services, March 2024
############
### Init ###
############
param (
     [switch]$Debug 
)
$FileTime = get-date -format "MM-dd-yyyy-HH-mm"

$ScriptRoot = $PSScriptRoot
$CurFolder = $PSScriptRoot + "\Reports"
write-host "ScriptRoot: $ScriptRoot"
write-host "CurFolder: $CurFolder"

$DebugFlag = "off"

if ($Debug.IsPresent -eq $true) {
    $DebugFlag="on"
}

$StartTime = Get-Date


###################
### Input Files ###
###################
$Tier0GroupFiles = gci $CurFolder\Tier0GroupMembership-*.CSV | sort LastWriteTime | select -last 2
if ($Tier0GroupFiles.Count -lt 2)
{
    Write-host "There aren't at least 2 instances of data to compare, exiting."
    exit
}

$Tier0URAFiles = gci $CurFolder\Tier0UserRightsAssignments-*.CSV | sort LastWriteTime | select -last 2
$Tier0MemberServerFiles = gci $CurFolder\Tier0MemberServerGroupMembership-*.CSV | sort LastWriteTime | select -last 2
$Tier0AdminSDHolderFiles = gci $CurFolder\Tier0AdminSDHolderPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0ConfigurationFiles = gci $CurFolder\Tier0ConfigurationNCPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0ContainerFiles = gci $CurFolder\Tier0ContainerPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0DomainRootFiles = gci $CurFolder\Tier0DomainRootPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0GPOFiles = gci $CurFolder\Tier0GPOPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0SchemaFiles = gci $CurFolder\Tier0SchemaNCPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0SecurityPrincipalFiles = gci $CurFolder\Tier0SecurityPrincipalPermissions-*.CSV | sort LastWriteTime | select -last 2
$Tier0RegistryFiles = gci $CurFolder\Tier0RegistryAccess-*.CSV | sort LastWriteTime | select -last 2
$Tier0ShareFiles = gci $CurFolder\Tier0ShareAccess-*.CSV | sort LastWriteTime | select -last 2
$Tier0TrustRelationshipFiles = gci $CurFolder\Tier0TrustRelationships-*.CSV | sort LastWriteTime | select -last 2
$NonTier0AdminCountFiles = gci $CurFolder\NonTier0AdminCount-*.CSV | sort LastWriteTime | select -last 2
$Tier0SidHistoryFiles = gci $CurFolder\Tier0SidHistory-*.CSV | sort LastWriteTime | select -last 2

####################
### Output Files ###
####################
$LogFile = $CurFolder + "\" + "CompareTier0GroupMembership.LOG"
$Tier0GroupComparison = $CurFolder + "\" + "Tier0GroupComparison-$FileTime.CSV"
$Tier0UserRightsComparison = $CurFolder + "\" + "Tier0UserRightsAssignmentComparison-$FileTime.CSV"
$Tier0MemberServerComparison = $CurFolder + "\" + "Tier0MemberServerGroupMembershipComparison-$FileTime.CSV"
$Tier0AdminSDHolderComparison = $CurFolder + "\" + "Tier0AdminSDHolderComparison-$FileTime.CSV"
$Tier0ConfigurationComparison = $CurFolder + "\" + "Tier0ConfigurationNCComparison-$FileTime.CSV"
$Tier0ContainerComparison = $CurFolder + "\" + "Tier0ContainerComparison-$FileTime.CSV"
$Tier0DomainRootComparison = $CurFolder + "\" + "Tier0DomainRootComparison-$FileTime.CSV"
$Tier0GPOComparison = $CurFolder + "\" + "Tier0GPOComparison-$FileTime.CSV"
$Tier0SchemaComparison = $CurFolder + "\" + "Tier0SchemaNCComparison-$FileTime.CSV"
$Tier0SecurityPrincipalComparison = $CurFolder + "\" + "Tier0SecurityPrincipalComparison-$FileTime.CSV"
$Tier0RegistryComparison = $CurFolder + "\" + "Tier0RegistryComparison-$FileTime.CSV"
$Tier0ShareComparison = $CurFolder + "\" + "Tier0ShareComparison-$FileTime.CSV"
$Tier0TrustRelationshipComparison = $CurFolder + "\" + "Tier0TrustRelationshipsComparison-$FileTime.CSV"
$NonTier0AdminCountComparison = $CurFolder + "\" + "NonTier0AdminCountComparison-$FileTime.CSV"
$Tier0SidHistoryComparison = $CurFolder + "\" + "Tier0SidHistoryComparison-$FileTime.CSV"

$LineOut = '"GroupDN",'`
            + '"ChangeType",'`
            + '"MemberDN"'

Set-Content -Path $Tier0GroupComparison -Value $LineOut -Encoding Unicode

$LineOut = '"UserRightAssignment",'`
            + '"ChangeType",'`
            + '"MemberDN"'

Set-Content -Path $Tier0UserRightsComparison -Value $LineOut -Encoding Unicode

$LineOut = '"LocalGroupName",'`
            + '"ChangeType",'`
            + '"MemberDN"'

Set-Content -Path $Tier0MemberServerComparison -Value $LineOut -Encoding Unicode

$LineOut = '"ChangeType",'`
            + '"Tier0DistinguishedName",'`
            + '"AccessRulesProtected",'`
            + '"ObjectTypeName",'`
            + '"InheritedObjectTypeName",'`
            + '"ActiveDirectoryRights",'`
            + '"InheritanceType",'`
            + '"ObjectTypeGUID",'`
            + '"InheritedObjectTypeGUID",'`
            + '"ObjectFlags",'`
            + '"AccessControlType",'`
            + '"IdentityReference",'`
            + '"IdentityObjectClass",'`
            + '"IdentityDistinguishedName",'`
            + '"IdentityContainer",'`
            + '"IdentityDomainFQDN",'`
            + '"IdentityType",'`
            + '"IsInherited",'`
            + '"InheritanceFlags",'`
            + '"PropagationFlags",'`
            + '"OwnerIdentityReference",'`
            + '"OwnerDistinguishedName",'`
            + '"OwnerObjectClass",'`
            + '"OwnerDomainFQDN",'`
            + '"Reason"'


Set-Content -Path $Tier0AdminSDHolderComparison -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0ConfigurationComparison -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0ContainerComparison -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0DomainRootComparison -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0GPOComparison -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0SchemaComparison -Value $LineOut -Encoding Unicode
Set-Content -Path $Tier0SecurityPrincipalComparison -Value $LineOut -Encoding Unicode

$LineOut = '"ChangeType",'`
            + '"ServerFQDN",'`
            + '"Name",'`
            + '"SamAccountName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"DistinguishedName",'`
            + '"RegistryLocation",'`
            + '"Access",'`
            + '"AccessType",'`
            + '"IsInherited",'`
            + '"Owner",'`
            + '"OwnerName",'`
            + '"OwnerDistinguishedName",'`
            + '"OwnerObjectClass",'`
            + '"OwnerDomainFQDN",'`
            + '"MembershipType",'`
            + '"Reason"'

Set-Content -Path $Tier0RegistryComparison -Value $LineOut -Encoding Unicode

$LineOut = '"ChangeType",'`
            + '"ServerFQDN",'`
            + '"Name",'`
            + '"SamAccountName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"DistinguishedName",'`
            + '"ShareName",'`
            + '"Access",'`
            + '"AccessType",'`
            + '"SharePath",'`
            + '"MembershipType",'`
            + '"Reason"'

Set-Content -Path $Tier0ShareComparison -Value $LineOut -Encoding Unicode

$LineOut = '"ChangeType",'`
            + '"Direction",'`
            + '"DisallowTransivity",'`
            + '"DistinguishedName",'`
            + '"ForestTransitive",'`
            + '"IntraForest",'`
            + '"IsTreeParent",'`
            + '"IsTreeRoot",'`
            + '"ObjectClass",'`
            + '"ObjectGUID",'`
            + '"SelectiveAuthentication",'`
            + '"SIDFilteringForestAware",'`
            + '"SIDFilteringQuarantined",'`
            + '"Source",'`
            + '"Target",'`
            + '"TGTDelegation",'`
            + '"TrustAttributes",'`
            + '"TrustedPolicy",'`
            + '"TrustingPolicy",'`
            + '"TrustType",'`
            + '"UplevelOnly",'`
            + '"UsesAESKeys",'`
            + '"UsesRC4Encryption",'`
            + '"Reason"'

Set-Content -Path $Tier0TrustRelationshipComparison -Value $LineOut -Encoding Unicode

$LineOut = '"ChangeType",'`
            + '"DistinguisheName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"AdminCount",'`
            + '"ObjectSID",'`
            + '"Reason"'

Set-Content -Path $NonTier0AdminCountComparison -Value $LineOut -Encoding Unicode

$LineOut = '"ChangeType",'`
            + '"DistinguisheName",'`
            + '"Domain",'`
            + '"ObjectClass",'`
            + '"SIDHistory",'`
            + '"RIDFound",'`
            + '"Tier0Object",'`
            + '"Reason"'

Set-Content -Path $Tier0SidHistoryComparison -Value $LineOut -Encoding Unicode

###################
### Write Event ###
###################
Function WriteEvent
{
    param (
        $EventID,
        $EventMessage,
        $EventType
    )

    if (-not [System.Diagnostics.EventLog]::SourceExists("Tier 0 Monitoring")) {
        [System.Diagnostics.EventLog]::CreateEventSource("Tier 0 Monitoring", "Application")
    }

    [System.Diagnostics.EventLog]::WriteEntry("Tier 0 Monitoring", $EventMessage, $EventType, $EventID)

}

#################
### Write Log ###
#################
Function WriteLog
{
    param ($LineIn)
    $CurTime =  get-date -UFormat "%m/%d/%Y %T"
    $LineOut = "$CurTime $LineIn"
    if ($DebugFlag -eq "on") {
        Add-Content -Path $LogFile -Value $LineOut -Encoding Unicode
    }

}

#######################################
### Monitor Tier 0 Group Membership ###
#######################################
$OlderFile = $Tier0GroupFiles[0]
$NewerFile = $Tier0GroupFiles[1]
Write-host "Comparing Newer File: $NewerFile to Older File: $OlderFile."

$NewerCSV = Import-Csv $NewerFile
$OlderCSV = Import-CSV $OlderFile

$dicNewGroupDNs = @{}
$dicOldGroupDNs = @{}

$dicAdds = @{}
$dicDeletes = @{}

foreach ($Row in $NewerCSV)
{
    $GroupDN = $Row.GroupDistinguishedName
    if ($dicNewGroupDNs.ContainsKey($GroupDN) -eq $false)
    {
        $dicNewGroupDNs.Add($GroupDN,"")
    }
}

foreach ($Row in $OlderCSV)
{
    $GroupDN = $Row.GroupDistinguishedName
    if ($dicOldGroupDNs.ContainsKey($GroupDN) -eq $false)
    {
        $dicOldGroupDNs.Add($GroupDN,"")
    }
}
$NewCount = $dicNewGroupDNs.Count
$OldCount = $dicOldGroupDNs.Count

foreach ($Key in $dicNewGroupDNs.Keys)
{
    WriteLog "Comparing: $Key"

    $dicNewMembers = @{}
    $dicOldMembers = @{}

    foreach ($Row in $NewerCSV)
    {
        $NewGroupDN = $Row.GroupDistinguishedName
        $NewMemberDN = $Row.MemberDistinguishedName
        
        if ($Key -eq $NewGroupDN)
        {
            $dicNewMembers.add($NewMemberDN,"...")    
        }
    }
    foreach ($Row in $OlderCSV)
    {
        $OldGroupDN = $Row.GroupDistinguishedName
        $OldMemberDN = $Row.MemberDistinguishedName
        
        if ($Key -eq $OldGroupDN)
        {
            $dicOldMembers.add($OldMemberDN,"...")    
        }
    }
    
    foreach ($Key2 in $dicNewMembers.Keys)
    {

        if ($dicOldMembers.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"' + $Key + '",'`
                        + '"Member Added",'`
                        + '"' + $Key2  + '"'

            Add-Content -Path $Tier0GroupComparison -Value $LineOut -Encoding Unicode

            $LineOut2 = "'$Key2' was added to '$Key' `r`n"
            $dicAdds.Add($LineOut2,"")

        }
    }

    foreach ($Key2 in $dicOldMembers.Keys)
    {

        if ($dicNewMembers.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"' + $Key + '",'`
                        + '"Member Removed",'`
                        + '"' + $Key2  + '"'

            Add-Content -Path $Tier0GroupComparison -Value $LineOut -Encoding Unicode
            
            $LineOut2 = "'$Key2' was removed from '$Key' `r`n"
            $dicDeletes.Add($LineOut2,"")
        }
    }

}
$AddMessage = "The following members have been added to Tier 0 Groups:`r`n`r`n"
$DeleteMessage = "The following members have been removed from Tier 0 Groups:`r`n`r`n"

$Counter=0
foreach ($Line in $dicAdds.Keys)
{
    $Counter=$Counter+1
    if ($Counter -lt 26)
    {
        $AddMessage = $AddMessage + $Line
    } else {
        if ($Counter -eq 26)
        {
            $AddMessage = "This event has been truncated.  Please see $Tier0GroupComparison for full results.`r`n`r`n" + $AddMessage
            WriteEvent 20241 $AddMessage "Warning"    
        }
        $Counter=$Counter + 1
    }
}
if ($Counter -gt 0 -and $Counter -lt 26)
{
    WriteEvent 20241 $AddMessage "Warning"     
}

$Counter=0
foreach ($Line in $dicDeletes.Keys)
{
    $Counter=$Counter+1
    if ($Counter -lt 26)
    {
        $DeleteMessage = $DeleteMessage + $Line
    } else {
        if ($Counter -eq 26)
        {
            $DeleteMessage = "This event has been truncated.  Please see $Tier0GroupComparison for full results.`r`n`r`n" + $DeleteMessage
            WriteEvent 20242 $DeleteMessage "Information"    
        }
        $Counter=$Counter + 1
    }
}
if ($Counter -gt 0 -and $Counter -lt 26)
{
    WriteEvent 20242 $DeleteMessage "Information"    
}



##############################################
### Monitor Tier 0 User Rights Assignments ###
##############################################
$OlderFile = $Tier0URAFiles[0]
$NewerFile = $Tier0URAFiles[1]
Write-host "Comparing Newer File: $NewerFile to Older File: $OlderFile."

$NewerCSV = Import-Csv $NewerFile
$OlderCSV = Import-CSV $OlderFile

$dicServers = @{}
$dicURAs = @{}

$dicAdds = @{}
$dicDeletes = @{}

foreach ($Row in $NewerCSV)
{
    $URA = $Row.UserRightAssignment
    $Server = $Row.ServerFQDN
    if ($dicServers.ContainsKey($Server) -eq $false)
    {
        $dicServers.Add($Server,"")
    }
    if ($dicURAs.ContainsKey($URA) -eq $false)
    {
        $dicURAs.Add($URA,"")
    }
}

foreach ($Row in $OlderCSV)
{
    $URA = $Row.UserRightAssignment
    $Server = $Row.ServerFQDN
    if ($dicServers.ContainsKey($Server) -eq $false)
    {
        $dicServers.Add($Server,"")
    }
    if ($dicURAs.ContainsKey($URA) -eq $false)
    {
        $dicURAs.Add($URA,"")
    }
}

$dicNewMembers = @{}
$dicOldMembers = @{}

foreach ($Server in $dicServers.Keys)
{
    foreach ($URA in $dicURAs.Keys)
    {
        WriteLog "Comparing: $URA on $Server"

        $dicNewMembers.Clear()
        $dicOldMembers.Clear()

        foreach ($Row in $NewerCSV)
        {
            $NewURA = $Row.UserRightAssignment
            $NewServer = $Row.ServerFQDN
            $NewMemberDN = $Row.DistinguishedName
        
            if ($NewServer -eq $Server -and $NewURA -eq $URA -and $dicNewMembers.ContainsKey($NewMemberDN) -eq $false)
            {
                $dicNewMembers.add($NewMemberDN,"")    
            }
        }
        foreach ($Row in $OlderCSV)
        {
            $OldURA = $Row.UserRightAssignment
            $OldServer = $Row.ServerFQDN
            $OldMemberDN = $Row.DistinguishedName
        
            if ($OldServer -eq $Server -and $OldURA -eq $URA -and $dicOldMembers.ContainsKey($OldMemberDN) -eq $false)
            {
                $dicOldMembers.add($OldMemberDN,"")    
            }
        }
    
        foreach ($Key2 in $dicNewMembers.Keys)
        {

            if ($dicOldMembers.ContainsKey($Key2) -eq $false)
            {
                $LineOut = '"' + $Server + "\" + $URA + '",'`
                            + '"Member Added",'`
                            + '"' + $Key2  + '"'

                Add-Content -Path $Tier0UserRightsComparison -Value $LineOut -Encoding Unicode
                $LineOut2 = "'$Key2' was added to '$URA' on server '$Server' `r`n"
                $dicAdds.Add($LineOut2,"")

            }
        }

        foreach ($Key2 in $dicOldMembers.Keys)
        {

            if ($dicNewMembers.ContainsKey($Key2) -eq $false)
            {
                $LineOut = '"' + $Server + "\" + $URA + '",'`
                            + '"Member Removed",'`
                            + '"' + $Key2  + '"'

                Add-Content -Path $Tier0UserRightsComparison -Value $LineOut -Encoding Unicode
                $LineOut2 = "'$Key2' was removed from '$URA' on server '$Server' `r`n"
                $dicDeletes.Add($LineOut2,"")
            }
        }
    }
}

$AddMessage = "The following members have been added to Tier 0 User Rights Assignments:`r`n`r`n"
$DeleteMessage = "The following members have been removed from Tier 0 User Rights Assignments:`r`n`r`n"

$Counter=0
foreach ($Line in $dicAdds.Keys)
{
    $Counter=$Counter+1
    if ($Counter -lt 26)
    {
        $AddMessage = $AddMessage + $Line
    } else {
        if ($Counter -eq 26)
        {
            $AddMessage = "This event has been truncated.  Please see $Tier0UserRightsComparison for full results.`r`n`r`n" + $AddMessage
            WriteEvent 20243 $AddMessage "Warning"    
        }
        $Counter=$Counter + 1
    }
}
if ($Counter -gt 0 -and $Counter -lt 26)
{
    WriteEvent 20243 $AddMessage "Warning"     
}

$Counter=0
foreach ($Line in $dicDeletes.Keys)
{
    $Counter=$Counter+1
    if ($Counter -lt 26)
    {
        $DeleteMessage = $DeleteMessage + $Line
    } else {
        if ($Counter -eq 26)
        {
            $DeleteMessage = "This event has been truncated.  Please see $Tier0UserRightsComparison for full results.`r`n`r`n" + $DeleteMessage
            WriteEvent 20244 $DeleteMessage "Information"    
        }
        $Counter=$Counter + 1
    }
}
if ($Counter -gt 0 -and $Counter -lt 26)
{
    WriteEvent 20244 $DeleteMessage "Information"    
}



#####################################################
### Monitor Tier 0 Member Server Group Membership ###
#####################################################
$OlderFile = $Tier0MemberServerFiles[0]
$NewerFile = $Tier0MemberServerFiles[1]
Write-host "Comparing Newer File: $NewerFile to Older File: $OlderFile."

$NewerCSV = Import-Csv $NewerFile
$OlderCSV = Import-CSV $OlderFile

$dicServers = @{}
$dicGroups = @{}

$dicAdds = @{}
$dicDeletes = @{}

foreach ($Row in $NewerCSV)
{
    $Group = $Row.LocalGroupName
    $Server = $Row.ServerFQDN

    if ($dicServers.ContainsKey($Server) -eq $false)
    {
        $dicServers.Add($Server,"")
    }
    if ($dicGroups.ContainsKey($Group) -eq $false)
    {
        $dicGroups.Add($Group,"")
    }
}

foreach ($Row in $OlderCSV)
{
    $Group = $Row.LocalGroupName
    $Server = $Row.ServerFQDN
    if ($dicServers.ContainsKey($Server) -eq $false)
    {
        $dicServers.Add($Server,"")
    }
    if ($dicGroups.ContainsKey($Group) -eq $false)
    {
        $dicGroups.Add($Group,"")
    }
}

$dicNewMembers = @{}
$dicOldMembers = @{}

foreach ($Server in $dicServers.Keys)
{
    foreach ($Group in $dicGroups.Keys)
    {
        WriteLog "Comparing: $Group on $Server"

        $dicNewMembers.Clear()
        $dicOldMembers.Clear()

        foreach ($Row in $NewerCSV)
        {
            $NewGroup = $Row.LocalGroupName
            $NewServer = $Row.ServerFQDN
            $NewMemberDN = $Row.MemberDistinguishedName
        
            if ($NewServer -eq $Server -and $NewGroup -eq $Group -and $dicNewMembers.ContainsKey($NewMemberDN) -eq $false)
            {
                $dicNewMembers.add($NewMemberDN,"")    
            }
        }
        foreach ($Row in $OlderCSV)
        {
            $OldGroup = $Row.LocalGroupName
            $OldServer = $Row.ServerFQDN
            $OldMemberDN = $Row.MemberDistinguishedName
        
            if ($OldServer -eq $Server -and $OldGroup -eq $Group -and $dicOldMembers.ContainsKey($OldMemberDN) -eq $false)
            {
                $dicOldMembers.add($OldMemberDN,"")    
            }
        }
    
        foreach ($Key2 in $dicNewMembers.Keys)
        {

            if ($dicOldMembers.ContainsKey($Key2) -eq $false)
            {
                $LineOut = '"' + $Server + "\" + $Group + '",'`
                            + '"Member Added",'`
                            + '"' + $Key2  + '"'

                Add-Content -Path $Tier0MemberServerComparison -Value $LineOut -Encoding Unicode
                $LineOut2 = "'$Key2' was added to '$Group' on server '$Server' `r`n"
                $dicAdds.Add($LineOut2,"")

            }
        }

        foreach ($Key2 in $dicOldMembers.Keys)
        {

            if ($dicNewMembers.ContainsKey($Key2) -eq $false)
            {
                $LineOut = '"' + $Server + "\" + $Group + '",'`
                            + '"Member Removed",'`
                            + '"' + $Key2  + '"'

                Add-Content -Path $Tier0MemberServerComparison -Value $LineOut -Encoding Unicode
                $LineOut2 = "'$Key2' was removed from '$Group' on server '$Server' `r`n"
                $dicDeletes.Add($LineOut2,"")
            }
        }
    }
}

$AddMessage = "The following members have been added to Tier 0 Member Server Groups:`r`n`r`n"
$DeleteMessage = "The following members have been removed from Tier 0 Member Server Groups:`r`n`r`n"

$Counter=0
foreach ($Line in $dicAdds.Keys)
{
    $Counter=$Counter+1
    if ($Counter -lt 26)
    {
        $AddMessage = $AddMessage + $Line
    } else {
        if ($Counter -eq 26)
        {
            $AddMessage = "This event has been truncated.  Please see $Tier0MemberServerComparison for full results.`r`n`r`n" + $AddMessage
            WriteEvent 20245 $AddMessage "Warning"    
        }
        $Counter=$Counter + 1
    }
}
if ($Counter -gt 0 -and $Counter -lt 26)
{
    WriteEvent 20245 $AddMessage "Warning"     
}

$Counter=0
foreach ($Line in $dicDeletes.Keys)
{
    $Counter=$Counter+1
    if ($Counter -lt 26)
    {
        $DeleteMessage = $DeleteMessage + $Line
    } else {
        if ($Counter -eq 26)
        {
            $DeleteMessage = "This event has been truncated.  Please see $Tier0MemberServerComparison for full results.`r`n`r`n" + $DeleteMessage
            WriteEvent 20246 $DeleteMessage "Information"    
        }
        $Counter=$Counter + 1
    }
}
if ($Counter -gt 0 -and $Counter -lt 26)
{
    WriteEvent 20246 $DeleteMessage "Information"    
}

##########################
### Transoform GPO Row ###
##########################
Function TransformGPORow
{
    param ($Row)

    $Tier0DistinguishedName = $Row.Tier0DistinguishedName
    $AccessRulesProtected = $Row.AccessRulesProtected
    $ObjectTypeName = $Row.ObjectTypeName
    $InheritedObjectTypeName = $Row.InheritedObjectTypeName
    $ActiveDirectoryRights = $Row.ActiveDirectoryRights
    $InheritanceType = $Row.InheritanceType
    $ObjectTypeGUID = $Row.ObjectTypeGUID
    $InheritedObjectTypeGUID = $Row.InheritedObjectTypeGUID
    $ObjectFlags = $Row.ObjectFlags
    $AccessControlType = $Row.AccessControlType
    $IdentityReference = $Row.IdentityReference
    $IdentityObjectClass = $Row.IdentityObjectClass
    $IdentityDistinguishedName = $Row.IdentityDistinguishedName
    $IdentityContainer = $Row.IdentityContainer
    $IdentityDomainFQDN = $Row.IdentityDomainFQDN
    $IdentityType = $Row.IdentityType
    $IsInherited = $Row.IsInherited
    $InheritanceFlags = $Row.InheritanceFlags
    $PropagationFlags = $Row.PropagationFlags
    $OwnerIdentityReference = $Row.OwnerIdentityReference
    $OwnerDistinguishedName = $Row.OwnerDistinguishedName
    $OwnerObjectClass = $Row.OwnerObjectClass
    $OwnerDomainFQDN = $Row.OwnerDomainFQDN
    $Reason = $Row.Reason
    $GPOName = $Row.GPOName
    $WhenChanged = "n/a"
    $WhenCreated = $Row.WhenCreated
    $LinkedTo = "n/a"

    $RowOut     = '"' + $Tier0DistinguishedName + '",'`
                + '"' + $AccessRulesProtected  + '",'`
                + '"' + $ObjectTypeName  + '",'`
                + '"' + $InheritedObjectTypeName  + '",'`
                + '"' + $ActiveDirectoryRights  + '",'`
                + '"' + $InheritanceType  + '",'`
                + '"' + $ObjectTypeGUID  + '",'`
                + '"' + $InheritedObjectTypeGUID  + '",'`
                + '"' + $ObjectFlags  + '",'`
                + '"' + $AccessControlType  + '",'`
                + '"' + $IdentityReference  + '",'`
                + '"' + $IdentityObjectClass  + '",'`
                + '"' + $IdentityDistinguishedName  + '",'`
                + '"' + $IdentityContainer  + '",'`
                + '"' + $IdentityDomainFQDN  + '",'`
                + '"' + $IdentityType  + '",'`
                + '"' + $IsInherited  + '",'`
                + '"' + $InheritanceFlags  + '",'`
                + '"' + $PropagationFlags  + '",'`
                + '"' + $OwnerIdentityReference  + '",'`
                + '"' + $OwnerDistinguishedName  + '",'`
                + '"' + $OwnerObjectClass  + '",'`
                + '"' + $OwnerDomainFQDN  + '",'`
                + '"' + $Reason  + '",'`
                + '"' + $GPOName  + '",'`
                + '"' + $WhenChanged  + '",'`
                + '"' + $WhenCreated  + '",'`
                + '"' + $LinkedTo + '"'

    Return $RowOut
}

##################################
### Monitor Tier 0 Permissions ###
##################################
Function MonitorTier0Permissions
{
    param (
        $Tier0PermissionsFiles,
        $OutputFile,
        $Description,
        $AddEventID,
        $DeleteEventID
    )
    $c=0
    $OlderFile = $Tier0PermissionsFiles[0]
    $NewerFile = $Tier0PermissionsFiles[1]
    Write-host "Comparing Newer File: $NewerFile to Older File: $OlderFile."


    if ($Description -eq "Tier 0 Group Policy Object Permissions")
    {
        $NewerCSV = Import-CSV $NewerFile
        $OlderCSV = Import-CSV $OlderFile
    } else {
        $NewerCSV = Get-Content $NewerFile -Encoding Unicode
        $OlderCSV = Get-Content $OlderFile -Encoding Unicode
    }

    $dicNewRows = @{}
    $dicOldRows = @{}

    $dicAdds = @{}
    $dicDeletes = @{}

    foreach ($Row in $NewerCSV)
    {
        if ($Description -eq "Tier 0 Group Policy Object Permissions")
        {
            $Row2 = TransformGPORow $Row

            if ($dicNewRows.ContainsKey($Row2) -eq $false)
                {
                    $dicNewRows.Add($Row2,"")
                }

        } else {
            if ($dicNewRows.ContainsKey($Row) -eq $false)
                {
                    $dicNewRows.Add($Row,"")
                }
        }
    }

    foreach ($Row in $OlderCSV)
    {

        if ($Description -eq "Tier 0 Group Policy Object Permissions")
        {
            $Row2 = TransformGPORow $Row

            if ($dicOldRows.ContainsKey($Row2) -eq $false)
                {
                    $dicOldRows.Add($Row2,"")
                }

        } else {
            if ($dicOldRows.ContainsKey($Row) -eq $false)
            {
                $dicOldRows.Add($Row,"")
            }
        }
    }

    foreach ($Key2 in $dicNewRows.Keys)
    {

        if ($dicOldRows.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"Permission Added",'`
                        + $Key2

            Add-Content -Path $OutputFile -Value $LineOut -Encoding Unicode
            $LineOut2 = "Permission Added: $Key2`r`n`r`n"
            if ($dicAdds.ContainsKey($LineOut2) -eq $false)
            {
                $dicAdds.Add($LineOut2,"")
            }

        }
    }

    foreach ($Key2 in $dicOldRows.Keys)
    {

        if ($dicNewRows.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"Permission Deleted",'`
                        + $Key2

            Add-Content -Path $OutputFile -Value $LineOut -Encoding Unicode
            $LineOut2 = "Permission Removed: $Key2`r`n`r`n"
            if ($dicDeletes.ContainsKey($LineOut2) -eq $false)
            {
                $dicDeletes.Add($LineOut2,"")
            }
        }
    }
    $DescriptionOut = [string]$Description
    
    $AddMessage = $DescriptionOut + " have been added:`r`n`r`n"
    $DeleteMessage = $DescriptionOut + " have been removed: `r`n`r`n"


    $Counter=0
    foreach ($Line in $dicAdds.Keys)
    {
        $Counter=$Counter+1
        if ($Counter -lt 26)
        {
            $AddMessage = $AddMessage + $Line
        } else {
            if ($Counter -eq 26)
            {
                $AddMessage = "This event has been truncated.  Please see $OutputFile for full results.`r`n`r`n" + $AddMessage
                WriteEvent $AddEventID $AddMessage "Warning"    
            }
            $Counter=$Counter + 1
        }
    }
    if ($Counter -gt 0 -and $Counter -lt 26)
    {
        WriteEvent $AddEventID $AddMessage "Warning"     
    }

    $Counter=0
    foreach ($Line in $dicDeletes.Keys)
    {
        $Counter=$Counter+1
        if ($Counter -lt 26)
        {
            $DeleteMessage = $DeleteMessage + $Line
        } else {
            if ($Counter -eq 26)
            {
                $DeleteMessage = "This event has been truncated.  Please see $OutputFile for full results.`r`n`r`n" + $DeleteMessage
                WriteEvent $DeleteEventID $DeleteMessage "Information"    
            }
            $Counter=$Counter + 1
        }
    }
    if ($Counter -gt 0 -and $Counter -lt 26)
    {
        WriteEvent $DeleteEventID $DeleteMessage "Information"    
    }

}

####################################
### Monitor Non-Tier0 AdminCount ###
####################################
Function MonitorNonTier0AdminCount
{
    param (
        $Tier0PermissionsFiles,
        $OutputFile,
        $Description,
        $AddEventID,
        $DeleteEventID
    )

    $OlderFile = $Tier0PermissionsFiles[0]
    $NewerFile = $Tier0PermissionsFiles[1]
    Write-host "Comparing Newer File: $NewerFile to Older File: $OlderFile."

    $NewerCSV = Import-CSV $NewerFile
    $OlderCSV = Import-CSV $OlderFile

    $dicNewRows = @{}
    $dicOldRows = @{}

    $dicAdds = @{}
    $dicDeletes = @{}

    foreach ($Row in $NewerCSV)
    {
        $DistinguishedName = $Row.DistinguishedName
        $Domain = $Row.Domain
        $ObjectClass = $Row.ObjectClass
        $AdminCount = $Row.AdminCount
        $ObjectSID = $Row.ObjectSID
        $Reason = $Row.Reason

        $Key = '"' + $DistinguishedName + '",'`
                + '"' + $Domain + '",'`
                + '"' + $ObjectClass + '",'`
                + '"' + $AdminCount + '",'`
                + '"' + $ObjectSID + '",'`
                + '"' + $Reason + '"'

        if ($dicNewRows.ContainsKey($Key) -eq $false)
        {
            $dicNewRows.Add($Key,"")
        }
    }

    foreach ($Row in $OlderCSV)
    {
        $DistinguishedName = $Row.DistinguishedName
        $Domain = $Row.Domain
        $ObjectClass = $Row.ObjectClass
        $AdminCount = $Row.AdminCount
        $ObjectSID = $Row.ObjectSID
        $Reason = $Row.Reason

        $Key = '"' + $DistinguishedName + '",'`
                + '"' + $Domain + '",'`
                + '"' + $ObjectClass + '",'`
                + '"' + $AdminCount + '",'`
                + '"' + $ObjectSID + '",'`
                + '"' + $Reason + '"'

        if ($dicOldRows.ContainsKey($Key) -eq $false)
        {
            $dicOldRows.Add($Key,"")
        }
    }

    foreach ($Key2 in $dicNewRows.Keys)
    {

        if ($dicOldRows.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"Permission Added",'`
                        + $Key2

            Add-Content -Path $OutputFile -Value $LineOut -Encoding Unicode
            $LineOut2 = "Permission Added: $Key2`r`n`r`n"
            if ($dicAdds.ContainsKey($LineOut2) -eq $false)
            {
                $dicAdds.Add($LineOut2,"")
            }

        }
    }

    foreach ($Key2 in $dicOldRows.Keys)
    {

        if ($dicNewRows.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"Permission Deleted",'`
                        + $Key2

            Add-Content -Path $OutputFile -Value $LineOut -Encoding Unicode
            $LineOut2 = "Permission Removed: $Key2`r`n`r`n"
            if ($dicDeletes.ContainsKey($LineOut2) -eq $false)
            {
                $dicDeletes.Add($LineOut2,"")
            }
        }
    }
    $DescriptionOut = [string]$Description
    
    $AddMessage = $DescriptionOut + " have been added:`r`n`r`n"
    $DeleteMessage = $DescriptionOut + " have been removed: `r`n`r`n"

    $Counter=0
    foreach ($Line in $dicAdds.Keys)
    {
        $Counter=$Counter+1
        if ($Counter -lt 26)
        {
            $AddMessage = $AddMessage + $Line
        } else {
            if ($Counter -eq 26)
            {
                $AddMessage = "This event has been truncated.  Please see $OutputFile for full results.`r`n`r`n" + $AddMessage
                WriteEvent $AddEventID $AddMessage "Warning"    
            }
            $Counter=$Counter + 1
        }
    }
    if ($Counter -gt 0 -and $Counter -lt 26)
    {
        WriteEvent $AddEventID $AddMessage "Warning"     
    }


    $Counter=0
    foreach ($Line in $dicDeletes.Keys)
    {
        $Counter=$Counter+1
        if ($Counter -lt 26)
        {
            $DeleteMessage = $DeleteMessage + $Line
        } else {
            if ($Counter -eq 26)
            {
                $DeleteMessage = "This event has been truncated.  Please see $OutputFile for full results.`r`n`r`n" + $DeleteMessage
                WriteEvent $DeleteEventID $DeleteMessage "Information"    
            }
            $Counter=$Counter + 1
        }
    }
    if ($Counter -gt 0 -and $Counter -lt 26)
    {
        WriteEvent $DeleteEventID $DeleteMessage "Information"    
    }

}

################################
### Monitor Tier0 SidHistory ###
################################
Function MonitorTier0SidHistory
{
    param (
        $Tier0PermissionsFiles,
        $OutputFile,
        $Description,
        $AddEventID,
        $DeleteEventID
    )

    $OlderFile = $Tier0PermissionsFiles[0]
    $NewerFile = $Tier0PermissionsFiles[1]
    Write-host "Comparing Newer File: $NewerFile to Older File: $OlderFile."

    $NewerCSV = Import-CSV $NewerFile
    $OlderCSV = Import-CSV $OlderFile

    $dicNewRows = @{}
    $dicOldRows = @{}

    $dicAdds = @{}
    $dicDeletes = @{}

    foreach ($Row in $NewerCSV)
    {
        $DistinguishedName = $Row.DistinguishedName
        $Domain = $Row.Domain
        $ObjectClass = $Row.ObjectClass
        $SIDHistory = $Row.SIDHistory
        $RIDFound = $Row.RIDFound
        $Tier0Object = $Row.Tier0Object
        $Reason = $Row.Reason

        $Key = '"' + $DistinguishedName + '",'`
                + '"' + $Domain + '",'`
                + '"' + $ObjectClass + '",'`
                + '"' + $SIDHistory + '",'`
                + '"' + $RIDFound + '",'`
                + '"' + $Tier0Object + '",'`
                + '"' + $Reason + '"'

        if ($dicNewRows.ContainsKey($Key) -eq $false)
        {
            $dicNewRows.Add($Key,"")
        }
    }

    foreach ($Row in $OlderCSV)
    {
        $DistinguishedName = $Row.DistinguishedName
        $Domain = $Row.Domain
        $ObjectClass = $Row.ObjectClass
        $SIDHistory = $Row.SIDHistory
        $RIDFound = $Row.RIDFound
        $Tier0Object = $Row.Tier0Object
        $Reason = $Row.Reason

        $Key = '"' + $DistinguishedName + '",'`
                + '"' + $Domain + '",'`
                + '"' + $ObjectClass + '",'`
                + '"' + $SIDHistory + '",'`
                + '"' + $RIDFound + '",'`
                + '"' + $Tier0Object + '",'`
                + '"' + $Reason + '"'

        if ($dicOldRows.ContainsKey($Key) -eq $false)
        {
            $dicOldRows.Add($Key,"")
        }
    }

    foreach ($Key2 in $dicNewRows.Keys)
    {

        if ($dicOldRows.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"Permission Added",'`
                        + $Key2

            Add-Content -Path $OutputFile -Value $LineOut -Encoding Unicode
            $LineOut2 = "Permission Added: $Key2`r`n`r`n"
            if ($dicAdds.ContainsKey($LineOut2) -eq $false)
            {
                $dicAdds.Add($LineOut2,"")
            }

        }
    }

    foreach ($Key2 in $dicOldRows.Keys)
    {

        if ($dicNewRows.ContainsKey($Key2) -eq $false)
        {
            $LineOut = '"Permission Deleted",'`
                        + $Key2

            Add-Content -Path $OutputFile -Value $LineOut -Encoding Unicode
            $LineOut2 = "Permission Removed: $Key2`r`n`r`n"
            if ($dicDeletes.ContainsKey($LineOut2) -eq $false)
            {
                $dicDeletes.Add($LineOut2,"")
            }
        }
    }
    $DescriptionOut = [string]$Description
    
    $AddMessage = $DescriptionOut + " have been added:`r`n`r`n"
    $DeleteMessage = $DescriptionOut + " have been removed: `r`n`r`n"

    $Counter=0
    foreach ($Line in $dicAdds.Keys)
    {
        $Counter=$Counter+1
        if ($Counter -lt 26)
        {
            $AddMessage = $AddMessage + $Line
        } else {
            if ($Counter -eq 26)
            {
                $AddMessage = "This event has been truncated.  Please see $OutputFile for full results.`r`n`r`n" + $AddMessage
                WriteEvent $AddEventID $AddMessage "Warning"    
            }
            $Counter=$Counter + 1
        }
    }
    if ($Counter -gt 0 -and $Counter -lt 26)
    {
        WriteEvent $AddEventID $AddMessage "Warning"     
    }


    $Counter=0
    foreach ($Line in $dicDeletes.Keys)
    {
        $Counter=$Counter+1
        if ($Counter -lt 26)
        {
            $DeleteMessage = $DeleteMessage + $Line
        } else {
            if ($Counter -eq 26)
            {
                $DeleteMessage = "This event has been truncated.  Please see $OutputFile for full results.`r`n`r`n" + $DeleteMessage
                WriteEvent $DeleteEventID $DeleteMessage "Information"    
            }
            $Counter=$Counter + 1
        }
    }
    if ($Counter -gt 0 -and $Counter -lt 26)
    {
        WriteEvent $DeleteEventID $DeleteMessage "Information"    
    }

}

MonitorTier0Permissions $Tier0AdminSDHolderFiles $Tier0AdminSDHolderComparison 'Admin SD Holder Permissions' 20247 20248
MonitorTier0Permissions $Tier0ConfigurationFiles $Tier0ConfigurationComparison 'Configuration Naming Context Permissions' 20249 20250
MonitorTier0Permissions $Tier0ContainerFiles $Tier0ContainerComparison 'Tier 0 Container Permissions' 20251 20252
MonitorTier0Permissions $Tier0DomainRootFiles $Tier0DomainRootComparison 'Domain Root Permissions' 20253 20254
MonitorTier0Permissions $Tier0GPOFiles $Tier0GPOComparison 'Tier 0 Group Policy Object Permissions' 20255 20256
MonitorTier0Permissions $Tier0SchemaFiles $Tier0SchemaComparison 'Schema Naming Context Permissions' 20257 20258
MonitorTier0Permissions $Tier0SecurityPrincipalFiles $Tier0SecurityPrincipalComparison 'Tier 0 Security Principal Permissions' 20259 20260

MonitorTier0Permissions $Tier0RegistryFiles $Tier0RegistryComparison 'Tier 0 Registry Permissions' 20261 20262
MonitorTier0Permissions $Tier0ShareFiles $Tier0ShareComparison 'Tier 0 Share Permissions' 20263 20264
MonitorTier0Permissions $Tier0TrustRelationshipFiles $Tier0TrustRelationshipComparison 'Trust Relationships' 20265 20266

MonitorNonTier0AdminCount $NonTier0AdminCountFiles $NonTier0AdminCountComparison 'Non-Tier 0 AdminCount' 20267 20268

MonitorTier0SidHistory $Tier0SidHistoryFiles $Tier0SidHistoryComparison 'Tier 0 Sid History' 20269 20270


# SIG # Begin signature block
# MIIoOwYJKoZIhvcNAQcCoIIoLDCCKCgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDEtEM5lgbmsZDZ
# J74EzkaurUJDb7A8T15Ehi9R3sjoVKCCDYUwggYDMIID66ADAgECAhMzAAAEhJji
# EuB4ozFdAAAAAASEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM1WhcNMjYwNjE3MTgyMTM1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDtekqMKDnzfsyc1T1QpHfFtr+rkir8ldzLPKmMXbRDouVXAsvBfd6E82tPj4Yz
# aSluGDQoX3NpMKooKeVFjjNRq37yyT/h1QTLMB8dpmsZ/70UM+U/sYxvt1PWWxLj
# MNIXqzB8PjG6i7H2YFgk4YOhfGSekvnzW13dLAtfjD0wiwREPvCNlilRz7XoFde5
# KO01eFiWeteh48qUOqUaAkIznC4XB3sFd1LWUmupXHK05QfJSmnei9qZJBYTt8Zh
# ArGDh7nQn+Y1jOA3oBiCUJ4n1CMaWdDhrgdMuu026oWAbfC3prqkUn8LWp28H+2S
# LetNG5KQZZwvy3Zcn7+PQGl5AgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUBN/0b6Fh6nMdE4FAxYG9kWCpbYUw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwNTM2MjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGLQps1XU4RTcoDIDLP6QG3NnRE3p/WSMp61Cs8Z+JUv3xJWGtBzYmCINmHVFv6i
# 8pYF/e79FNK6P1oKjduxqHSicBdg8Mj0k8kDFA/0eU26bPBRQUIaiWrhsDOrXWdL
# m7Zmu516oQoUWcINs4jBfjDEVV4bmgQYfe+4/MUJwQJ9h6mfE+kcCP4HlP4ChIQB
# UHoSymakcTBvZw+Qst7sbdt5KnQKkSEN01CzPG1awClCI6zLKf/vKIwnqHw/+Wvc
# Ar7gwKlWNmLwTNi807r9rWsXQep1Q8YMkIuGmZ0a1qCd3GuOkSRznz2/0ojeZVYh
# ZyohCQi1Bs+xfRkv/fy0HfV3mNyO22dFUvHzBZgqE5FbGjmUnrSr1x8lCrK+s4A+
# bOGp2IejOphWoZEPGOco/HEznZ5Lk6w6W+E2Jy3PHoFE0Y8TtkSE4/80Y2lBJhLj
# 27d8ueJ8IdQhSpL/WzTjjnuYH7Dx5o9pWdIGSaFNYuSqOYxrVW7N4AEQVRDZeqDc
# fqPG3O6r5SNsxXbd71DCIQURtUKss53ON+vrlV0rjiKBIdwvMNLQ9zK0jy77owDy
# XXoYkQxakN2uFIBO1UNAvCYXjs4rw3SRmBX9qiZ5ENxcn/pLMkiyb68QdwHUXz+1
# fI6ea3/jjpNPz6Dlc/RMcXIWeMMkhup/XEbwu73U+uz/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAASEmOIS4HijMV0AAAAA
# BIQwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPnL
# m3N6Fvz1a9jkoGoa9FKnNpKhWbT7tTZ/UGkIYG9aMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAIc2WpWGnr1Lsy+PKgm9/dtiKOGtUK6StgDK5
# tbDCbaG3HhFOHZ/Fhf3taM185/2sv2IGnEt44ccz4b2P9MOaEaK9kREnA/Y3z+W4
# dmHyqbpcpKDoB9ME5oMqLvQBYYLv0UhcKWanO2oShPlcqbm2l4MsZeBG44PflLCF
# m2TZpQqYm5Yc3rOGTUHYkYkgOm0s5DXPVgvRZo3Aqz0gspL3QJac8IwK61FmG+rp
# vPwRb1xZONg3dCGTXfqXfZNhA5MsE/brbaJR96ivNeW4TwLUpIduxRIuYodB4r54
# Un1S8vecvt2tJ51oN5Usm5nJ28hd8lJ61rr3WxZFcD/eC1DyZaGCF5YwgheSBgor
# BgEEAYI3AwMBMYIXgjCCF34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCBzljaFNPLzUTF4IkFiP5C1rquP/V4xp/BI
# BtS4LlBouAIGaFuGatfYGBIyMDI1MDcyOTE4Mjc0My43OVowBIACAfSggdGkgc4w
# gcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsT
# HE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQg
# VFNTIEVTTjo5NjAwLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCEe0wggcgMIIFCKADAgECAhMzAAACBNjgDgeXMliYAAEA
# AAIEMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTI1MDEzMDE5NDI0N1oXDTI2MDQyMjE5NDI0N1owgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo5NjAwLTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAPDdJtx57Z3rq+RYZMheF8aq
# qBAbFBdOerjheVS83MVK3sQu07gH3f2PBkVfsOtG3/h+nMY2QV0alzsQvlLzqopi
# /frR5eNb58i/WUCoMPfV3+nwCL38BnPwz3nOjSsOkrZyzP1YDJH0W1QPHnZU6z2o
# /f+mCke+BS8Pyzr/co0hPOazxALW0ndMzDVxGf0JmBUhjPDaIP9m85bSxsX8NF2A
# zxR23GMUgpNdNoj9smGxCB7dPBrIpDaPzlFp8UVUJHn8KFqmSsFBYbA0Vo/OmZg3
# jqY+I69TGuIhIL2dD8asNdQlbMsOZyGuavZtoAEl6+/DfVRiVOUtljrNSaOSBpF+
# mjN34aWr1NjYTcOCWvo+1MQqA+7aEzq/w2JTmdO/GEOfF2Zx/xQ3uCh5WUQtds6b
# uPzLDXEz0jLJC5QxaSisFo3/mv2DiW9iQyiFFcRgHS0xo4+3QWZmZAwsEWk1FWdc
# FNriFpe+fVp0qu9PPxWV+cfGQfquID+HYCWphaG/RhQuwRwedoNaCoDb2vL6MfT3
# sykn8UcYfGT532QfYvlok+kBi42Yw08HsUNM9YDHsCmOv8nkyFTHSLTuBXZusBn0
# n1EeL58w9tL5CbgCicLmI5OP50oK21VGz6Moq47rcIvCqWWO+dQKa5Jq85fnghc6
# 0pwVmR8N05ntwTgOKg/VAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUGnV2S0Bwalb8
# qbqqb6+7gzUZol8wHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBAF5y/qxHDYdMszJQ
# LVYkn4VH4OAD0mS/SUawi3jLr0KY6PxHregVuFKZx2lqTGo1uvy/13JNvhEPI2q2
# iGKJdu2teZArlfvL9D74XTMyi1O1OlM+8bd6W3JX8u87Xmasug1DtbhUfnxou3Tf
# S05HGzxWcBBAXkGZBAw65r4RCAfh/UXi4XquXcQLXskFInTCMdJ5r+fRZiIc9HSq
# TP81EB/yVJRRXSBsgxrAYiOfv5ErIKv7yXXF02Qr8XRRi5feEbScT71ZzQvgD96e
# W5Q3s9r285XpWLcE4lJPRFj9rHuJnjmV4zySoLDsEU9xMiRbPGmOvacK2KueTDs4
# FDoU2DAi4C9g1NTuvrRbjbVgU4vmlOwxlw0M46wDTXG/vKYIXrOScwalEe7DRFvY
# EAkL2q5TsJdZsxsAkt1npcg0pquJKYJff8wt3Nxblc7JwrRCGhE1F/hapdGyEQFp
# jbKYm8c7jyhJJj+Sm5i8FLeWMAC4s3tGnyNZLu33XqloZ4Tumuas/0UmyjLUsUqY
# Wdb6+DjcA2EHK4ARer0JrLmjsrYfk0WdHnCP9ItErArWLJRf3bqLVMS+ISICH89X
# IlsAPiSiKmKDbyn/ocO6Jg5nTBSSb9rlbyisiOg51TdewniLTwJ82nkjvcKy8HlA
# 9gxwukX007/Uu+hADDdQ90vnkzkdMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCA1AwggI4AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0wNUUw
# LUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoB
# ATAHBgUrDgMCGgMVALo9gdHD371If7WnDLqrNUbeT2VuoIGDMIGApH4wfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDsM32VMCIY
# DzIwMjUwNzI5MTcwNDIxWhgPMjAyNTA3MzAxNzA0MjFaMHcwPQYKKwYBBAGEWQoE
# ATEvMC0wCgIFAOwzfZUCAQAwCgIBAAICDasCAf8wBwIBAAICEk4wCgIFAOw0zxUC
# AQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEK
# MAgCAQACAwGGoDANBgkqhkiG9w0BAQsFAAOCAQEAGKWyTIstbh8GgKFjA/QEFHgH
# zDwU7xPpT8OtoXigwrUdciptKZfHisQhQVACSAqcLFnA3a/PbNZ7TCyKNMO6r0Zg
# LFJDFYgNUUPciBQht8PKk3VBGlfasJgnukW64d4hYXnCoQ5SttVetaUg2P5Lfrox
# si6ALxaygkv9Cqnx56LnpXbygUo79M6FHIiDCnlSb8m6+NoAchqY2w1Q8m1VnQMp
# 8BQLcSFNxjQLWsWNYYlkscSDBKD/qWgT0StNUe/o6PePwkM5eXrlplvuU+uy05HG
# b4faDQnFPmVDzkJm35zDcFvH/CuNOLPEs1D4MnT9wlFgBzc225NGyEiKJShNBDGC
# BA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAC
# BNjgDgeXMliYAAEAAAIEMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMx
# DQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEICt2aYI93iSw7cmyBBPO1JFi
# x8tjWnn4pJIN55vJIKnDMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg+e14
# Zf1bCrxV0kzqaN/HUYQmy7v/qRTqXRJLmtx5uf4wgZgwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgTY4A4HlzJYmAABAAACBDAiBCCH9+SI
# D0SjdeeCUBgN+HKO8bIJu1sJODLpCrTk8i4AtTANBgkqhkiG9w0BAQsFAASCAgDr
# YdyjJzGM88Ifn9ih6m3t4l0W5iY3os79RkUaimfuSJAy9OyUtbuxZzcwrnvxsiJE
# 0vjEtGiM5Qdz3XbRSwR327+INI+3KhJ4gGo6ClOdW38qwaoM3DuTpEEW2c4SaWjM
# LPskFUyy4V2edUJh8rL9bkctpyDtEe2a7h5TtXPsANPzxX6d8U2uO7qXk7X6Lp6c
# cqL7dIFi/rMjTUSy72/9Hb6jNPNZ4NdInU8vw2qXzGFejUzePTvM5uza6rzc5pkH
# xm3Lt7E+xv1hfIgTMOXZoSn8BgaSEoH2xKyo6HTFa6q3OK7C5HHHzCP1xneGv4lj
# TGCYsNFtiPRws+UbwUZs5OCz3Wy1Inp4ePtlrrC76VrK50hbGdQbErDHxxbd+NZ6
# OdKAEPiVtE9/+GVipoepPd2bs9rLbHYm+Gqv5JPTaqD19YU9Xjm4+OW52bFgZ11C
# GZY7ieZLQVLFugLztkahArNuT+UQjXOPcpkuW/kt0/D+KyIH0vhLKRdQNM7XJpeU
# VohbbhI1Dj8e0G2xmeOnKiJKfftrutPzr6+dXmuL1Y2f3cdTlFLe+d0qY5Mk+3IM
# MBJOYOA3BtNbahnnKWuiNkcmL2StJStq9RXIt0vswDeGoWc32TdG4vWfppU1zWzp
# 7svIllWT+xpkQi6UIc09bW+5ZSxDeA7+gHJeWrFKKA==
# SIG # End signature block
