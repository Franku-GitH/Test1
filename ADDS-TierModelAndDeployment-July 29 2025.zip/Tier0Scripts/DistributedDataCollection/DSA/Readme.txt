Delta Security Assessment Usage
===============================


Capturing on the assessed server:

.\DeltaSecurityAssessment.ps1 -capture -deltaLocation "C:\Source\DSA\Captures"


Creating the GPO delta in Active Directory:

For Windows Server 2012 assessments, use -

.\DeltaSecurityAssessment.ps1 -create -deltaLocation "C:\Source\DSA\Captures" -osversion 2012R2 -servername COMPUTERNAME -gponame COMPUTERNAME

For Windows Server 2016 assessments, use -

.\DeltaSecurityAssessment.ps1 -create -deltaLocation "C:\Source\DSA\Captures" -osversion 2016 -servername COMPUTERNAME -gponame COMPUTERNAME
