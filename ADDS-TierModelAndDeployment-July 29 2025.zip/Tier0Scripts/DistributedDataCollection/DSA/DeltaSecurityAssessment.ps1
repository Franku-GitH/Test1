﻿<#
    .COPYRIGHT

     Copyright (c) Microsoft. All Rights Reserved.
     Information Contained Herein is Proprietary and Confidential.
     Microsoft makes no warranties, express or implied.
     This code can only be used if authorized by Microsoft.   
    
    .SYNOPSIS
        Perform Security Assessment and gather the required information that will assist in the 
        creation of server role security and firewall delta policies. Build Server Role Security 
        and Firewall Delta Policies

    .DESCRIPTION
        Captures information from the target machine relating to security settings such as server
        user right assingments and firewall settings to assist in building a server role security
        policy.
        
    ===============
    Version Control
    ===============
    Ver #: 2.0.2
    Modified By: Jason Jones
    Date Modified: 09/06/2015		
    Details: jason.jones@microsoft.com
    Modification Reason: Fix ICMP-based firewall rules bug	
    ===============
    Ver #: 2.0.3
    Modified By: Kieran Bhardwaj
    Date Modified: 27/10/2015		
    Details: kieran.bhardwaj@microsoft.com
    Modification Reason: Fix for incorrect matching on firewall rules.
    ===============
    Ver #:2.0.4
    Modified by James Noyce
    Date Modified: 24/05/2017
    Details: james.noyce@microsoft.com
    Modification reason: Fix issue when local group membership not captured correctly when only one group or user was added to the local group
    ===============
    Ver #:2.0.5
    Modified by James Noyce
    Date Modified: 07/02/2018
    Details: james.noyce@microsoft.com
    Modification reason: Added support for Windows Server 2016
    ===============
    Ver #:2.0.6
    Modified by Jason Jones
    Date Modified: 12/02/2018
    Details: jason.jones@microsoft.com
    Modification reason: Added exclusion for Per-User Services in Windows Server 2016
    ===============
    Ver #:2.0.7
    Modified by Jason Jones
    Date Modified: 17/07/2018
    Details: jason.jones@microsoft.com
    Modification reason: Fixed 2016-ProcessRules.zxml due to missing User Rights Assignments
    ===============

    End Version Control
#>
<#
    To Do List:
    1) Add in check that XML file is valid into pre-req check

    Notes:
    1) If a service is set to auto in the baseline but manual on a machine - then it is not captured as the auto setting in the baseline will suffice

#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string]$deltaLocation,

    [Parameter(ParameterSetName="capture", Mandatory=$false)]
    [switch]$capture,

    [Parameter(ParameterSetName="create", Mandatory=$false)]
    [switch]$createDelta,

    [Parameter(ParameterSetName="create", Mandatory=$true)]
    [validateset("2012R2","2016")][string]$osversion,

    [Parameter(ParameterSetName="create", Mandatory=$true)]
    [string]$servername,

    [Parameter(ParameterSetName="create", Mandatory=$FALSE)]
    [string]$gpoName
)
$Global:Version = "2.0.7"

######################################################################################################################
# Utility Functions
######################################################################################################################

Function Start-Log
{
<#
    .SYNOPSIS
    Start script logging
    .DESCRIPTION
    Checks and if necessary creates a log directory and starts a date/time stamped log file
#>
    # Get the date/time so we can use this to tag output file names.
    $dateTime=get-date -format s
    $dateTime=$dateTime -replace ":","_"
    $dateTime=$dateTime.ToString()

    $path = $PSScriptRoot + "\Logs"
    If(!(Test-Path ($path))){
        Write-Host ("Creating directory " + $path + ".") -ForegroundColor Cyan
        New-Item -ItemType Directory ($path) | Out-Null
    }

    if($capture){
        $Script:logFile=$path + "\DeltaSecurityAssessment_capture_" + $dateTime + ".log"
    }elseif($createDelta){
        $Script:logFile=$path + "\DeltaSecurityAssessment_create_" + $dateTime + ".log"
    }else{
        $Script:logFile=$path + "\DeltaSecurityAssessment_" + $dateTime + ".log"
    }
    Log "INFO" ("Log File Name is " + $Script:logFile)
}

Function Write-Log($Msg)
{  
<#
    .SYNOPSIS
    Write messages to the log file
    .DESCRIPTION
    Write a message to the global log file including a timestamp
    .PARAMETER Msg
    Message to be written to log file
#>

    $date = Get-Date -format dd.MM.yyyy  
    $time = Get-Date -format HH:mm:ss  
    Add-Content -Path $Script:LogFile -Value ($date + " " + $time + "   " + $Msg)  
}

Function Log($type, $text)
{
<#
    .SYNOPSIS
    Handles errors and information messages
    .DESCRIPTION
    Write a message to the logging locations and to the user screen.
    .PARAMETER type
    If the message is error (ERR) or information (INFO) or success (SUCC)
    .PARAMETER text
    Message text
#>

    # If error use red text
    if($type -eq "ERR"){
        $msg = "Error: " + $text
        Write-Log $msg
        Write-Host -ForegroundColor Red $msg
    }

    # If info use blue text
    if($type -eq "INFO"){
        $msg = "Information: " + $text
        Write-Log $msg
        Write-Host -ForegroundColor Cyan $msg
    }

    # If success use green text
    if($type -eq "SUCC"){
        $msg = "Success: " + $text
        Write-Log $msg
        Write-Host -ForegroundColor Green $msg
    }
}

Function Load-Module($name)
{
<#
    .SYNOPSIS
    Loads a system module
    .DESCRIPTION
    Checks a module exists and then loads it into the PowerShell environment
    .PARAMETER name
    The name of the module to be loaded
#>

    $result = $true

    If(Get-Module -ListAvailable | Where-Object { $_.name -eq $name }) { 
        Import-Module -Name $name 
    }else{
        $result =  $false 
    }  

    return $result
}

Function isElevated
{
    $result = $true 

    $wid = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $prp = New-Object System.Security.Principal.WindowsPrincipal($wid)
    $role = [System.Security.Principal.WindowsBuiltInRole]::Administrator
    $isInRole = $prp.IsInRole($role)
    If (!($isInRole))
    {
       $result = $false
    }
    
    return $result
}

######################################################################################################################
# Start and Finish
######################################################################################################################
Function PreReqPrep
{
<#
    .SYNOPSIS
    Check script pre-requistes and parses XML file.
    .DESCRIPTION
    Ensure all pre-requistes exist and that the XML file contains all required information
#>
    $result = $true
    Set-Location $PSScriptRoot

    $wid = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    Log "INFO" "Checking if current user, " + $wid.Name + ", is running elevated."
    if(isElevated){
        Log "SUCC" ("Current user, " + $wid.Name + ", is running elevated.")
    }else{
        Log "ERR" ("Current user, " + $wid.Name + ", is not running elevated. Run PowerShell as an Administrator and retry...")
        $result = $false
    }

    # Set variables for script
    $ErrorActionPreference= 'silentlycontinue'
    $Script:Domain = Get-ADDomain 
    $Script:strDomainDN = $Script:Domain.DistinguishedName
    
    # Set location for delta files
    if(($deltaLocation -eq "") -or ($deltaLocation -eq ".")){
        # Create capture location
        $path = $PSScriptRoot + "\Captures"
        Log "INFO" ("No delta location provided, using default location " + $path + "\" + $env:COMPUTERNAME + ".")
        If(!(Test-Path ($path))){
            Log "INFO" ("Creating directory " + $path + ".")
            New-Item -ItemType Directory ($path) | Out-Null
        }
        $Script:DeltaLoc = $path      
    }else{
        # Create capture location 
        $path = $deltaLocation
        If(!(Test-Path ($path))){
            Log "ERR" ("Provided delta location " + $path + " is not valid.")
            $path = $PSScriptRoot + "\Captures"
            Log "INFO" ("Using default location " + $path + "\" + $env:COMPUTERNAME + ".")
            New-Item -ItemType Directory ($path) | Out-Null
        }
        $Script:DeltaLoc = $path
    }

    if($capture){
        $Script:DeltaLoc = $Script:DeltaLoc + "\" + $env:COMPUTERNAME
        If(!(Test-Path ($Script:DeltaLoc))){
            Log "INFO" ("Creating directory " + $Script:DeltaLoc + ".")
            New-Item -ItemType Directory ($Script:DeltaLoc) | Out-Null
        }
    }

    # Check files exist if needed for capture
    if($createDelta){
        $Script:DeltaLoc = $Script:DeltaLoc + "\" + $servername
        If ((Test-Path $Script:DeltaLoc) -ne $True) 
        {
            Log "ERR" ("The folder specified " + $Script:DeltaLoc + " does not exist. Unable to find scan results")
            $result = $false
        }

        # Check the folder contains gathered files
        If ((Test-Path ($Script:DeltaLoc + "\" + $servername + "_userrights.xml")) -ne $True) 
        {
            Log "ERR" ("The folder specified does not contain files to match servername " + $serverName + ". Unable to find scan results")
            $result = $false
        }

        # Create temp working directory
        $Script:TempPath = ($PSScriptRoot + "\Output")
        If(!(Test-Path ($Script:TempPath))){
            Log "INFO" ("Creating directory " + $Script:TempPath + ".")
            New-Item -ItemType Directory ($Script:TempPath) -ErrorAction SilentlyContinue | Out-Null
        }
        
        If($osversion -eq "2012R2"){
        Log "INFO" ("Importing processing rules for Windows Server 2012R2")
        $Script:processingRulesXML = [xml](Get-content ($PSScriptRoot + "\XML\2012R2-ProcessRules.xml"))
        }
        
        If($osversion -eq "2016"){
        Log "INFO" ("Importing processing rules for Windows Server 2016")
        $Script:processingRulesXML = [xml](Get-content ($PSScriptRoot + "\XML\2016-ProcessRules.xml"))
        }

        #Import the Processing Rules XML
        #$Script:processingRulesXML = [xml](Get-content ($PSScriptRoot + "\XML\ProcessRules.xml"))
        #$Script:Cleanup = $Script:processingRulesXML.ProcessingRules.Global.Cleanup
    }

    return $result
}

Function Cleanup
{
<#
    .SYNOPSIS
    Cleans up any items used by the script
    .DESCRIPTION
    Removed unnecessary files or objects created temporarily by the script and then closes script
#>
    if($Script:Cleanup -eq $true){
        if(Test-Path -path $Script:TempPath){
            Remove-Item -path $Script:TempPath -Force -Recurse
        }
    }

    Exit
}

######################################################################################################################
# Capture Functions
######################################################################################################################

Function CaptureLocalUserRights 
{
#       
#      .DESCRIPTION  
#          Collects the locally configured User Rights Assignments by exporting the configuration using SECEDIT
#          and then converting the SIDs to User/Group/Computer names. The configuration is then saved in the XML format
#  

    Set-Content $userRightsXML "<?xml version='1.0' encoding='Unicode'?>" -Encoding Unicode
    Add-Content $userRightsXML "<UserRights>" -Encoding Unicode
    Add-Content $userRightsXML "</UserRights>" -Encoding Unicode

    $secEditCmd = ("/export /cfg " + [char]34 + $userRightsTemp + [char]34 + " /areas USER_RIGHTS")

    Write-Log ("INFORMATION: Running SECEDIT with the following parameters: " + $secEditCmd)

    Start-Process -Wait -WindowStyle Hidden -FilePath "C:\Windows\System32\secedit.exe" -ArgumentList $secEditCmd

    $exportedLocalRights = Get-Content($userRightsTemp)

    #$xml = [xml](Get-Content $userRightsRef)
    $xml2 = [xml](Get-Content $userRightsXML)
            
        foreach ($line in $exportedLocaLRights) 
        {

            If (($line.Substring(0,2)) -eq "Se")
            {
                                        
                $UserRight= $line.split("=")
                $userRightShortName = $userRight[0].TrimEnd()
               
                #$UserRightCaption = $xml.UserRights.Policy | where {$_.name -eq $userRightShortName}
                
               
                if(!($xml2.UserRights.Policy | where {$_.name -eq $UserRightShortName})) 
                {

                    $newUserRightElement = $xml2.CreateElement("Policy")
                    $newUserRightElement.SetAttribute("name", $userRightShortName)
                    #$newUserRightElement.SetAttribute("caption", $userRightCaption.Caption)
                    $xml2["UserRights"].AppendChild($newUserRightElement)| Out-Null

                }
                
                $xmlUserRight = $xml2.UserRights.Policy | where {$_.name -eq $UserRightShortName}


                    Foreach ($accountList in $UserRight[1])
                    {                                                                                                                                               
                       
                     $accounts = $accountList.split(",")
                               
                        Foreach ($account in $accounts) 
                        {

                            $accountString = $account.replace("*","")
                            $accountString = $accountString.TrimStart()

                               If (($accountString.Substring(0,2)) -eq "S-") 
                               {

                                    $objSID = New-Object System.Security.Principal.SecurityIdentifier($accountString) 
                                    try
                                    {
                                        $objUser = $objSID.Translate( [System.Security.Principal.NTAccount]) 
                                    } catch {
                                        $objUser = $accountString
                                    }
                                    $newAccountElement = $xml2.CreateElement("Account")
                                    $newAccountElement.SetAttribute("name", $objUser)
                                    $xmlUserRight.AppendChild($newAccountElement) | Out-Null
        
                                }
                        }

                    }
            }

    

    }

$xml2.Save($userRightsXML)

}

Function CaptureServices 
{
#       
#      .DESCRIPTION  
#          Export the local Services configuration to XML 
#  


    #Create content for XML dump of service configuration
    Set-Content $allServicesXML "<?xml version='1.0' encoding='Unicode'?>" -Encoding Unicode
    Add-Content $allServicesXML "<Services>" -Encoding Unicode
    Add-Content $allServicesXML "</Services>" -Encoding Unicode
    $xml = [xml](Get-Content $allServicesXML)

    #Create an array for the Service information
    $services = @();

    #Add the required properties from the WMI query to the array
    Get-WMIObject Win32_Service | % { 
    $myObject = New-Object System.Object;
    $myObject | Add-Member -Type NoteProperty -Name Name -Value $_.Name;
    $myObject | Add-Member -Type NoteProperty -Name State -Value $_.State;
    $myObject | Add-Member -Type NoteProperty -Name StartMode -Value $_.StartMode;
    $myObject | Add-Member -Type NoteProperty -Name Caption -Value $_.Caption;
    $services += $myObject}

    Foreach ($Service in $Services) {

                #Export local service configuration to XML
                if(!($xml.Services.Service | where {$_.name -eq $Service.name })) 
                {

                    $newServiceElement = $xml.CreateElement("Service")
                    $newServiceElement.SetAttribute("Name", $Service.name)
                    $newServiceElement.SetAttribute("Caption", $Service.caption)
                    $newServiceElement.SetAttribute("State", $Service.State)
                    $newServiceElement.SetAttribute("StartMode", $Service.StartMode)
                    $xml["Services"].AppendChild($newServiceElement) | Out-Null

                }
            
                $xml.Save($allServicesXML)

        

        }

}

Function RSOP
{
#       
#      .DESCRIPTION  
#         Export the RSOP in HTML format
# 

    $gpresultParams = ("/h " + "`"$rsopHTML`"")

    Start-Process -Wait -WindowStyle Hidden -FilePath "C:\windows\system32\gpresult.exe" -ArgumentList $gpresultParams
    
}

Function CaptureLocalUsersGroups
{
#       
#      .DESCRIPTION  
#         Export the local group membership information
# 

    Set-Content $localUsersAndGroupsXML "<?xml version='1.0' encoding='Unicode'?>" -Encoding Unicode
    Add-Content $localUsersAndGroupsXML "<Groups>" -Encoding Unicode
    Add-Content $localUsersAndGroupsXML "</Groups>" -Encoding Unicode
    $xml = [xml](Get-Content $localUsersAndGroupsXML)

        $localGroups = Get-WmiObject win32_group -Filter “LocalAccount=True”

    
    Foreach ($group in $localGroups)
    { 


    $strSID = $null
    $objGroup = New-Object System.Security.Principal.NTAccount($group.Name)
    $strSID = $objGroup.Translate([System.Security.Principal.SecurityIdentifier])

            if(!($xml.Groups.Group | where {$_.name -eq $group.name })) 
            {

                $newGroupElement = $xml.CreateElement("Group")
                $newGroupElement.SetAttribute("name", $group.name)
                $sidString = ([string]$strSID).Length
                If($sidString -le "12")
                {
                
                    $newGroupElement.SetAttribute("SID", $strSID)
                
                }
                $xml["Groups"].AppendChild($newGroupElement)| Out-Null

            }

            $xmlGroupName = $xml.Groups.Group | where {$_.name -eq $group.name }
        
            $query="GroupComponent = `"Win32_Group.Domain='" + $group.domain + "',NAME='" + $group.name + "'`""

            #$query="GroupComponent = `"Win32_Group.Domain='" + $group.domain + "',NAME='" + $group.name + "'`""


            $users = Get-wmiobject win32_groupuser -filter $query
            
            $GroupMembers = 1 #Get-wmiobject win32_group -filter $query

            $user = $null
            
       
            #If($USERS.COUNT -gt 0)

            #If(($USERS.COUNT) -or ($GroupMembers.COUNT) -gt 0)
            #{
                foreach ($user in $users) 
                { 
                   
                           
                    $user = $user.partcomponent
                    $groupMember = $null
                    $GroupMember = ($user.replace("Domain="," , ").replace(",Name=","\").replace("\\",",").replace('"','').split(","))[2] 
                    $strSID = $null
                
                    If($groupMember -match $env:COMPUTERNAME)
                    {

                        $groupMember = $groupMember -creplace '^[^\\]*\\', ''
                        $strSID = $null
                        $objUser = New-Object System.Security.Principal.NTAccount($GroupMember)
                        $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])

                    }
                    Else
                    {

                        $domain = ($GroupMember.Split("\"))[0].trim()
                        $user = ($GroupMember.Split("\"))[1]
                        $objUser = New-Object System.Security.Principal.NTAccount($domain,$user)
                        $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
                        $domainObject = $True
                    }

                    $newMemberElement = $xml.CreateElement("Member")
                    $newMemberElement.SetAttribute("name", $groupmember)
                    $sidString = ([string]$strSID).Length
                    If(($sidString -le "12") -or ($domainObject -eq $True))
                    {
                
                        $newMemberElement.SetAttribute("SID", $strSID)
                    
                    }
                    $xmlGroupName.AppendChild($newMemberElement)| Out-Null

                                                                       
         
                }
              #}

                

            }

        $xml.Save($localUsersAndGroupsXML)

}

Function netshFirewallExport
{
#       
#      .DESCRIPTION  
#         Export the local firewall in .wfw format using NETSH
#  

    $netshAdvFirewallParams = ("advfirewall export " + $netshExport)



    Start-Process -wait -WindowStyle hidden -FilePath "C:\Windows\System32\netsh.exe" -ArgumentList $netshAdvFirewallParams

}

Function Get-FireWallConfig
{
#       
#      .DESCRIPTION  
#         Export the local firewall rules to XML
#  
  

    Set-Content $firewallXML "<?xml version='1.0' encoding='Unicode'?>" -Encoding Unicode
    Add-Content $firewallXML "<Rules>" -Encoding Unicode
    Add-Content $firewallXML "</Rules>" -Encoding Unicode

    $xml = [xml](Get-Content $firewallXML)
     
    $Rules = Get-NetFirewallRule
    
    Foreach ($rule in $rules) {
               
                    $portFilters = Get-NetFirewallPortFilter | where {$_.instanceID -eq $rule.name}
                    $applicationFilters = Get-NetFirewallApplicationFilter | where {$_.instanceID -eq $rule.name}
                    $addressFilters = Get-NetFirewallAddressFilter  | where {$_.instanceID -eq $rule.name}
                    $serviceFilters = Get-NetFirewallServiceFilter  | where {$_.instanceID -eq $rule.name}
                
                    $newRuleElement = $xml.CreateElement("FirewallRule") 
                    $newRuleElement.SetAttribute("name", $rule.name)
                    $newRuleElement.SetAttribute("displayName", $rule.displayname)
                    $newRuleElement.SetAttribute("Description",$rule.Description)
                    $newRuleElement.SetAttribute("Program",$applicationFilters.program)
                    $newRuleElement.SetAttribute("Service",$serviceFilters.service)
                    $newRuleElement.SetAttribute("direction", $rule.direction)
                    $newRuleElement.SetAttribute("enabled", $rule.enabled)
                    $newRuleElement.SetAttribute("group", $rule.group)
                    $newRuleElement.SetAttribute("protocol", $portFilters.protocol)
                    $newRuleElement.SetAttribute("profile", $rule.profile)
                    $newRuleElement.SetAttribute("action", $rule.action)
                    $newRuleElement.SetAttribute("localPorts", $portFilters.localPort)
                    $newRuleElement.SetAttribute("remotePorts", $portFilters.remotePort)
                    $newRuleElement.SetAttribute("localAddress", $addressFilters.localAddress)
                    $newRuleElement.SetAttribute("remoteAddress", $addressFilters.remoteAddress)
                    $newRuleElement.SetAttribute("localIP", $addressFilters.localIP)
                    $newRuleElement.SetAttribute("remoteIP", $addressFilters.remoteIP)

                    #If this is an ICMP rule, we need the ICMPType too
                    If($rule.protocol -match "ICMP")
                    {
			
                        $newRuleElement.SetAttribute("ICMPType",$rule.ICMPType)

                    }
                    If($portfilters.localPort -is [array])
                    {
                        $newRuleElement.SetAttribute("localPorts",$portFilters.LocalPort -Join ",")

                    }

                    $xml["Rules"].AppendChild($newRuleElement) | Out-Null

                    $xml.save($firewallXML)
               
           }

}

Function ConvertAny($value)
{


    If($value)
    {

        If($value -eq "RPC-EPMap")
        {

            return "RPCEPMap"

        }
        Else
        {

            return $value

        }

    }

    Else
    {

        return "Any"

    }


}

Function Get-FirewallConfigLegacy()
{
#       
#      .DESCRIPTION  
#         Export the local firewall rules to XML for devices which do not have PowerShell v3.0 installed
#  


$profilesArray = @{1="Domain"; 2= "Private"; 4 = "Public"; 3 = "Private, Domain"; 5 = "Domain, Public"; 6 = "Private, Public"; 7 = "Domain, Private, Public"; 2147483647 = "Domain, Private, Public"}
$directionArray = @{1="Inbound";2="Outbound"}
$actionArray = @{1="Allow";2="Block"}

$rules = (New-Object -ComObject hnetcfg.fwpolicy2).rules


    Set-Content $firewallXML "<?xml version='1.0' encoding='Unicode'?>" -Encoding Unicode
    Add-Content $firewallXML "<Rules>" -Encoding Unicode
    Add-Content $firewallXML "</Rules>" -Encoding Unicode

    $xml = [xml](Get-Content $firewallXML)
  
    Foreach ($rule in $rules) {

                If ($rule.enabled -eq "true") {
                
                    $action  = $actionArray[$rule.action]
                    $direction = $directionArray[$rule.direction]
                    $profile = $profilesArray[$rule.profiles]
                    
                    $newRuleElement = $xml.CreateElement("FirewallRule") 
                    $newRuleElement.SetAttribute("name", $rule.name)
                    $newRuleElement.SetAttribute("displayName", $rule.name)
                    $newRuleElement.SetAttribute("Description",$rule.Description)
                    $newRuleElement.SetAttribute("Program", (ConvertAny -value $rule.ApplicationName))
                    $newRuleElement.SetAttribute("Service",(ConvertAny -value $rule.serviceName))
                    $newRuleElement.SetAttribute("direction", $direction)
                    $newRuleElement.SetAttribute("enabled", $rule.enabled)
                    $newRuleElement.SetAttribute("group", $rule.grouping)
                    $newRuleElement.SetAttribute("protocol", $rule.protocol)
                    $newRuleElement.SetAttribute("profile", $profile)
                    $newRuleElement.SetAttribute("action", $action)
                    $newRuleElement.SetAttribute("localPorts", (ConvertAny -value $rule.localPorts))
                    $newRuleElement.SetAttribute("remotePorts", (ConvertAny -value $rule.remotePorts))
                    $newRuleElement.SetAttribute("localAddress", (ConvertAny -value $rule.localAddresses))
                    $newRuleElement.SetAttribute("remoteAddress", (ConvertAny -value $rule.remoteAddresses))

                        $xml["Rules"].AppendChild($newRuleElement) | Out-Null

                    $xml.save($firewallXML) 

                    }
               
           }

}

Function Capture
{
    $result = $true

    $computerName = $env:COMPUTERNAME
    Log "INFO" ("Computer name is " + $computerName)
    #Build File Names

    #Generated Export Files

    $Script:localUsersAndGroupsXML = ($Script:DeltaLoc + "\" + $computerName + "_localgroupmembership.xml")
    $Script:allServicesXML = ($Script:DeltaLoc + "\" + $computerName + "_allServices.xml")
    $Script:difServicesXML = ($Script:DeltaLoc + "\" + $computerName + "_difServices.xml")
    $Script:userRightsXML = ($Script:DeltaLoc + "\" + $computerName + "_userRights.xml")
    $Script:firewallXML = ($Script:DeltaLoc + "\" + $computerName + "_firewall.xml")
    $Script:rsopHTML = ($Script:DeltaLoc + "\" + $computerName + "_RSOP.html")
    $Script:netshExport = ($Script:DeltaLoc + "\" + $computerName + "_netshExport.wfw")
    $Script:userRightsTemp = ($Script:DeltaLoc + "\" + $computerName + "_LUSR_RIGHTS.inf")

    Log "INFO" ("Gathering Information....")
    
    Log "INFO" ("(Item 1 of 5) Gathering Local User Rights Assignments...")
    CaptureLocalUserRights 

    Log "INFO" ("(Item 2 of 5) Gathering Services Configuration...")
    CaptureServices
    
    #Log "INFO" ("(Item 3 of 6) NETSH Export of Firewall Config (.wfw )...")
    #netshFirewallExport

    Log "INFO" ("(Item 3 of 5) XML Export of Firewall Config...")

    If($host.version.major -lt 3)
    {
        Get-FirewallConfigLegacy
    }
    Else
    {
        Get-firewallConfig
    }
        
    Log "INFO" ("(Item 5 of 6) Export RSOP...")           
    RSOP

    Log "INFO" ("(Item 6 of 6) Export Local Groups and Members...")    
    if ($IsDC -eq $false)
    {
        CaptureLocalUsersGroups
    } else {
        write-host "Information: Skipping because this machine is a Domain Controller." -ForegroundColor Cyan
    }

    Log "SUCC" ("Gathered files are stored in " + $Script:DeltaLoc + ".")

    return $result
}

######################################################################################################################
# CreateDelta Functions
######################################################################################################################
Function CreateGPO($name)
{
#       
#      .DESCRIPTION  
#         Creates a Group Policy Object with the specified name
#  

    $error.clear()
    try{
        New-GPO -Name $name -ErrorAction Stop | Out-Null
    }catch{
        if($error -match "GPO already exists"){
            Log "INFO" ("The Group Policy " + $name + " already exists. The existing policy will be used")
        }elseif($error){
            Log "ERR" ("Unable to create the Group Policy " + $name)
        }
    }
  
    If(!$error){
            Log "SUCC" ("Create the Group Policy " + $name)
    }
}

Function Configure-UserRights()
{
#       
#      .DESCRIPTION  
#         Loads the content of the baseline user rights assignments and for 
#         for each user right, compares the baseline values with those gathered
#         during the securitity assessment
#  
    
    #Create the temporary inf file
    Set-Content ($Script:TempPath + "\userRightsDif.txt") "[Privilege Rights]"

    #For each user right, call the function to compare with the captured rights
    foreach($userRight in $processingRulesXML.ProcessingRules.UserRights.Policy){   
        CompareRights -preDefined $userRight   
    }
}

Function CompareRights($preDefined) 
{
#       
#      .DESCRIPTION  
#         Called by the UserRights Function to compare the baseline and configured accounts
#         for the specified user right
#  

    #Start building the string that will be written to the GptTmpl.inf
    $gptTmplString = ($preDefined.name + "=")
    $differenceFound = $false
    $accountName = $null

    #Get the rights that have been captured
    $configuredRights = [xml](Get-Content ($Script:DeltaLoc + "\" + $serverName + "_UserRights.xml"))

    #Get list of accounts for the defined user right
    $configuredAccounts = $configuredRights.UserRights.Policy | where {$_.name -eq $preDefined.name}

    Log "INFO" ("Assessing User Right: " + [string]$preDefined.Caption)

    if($configuredAccounts){
        Log "INFO" ("The Server has the following accounts configured: " + ($configuredAccounts.Account.name -join ", "))
        Log "INFO" ("The MSBP has the following accounts configured: " + ($preDefined.Accounts))

        #Split the predefined account list so we can use the contains operator
        $preDefinedSplit = ($preDefined.Accounts).Split(",")

        #For each account in the captured list of accounts
        foreach($account in $configuredAccounts.Account){
            #Replace the BUILTIN and NT AUTHORITY prefixes
            $accountName = ($account.name).Replace("BUILTIN\","")
            $accountName = ($accountname).Replace("NT AUTHORITY\","")


            #If the baseline is configured as empty, check if the server configuration is also empty. If it isn't it must be different, so update the account list
            if($preDefined.Accounts -eq ""){      
                if($accountname -ne ""){
                    $gptTmplString += ($accountName + ",")
                    $differenceFound = $true
                }
            #If the server configuration is not a defined in the account list, update the configuration
            }elseIf ($preDefinedSplit -notcontains $accountname) {
                #Check whether this is a value we know about and want to ignore
                $preDefinedExclusions = $processingRulesXML.ProcessingRules.UserRightsToIgnore.UserRight | where {$_.name -eq $preDefined.Name}
    
                if($preDefinedExclusions){
                    #Check the account is not a known exclusion, for example the Backup Operators
                    if((($preDefinedExclusions.accounts).Split(",") |Foreach-Object{$_.TrimStart()}) -notcontains $accountname){
                        Log "SUCC" ("The account " + $accountName + " will be granted the privilege " + [string]$preDefined.caption)
                        $gptTmplString += ($accountName + ",")
                        $differenceFound = $true
                    }else{
                         Log "INFO" ("Ignoring the account " + $accountName + " as it is configured in the ignore list")
                    }
                }else{
                    Log "SUCC" ("The account " + $accountName + " will be granted the privilege " + [string]$preDefined.caption)
                    $gptTmplString += ($accountName + ",")
                    $differenceFound = $true
                }
            }
        }

         #If differences have been found, write the final string to the configuration file.
         if ($differenceFound -ne $false){ 
             $gptTmplString += $preDefined.accounts
             Add-Content ($Script:TempPath + "\userRightsDif.txt") ($gptTmplString.trimend(","))
         }
    }
}

Function Configure-Services()
{
#       
#      Loads the capture Services XML file and for each service, calls the CompareService function
#      to evaluate the service and determine whether it is not configured in the baseline. 
#         
#  

    #Set the temporary file
    Set-Content ($Script:TempPath + "\services.csv") "[Service General Setting]"
    $capturedServicesXMLLocation = ($Script:DeltaLoc + "\" + $serverName + "_allServices.xml")
    $xml = [xml](Get-Content $capturedServicesXMLLocation)

    foreach ($capturedService in $xml.Services.Service){
        CompareService -serviceName $capturedService.name -serviceCaption $capturedService.Caption -serviceStartMode $capturedService.StartMode
    }
}

Function CompareService($serviceName, $serviceCaption, $serviceStartMode)
{
#       
#      .DESCRIPTION  
#         Called by the Services Function to compare the baseline and server service configurations and capture any 
#        services that are new on the target system
#  

    #Hash table to convert startmodes
    $serviceStartModeTable = @{"Auto"="2";"Manual"="3";"Disabled"="4"}
    $controlledServices = $processingRulesXML.ProcessingRules.ControlledServices
    $ignoredServices = $processingRulesXML.ProcessingRules.IgnoredServices
    $baselineServices = $processingRulesXML.ProcessingRules.BaselineServices.Service
    $baselineServicesArray = @()
    $controlledServicesArray = @() 

    foreach($service in $controlledServices){
        $controlledServicesArray += $service.name
    }

    foreach($service in $baselineServices){
        $baselineServicesArray += $service.name
    }

    $findBaselineService = $baselineServices | where {($_.Name -eq $servicename)}
    
    if(($serviceName -match "Svc_") -or ($serviceName -match "Service_")){ 
        Log "INFO" ("Ignoring the service " + $serviceName + " as it represents a per-user service")
        $addToDelta = $false
    
    }else{

    $addToDelta = $false
        if(!($ignoredServicesArray -match $serviceName)){
            if (($findBaselineService)){
                if(!($findBaselineService.startmode -eq $serviceStartMode)){
                    if(!(($serviceStartMode -eq "Manual") -and ($findBaselineService.startmode -eq "Auto"))){
                        $addtoDelta = $true
                    }
                }
            
        }else{
                $addtoDelta = $true
                }
        
    }else{
         Log "INFO" ("Ignoring the service " + $serviceName + " as it is defined in the ignore list")
    }

    if($addToDelta){
        if($controlledServicesArray -match $serviceName){
            $popupBox = new-object -comobject wscript.shell
            $response = $popupBox.popup(“The service $serviceCaption has start mode $serviceStartMode configured on the target machine. Please select OK to include this in the delta.“,0,”Controlled Service Detected in Delta”,1)
            if($response -eq 1){
                Log "SUCC" ("Configure the service " + $serviceName + " with startmode " + $serviceStartMode)
                Add-content ($Script:TempPath + "\services.csv")  ([char]34 + $servicename + [char]34 + "," + $serviceStartModeTable[$serviceStartMode] + "," + [char]34 + [char]34)
            }
        }else{
            Log "SUCC" ("Configure the service " + $serviceName + " with startmode " + $serviceStartMode)
            Add-content ($Script:TempPath + "\services.csv")  ([char]34 + $servicename + [char]34 + "," + $serviceStartModeTable[$serviceStartMode] + "," + [char]34 + [char]34)
        }
    }
    }
}

Function Configure-Firewall
{
    #Import the Firewall Configuration into the GPO
    $script:PreDefinedRules = $processingRulesXML.ProcessingRules.MSBPRules.Rule

    #Check the OS Version - Firewall rules need to be handled different for 2008 and 2012+ 
    if(((Get-WmiObject win32_operatingsystem).caption -match "2012") -or ((Get-WmiObject win32_operatingsystem).caption -match "2016")){
        Log "INFO" ("Converting the Firewall XML to GPO...")
        Firewall-toGPO -policy ($gpoName + " Firewall Delta Policy")
    }elseif((Get-WmiObject win32_operatingsystem).caption -match "2008"){
        Log "INFO" ("Converting the Firewall XML to GPO... (Using Netsh)")
        Firewall-toGPO-NetSh -policy ($gpoName + " Firewall Delta Policy")
    }
}

Function Configure-RestrictedGroups()
{
#       
#      .DESCRIPTION  
#         Configures the Restricted Groups Group Policy settings
#        
#  

    Set-Content ($Script:TempPath + "\restrictedGroups.txt") "[Group Membership]"
    $xml = [xml](Get-Content ($Script:DeltaLoc + "\" + $serverName + "_LocalGroupMembership.xml"))

    foreach($group in $xml.Groups.Group){
        foreach($restricted in $Script:processingRulesXML.ProcessingRules.RestrictedGroups.Group){
            if($group.name -eq $restricted.name){
                if($Group.SID){
                    $outputString = ("*" + $group.SID + "__Members=")
                }else{
                    $outputString = ($group.name + "__Members=")
                }

                foreach ($member in $group.member){
                    if($member.SID){
                        $outputString = ($outputString + "*" + $member.SID + ",")
                    }else{
                        $outputString = ($outputString + $member.name + ",")
                    }
                }

                $outputString = $outputString.TrimEnd(",")
                Add-Content ($Script:TempPath + "\restrictedGroups.txt") $outputString
            }
        }
    }
}

Function Firewall-toGPO($policy)
{
#       
#      .DESCRIPTION  
#         Opens the gathered Firewall XML file and injects the rules into the specified Group Policy
#  

    #Open the Firewall XML
    $xml = [xml](Get-Content ($Script:DeltaLoc + "\" + $serverName + "_Firewall.xml"))

    #Extract the firewall rules from the XML
    $gatheredFirewallRules = $xml.Rules.FirewallRule

    #Open the Group Policy
    $store = ($domain.dnsRoot + "\" + $policy)
    $gpo = Open-NetGPO -PolicyStore $store

    #Process each Firewall rule
    foreach($rule in $gatheredFirewallRules){
        #Check if the rule is not already in the MSBP and is inbound
        if(($script:preDefinedRules.Name -notcontains $rule.displayName) -and ($rule.direction -eq "Inbound")){
            #Check if this is an ICMP rule
            if($rule.protocol -match "ICMP"){                   
                try{   
                    Log "INFO" ("Attempting to create ICMP-based firewall rule  " + $rule.displayName)
		    $rule.LocalPorts = "Any"
                    New-NetFirewallRule -DisplayName $rule.displayName -Description $rule.description -Program $rule.program -Service $rule.service -direction $rule.direction -Enabled $rule.enabled -Protocol $rule.protocol -IcmpType $rule.icmptype -action $rule.action -LocalPort $rule.LocalPorts -RemotePort $rule.RemotePorts -LocalAddress $rule.localaddress -RemoteAddress $remoteAddressArray -Profile $rule.profile -GPOSession $GPO -ErrorAction Stop | out-null
                }catch{
                    Log "ERR" ("Unable to create the ICMP-based firewall rule " + $rule.displayName)
                }
                
                if(!$Error){
                    Log "SUCC" ("Created the firewall rule " + $rule.displayName)
                }     
            #Not an ICMP rule
            }elseif($rule.LocalPorts -match ","){
                try{   
                    Log "INFO" ("Attempting to create firewall rule " + $rule.displayName)
                    $MultipleLocalPorts = $rule.LocalPorts -split(",")
                    New-NetFirewallRule -DisplayName $rule.displayName -Description $rule.description -Program $rule.program -Service $rule.service -direction $rule.direction -Enabled $rule.enabled -Protocol $rule.protocol -action $rule.action -LocalPort $MultipleLocalPorts -RemotePort $rule.RemotePorts -LocalAddress $rule.localaddress -RemoteAddress $remoteAddressArray -Profile $rule.profile -GPOSession $GPO -ErrorAction Stop | out-null  
                }catch{
                    Log "ERR" ("Unable to create the firewall rule " + $rule.displayName)
                }

                if(!$Error){
                    Log "SUCC" ("Created the firewall rule " + $rule.displayName)
                } 
            }else{
                try{   
                    Log "INFO" ("Attempting to create firewall rule " + $rule.displayName)
                    New-NetFirewallRule -DisplayName $rule.displayName -Description $rule.description -Program $rule.program -Service $rule.service -direction $rule.direction -Enabled $rule.enabled -Protocol $rule.protocol -action $rule.action -LocalPort $rule.LocalPorts -RemotePort $rule.RemotePorts -LocalAddress $rule.localaddress -RemoteAddress $remoteAddressArray -Profile $rule.profile -GPOSession $GPO -ErrorAction Stop | out-null  
                }catch{
                    Log "ERR" ("Unable to create the firewall rule " + $rule.displayName)
                }

                if(!$Error){
                    Log "SUCC" ("Created the firewall rule " + $rule.displayName)
                } 
            }
        #Acknowledge rules that have been ignored
        }elseif ($script:preDefinedRules.Name -contains $rule.displayName){
            Log "INFO" ("Ignoring rule " + $rule.displayName + " as it is included in the baseline")
        }
    }

    #Save the settings in the GPOSession
    Save-NetGPO -GPOSession $GPO
}

Function Firewall-toGPO-NetSh($policy)
{
#       
#      .DESCRIPTION  
#        For use on Windows Server 2008 where the new-netfirewall cmdlets are not available
#         
# 

    #Identify the netsh export files
    $netshInput = ($script:DeltaLoc + "\" + $serverName + "_netshTemp.txt")
    $wfwfile = ($Script:DeltaLoc + "\" + $serverName + "_netshExport.wfw")

    #Import the netsh export into the Group Policy 
    $stream = [System.IO.StreamWriter] $netshinput
    $stream.WriteLine('advfirewall')
    $stream.WriteLine('set store gpo=' + [char]34 + $domain.dnsroot + '\' + $policy + [char]34)
    $stream.WriteLine('show store')
    $stream.WriteLine('import ' + $wfwfile)
    $stream.WriteLine('exit')
    $stream.close()
 
    #Pipe Netsh commands in Netsh 
    get-content $netshinput | netsh

    Log "INFO" ("Cleaning up Firewall settings... this takes time")

    #As the Netsh import continue all rules, we need to cleanup the rules that have been imported
    $gpo = Get-GPRegistryValue -name $policy -key "HKLM\Software\Policies\Microsoft\WindowsFirewall\FirewallRules"

    #Create a array for the baseline rules so we can check whether any import rules are already present in the MSBP
    $preDefinedFirewallRules = @()
    foreach ($preDefinedFirewallrule in $script:PreDefinedRules){
        $preDefinedFirewallRules += $preDefinedFirewallRule.Name
    }

    #Evaluate each rules that has been imported into the Group Policy
    foreach ($rule in $gpo){
        #If the rule is disabled, remove it from the Group Policy
        if($rule.value -match "Active=FALSE"){
            Log "INFO" ("Removing disabled rule " + $rule.valueName)
            try{
                Remove-GPRegistryValue -name $policy -key $rule.fullkeypath -valueName $rule.valueName | Out-Null
            }catch{
            }
        #If the rule is an outbound rule, remove it from the Group Policy
        }elseif($rule.value -match "Dir=Out"){
            Log "INFO" ("Removing outbound rule " + $rule.valueName) 
            try{
                Remove-GPRegistryValue -name $policy -key $rule.fullkeypath -valueName $rule.valueName | out-null
            }catch{
            }
        #If the rule is one of the rules defined in the baseline, remove it from the Group Policy
        }elseif($preDefinedFirewallRules -contains $rule.valueName){
            Log "INFO" ("Removing pre-defined rule " + $rule.valueName) 
            try{
                Remove-GPRegistryValue -name $policy -key $rule.fullkeypath -valueName $rule.valueName | out-null
            }catch{
            }
        #Otherwise ignore the rule and leave it in the Group Policy  
        }else{
            Log "INFO" ("Ignoring rule " + $rule.valueName) 
        }
    }

    #Remove any Global Firewall Settings from the Group Policy. These will be contained in the baseline policy
    Get-GPRegistryKey -GPO $policy -key "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\WindowsFirewall"

}

Function Get-GPRegistrySubkey($policy, $KeyPath)
{
    $val = @(Get-GPRegistryValue -Name $policy -key $keypath -ErrorAction SilentlyContinue)
    $val | %{
        $_
        if($_.fullKeyPath -ne $keyPath) {
            Get-GPRegistrySubkey $policy $_.fullkeypath
        }
    }
}

function Get-GPRegistryKey($gpo, $key)
{
    $results =  Get-GPRegistrySubkey $gpo $key 
    $items = $Results | sort fullkeypath 

    foreach ($item in $items) 
    {
  
        If($item.fullkeyPath -match "HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsFirewall\\FirewallRules"){
        }ElseIf($item.valueName -match "PolicyVersion"){
        }Else{
            Log "INFO" ("Deleting " + $item.fullkeypath + " value " + $item.valueName)
            If(!($item.valueName -eq $null)){
                Remove-GPRegistryValue -Name $gpo -key $item.fullkeypath -valuename $item.valueName | out-null
            }
        }
    }
}

Function AddGptTmpl-toGPO
{
#       
#      .DESCRIPTION  
#         Takes the configured GptTmpl.inf file and copies into the Server Security Delta Policy
#

    #Add the User Rights and Services Configuration to the Group Policy Security Inf
    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureServices -eq "True"){
        $servicesSection = Get-Content($Script:TempPath + "\services.csv")
        Add-content($Script:TempPath + "\gpttmpl.inf") $servicesSection
    }

    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureUserRights -eq "True"){
        $userRightsSection = Get-Content($Script:TempPath + "\userrightsdif.txt")
        Add-content($Script:TempPath + "\gpttmpl.inf") $userRightsSection
    }

    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureRestrictedGroups -eq "True"){
        $restrictedGroupsSection = Get-content($Script:TempPath + "\restrictedGroups.txt")
        Add-content($Script:TempPath + "\gpttmpl.inf") $restrictedGroupsSection
    }

    #Build string of the SYSVOL Path
    $sysvol = ("\\" + ($Script:strDomainDN.Replace("DC=","").Replace(",",".")) + "\Sysvol\" + ($Script:strDomainDN.Replace("DC=","").Replace(",",".")))
    
    #Get the GPO Information
    $gpo = Get-Gpo -Name ($gpoName + " Security Delta Policy")
    $gpoDirectory = ($sysvol + "\policies\{" + $gpo.id + "}\Machine\Microsoft\Windows NT\Secedit")

    Import-GPO -backupID "2B8C8CC7-C705-41CA-9508-4F7A9F109CAD" -path ($PSScriptRoot + "\Baseline\StarterGPO") -targetName ($gpoName + " Security Delta Policy") | out-null
      
    #Check if the required directory structure exists. If not then create it. 
    if(!(Test-Path $gpoDirectory)){
    #    New-Item -Path $gpoDirectory -ItemType directory | Out-Null
    }

    Log "INFO" ("Adding the gptTmpl.inf file to " + $gpoDirectory)

    #Copy the GptTmpl.inf to the target GPO folder
    Copy-Item ($Script:TempPath + "\Gpttmpl.inf") $gpoDirectory
}

Function CreateDelta
{
#       
#      .DESCRIPTION  
#         Main processing function
#  
    $result = $true

    #Create the GptTmpl.inf that will contain the security policies
    Set-content($Script:TempPath + "\gpttmpl.inf") "[Unicode]"
    Add-content($Script:TempPath + "\gpttmpl.inf") "Unicode=yes"
    Add-content($Script:TempPath + "\gpttmpl.inf") "[Version]"
    Add-content($Script:TempPath + "\gpttmpl.inf") "signature=`$CHICAGO$" 
    Add-content($Script:TempPath + "\gpttmpl.inf") "Revision=1"

    #If a gponame parameter has been specfied, create the GPO and import the settings
    if($gpoName -ne ""){
        Log "INFO" ("Option to create GPO has been specified...")
        Log "INFO" ("Creating Firewall Policy - " + $gpoName + " Firewall Delta Policy")
        CreateGPO -name ($gpoName + " Firewall Delta Policy")
        Log "SUCC" ("Creating Firewall Policy - " + $gpoName + " Firewall Delta Policy" + " succeeded.")
        Log "INFO" ("Creating Security Policy - " + $gpoName + " Security Delta Policy")
        CreateGPO -name ($gpoName + " Security Delta Policy")
        Log "SUCC" ("Creating Security Policy - " + $gpoName + " Security Delta Policy" + " succeeded.")
    }else{
        Log "INFO" ("The option to create a GPO has not been specified. The configuration can be imported manually using the files located in " + $Script:TempPath + ".")

    }

    # Start the Delta Policy Configuration
    Log "INFO" ("Starting assessment of gathered files...")

    # Configure the User Rights Assignment
    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureUserRights -eq "True"){
        Log "INFO" ("Comparing User Rights Assignments...")
        Configure-UserRights 
    }else{
        Log "Info" ("User Rights Assignment processing has been disabled in the Configuration XML files. Skipping")
    }

    # Configure the Services
    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureServices -eq "True"){
        Log "INFO" "Comparing Services configuration..."
        Configure-Services 
    }else{
        Log "INFO" ("Services processing has been disabled in the Configuration XML files. Skipping")
    }
    
    #Configure the Firewall
    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureFirewall -eq "True"){
        Log "INFO" ("Comparing Firewall configuration...")
        Configure-Firewall
        
    }else{
        Log "INFO" ("Firewall processing has been disabled in the Configuration XML files. Skipping")
    }

    #Configure the Restricted Groups
    if($Script:processingRulesXML.ProcessingRules.Global.ConfigureRestrictedGroups -eq "True"){
        Log "INFO" "Comparing Restricted Groups configuration..."
        Configure-RestrictedGroups
        
    }else{
        Log "INFO" ("Restricted Group processing has been disabled in the Configuration XML files. Skipping")
    }

    if($gpoName -ne ""){
        #Copy the GptTmpl.inf to SYSVOL
        AddGptTmpl-toGPO
    }

    return $result
}

######################################################################################################################
# Main
######################################################################################################################

Write-Host -ForegroundColor Gray ("Microsoft Server Lockdown Assessment " + $Global:Version)
Write-Host -ForegroundColor Gray "Copyright (c) Microsoft. All Rights Reserved."

$productType = (Get-CimInstance -ClassName Win32_OperatingSystem).ProductType
$computerName = $env:COMPUTERNAME
switch ($productType) {
    1 { $IsDC=$false }
    2 { $IsDC=$true }
    3 { $IsDC=$false }
    default { $IsDC=$false }
}
Write-Host "IsDC: $IsDC"

Start-Log

# Import Modules
if($host.version.major -ge 3){
    Log "INFO" "Loading NetSecurity Module. Please wait..."
    if ((Load-Module "NetSecurity") -eq $True){
        Log "SUCC" "Loaded NetSecurity Module"
    }else{
        Log "ERR" "Failed to load NetSecurity Module"
        Log "ERR" "Terminating script..."
        Cleanup
    }
}

# Verify Pre-Reqs
Log "INFO" "-------------------------------------------"
Log "INFO" "Verifying pre-reqs and reading XML."
if((PreReqPrep)){
    Log "SUCC" "Pre-reqs check complete. XML parsed into script."
    Log "INFO" "-------------------------------------------"
}else{
    Log "ERR" "Error with pre-reqs or parsing XML."
    Log "ERR" "Terminating script..."
    Cleanup
}

# Capture branch
if($capture){
    Log "INFO" "Script running in capture mode."
    Log "INFO" "-------------------------------------------"
    Log "INFO" "Starting delta security assessment capture..."
    if((Capture)){
        Log "SUCC" "Capture complete."
        Log "INFO" "-------------------------------------------"
    }else{
        Log "ERR" "Error with delta security assessment capture."
        Log "ERR" "Terminating script..."
        Cleanup
    }
}

# Create branch
if($createDelta){
    Log "INFO" "Script running in delta creation mode."

    Log "INFO" "Loading ActiveDirectory Module. Please wait..."
    If ((Load-Module -name "ActiveDirectory") -eq $True){
        Log "SUCC" "Loaded ActiveDirectory Module"
    }else{
        Log "ERR" "Failed to load ActiveDirectory Module"
        Log "ERR" "Terminating script..."
        Cleanup
    }

    Log "INFO" "Loaded GroupPolicy Module.  Please wait..."
    If ((Load-Module "GroupPolicy") -eq $True){
        Log "SUCC" "Loaded GroupPolicy Module"
    }else{
        Log "ERR" "Failed to load GroupPolicy Module"
        Log "ERR" "Terminating script..."
        Cleanup
    }

    Log "INFO" "-------------------------------------------"
    Log "INFO" "Starting security assessment delta creation..."
    if((CreateDelta)){
        Log "SUCC" "Delta creation complete."
        Log "INFO" "-------------------------------------------"
    }else{
        Log "ERR" "Error with delta security assessment creation."
        Log "ERR" "Terminating script..."
        Cleanup
    }
}
Cleanup


# SIG # Begin signature block
# MIIoKgYJKoZIhvcNAQcCoIIoGzCCKBcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAjCW/Pik5nd+d2
# riO0Qn28DblpktB2zZoD5Rmh2c6y36CCDXYwggX0MIID3KADAgECAhMzAAAEhV6Z
# 7A5ZL83XAAAAAASFMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM3WhcNMjYwNjE3MTgyMTM3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDASkh1cpvuUqfbqxele7LCSHEamVNBfFE4uY1FkGsAdUF/vnjpE1dnAD9vMOqy
# 5ZO49ILhP4jiP/P2Pn9ao+5TDtKmcQ+pZdzbG7t43yRXJC3nXvTGQroodPi9USQi
# 9rI+0gwuXRKBII7L+k3kMkKLmFrsWUjzgXVCLYa6ZH7BCALAcJWZTwWPoiT4HpqQ
# hJcYLB7pfetAVCeBEVZD8itKQ6QA5/LQR+9X6dlSj4Vxta4JnpxvgSrkjXCz+tlJ
# 67ABZ551lw23RWU1uyfgCfEFhBfiyPR2WSjskPl9ap6qrf8fNQ1sGYun2p4JdXxe
# UAKf1hVa/3TQXjvPTiRXCnJPAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuCZyGiCuLYE0aU7j5TFqY05kko0w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwNTM1OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBACjmqAp2Ci4sTHZci+qk
# tEAKsFk5HNVGKyWR2rFGXsd7cggZ04H5U4SV0fAL6fOE9dLvt4I7HBHLhpGdE5Uj
# Ly4NxLTG2bDAkeAVmxmd2uKWVGKym1aarDxXfv3GCN4mRX+Pn4c+py3S/6Kkt5eS
# DAIIsrzKw3Kh2SW1hCwXX/k1v4b+NH1Fjl+i/xPJspXCFuZB4aC5FLT5fgbRKqns
# WeAdn8DsrYQhT3QXLt6Nv3/dMzv7G/Cdpbdcoul8FYl+t3dmXM+SIClC3l2ae0wO
# lNrQ42yQEycuPU5OoqLT85jsZ7+4CaScfFINlO7l7Y7r/xauqHbSPQ1r3oIC+e71
# 5s2G3ClZa3y99aYx2lnXYe1srcrIx8NAXTViiypXVn9ZGmEkfNcfDiqGQwkml5z9
# nm3pWiBZ69adaBBbAFEjyJG4y0a76bel/4sDCVvaZzLM3TFbxVO9BQrjZRtbJZbk
# C3XArpLqZSfx53SuYdddxPX8pvcqFuEu8wcUeD05t9xNbJ4TtdAECJlEi0vvBxlm
# M5tzFXy2qZeqPMXHSQYqPgZ9jvScZ6NwznFD0+33kbzyhOSz/WuGbAu4cHZG8gKn
# lQVT4uA2Diex9DMs2WHiokNknYlLoUeWXW1QrJLpqO82TLyKTbBM/oZHAdIc0kzo
# STro9b3+vjn2809D0+SOOCVZMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgowghoGAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAASFXpnsDlkvzdcAAAAABIUwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGjVcM8DvamnLN8rnWEEgSos
# YXrgiNkMe19suebaDhHsMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAVwAnT3N0NVOT1toaxgxQwuptLmF2cj23cgTEk58p8ccfjUCp81xtIaKZ
# C8Xd/T4B5IwgbZHpdWzZrl6HC3nGKRUcH/yvcFr+WD6f7u2LiiqqVStA5HxlKbf4
# Wo5NooSDm28/Jh2PrQ52MsjnaKO66e8UGrjYiF81PzcaU1mAj1QYHnNTDCtuTGep
# KA0I2g06PQNmGQRlEajYcZkfGw8TCrxMc3G3yeFTMBXVhdlQfZsaM8YJLfMCLKze
# 6rbJmOK5lklVBYRsgqAA7ng1KZ9+6BCduSwC41We9LbJioz2FgFikITe9b42Fkzs
# UIQecPObsVUJ2eFxJWGgkXxzZxpJZKGCF5QwgheQBgorBgEEAYI3AwMBMYIXgDCC
# F3wGCSqGSIb3DQEHAqCCF20wghdpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCDxIg8hVaIg9jOlUILvs6w416+3I7zMZFwLKiV57I26dAIGaEsTK85b
# GBMyMDI1MDcyOTE4MjgwNy45NzNaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0YwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHqMIIHIDCCBQigAwIBAgITMwAAAgbXvFE4mCPsLAABAAACBjANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQy
# NTBaFw0yNjA0MjIxOTQyNTBaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0YwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDpRIWbIM3Rlr397cjHaYx85l7I+ZVWGMCBCM911BpU
# 6+IGWCqksqgqefZFEjKzNVDYC9YcgITAz276NGgvECm4ZfNv/FPwcaSDz7xbDbsO
# oxbwQoHUNRro+x5ubZhT6WJeU97F06+vDjAw/Yt1vWOgRTqmP/dNr9oqIbE5oCLY
# dH3wI/noYmsJVc7966n+B7UAGAWU2se3Lz+xdxnNsNX4CR6zIMVJTSezP/2STNcx
# JTu9k2sl7/vzOhxJhCQ38rdaEoqhGHrXrmVkEhSv+S00DMJc1OIXxqfbwPjMqEVp
# 7K3kmczCkbum1BOIJ2wuDAbKuJelpteNZj/S58NSQw6khfuJAluqHK3igkS/Oux4
# 9qTP+rU+PQeNuD+GtrCopFucRmanQvxISGNoxnBq3UeDTqphm6aI7GMHtFD6DOjJ
# lllH1gVWXPTyivf+4tN8TmO6yIgB4uP00bH9jn/dyyxSjxPQ2nGvZtgtqnvq3h3T
# RjRnkc+e1XB1uatDa1zUcS7r3iodTpyATe2hgkVX3m4DhRzI6A4SJ6fbJM9isLH8
# AGKcymisKzYupAeFSTJ10JEFa6MjHQYYohoCF77R0CCwMNjvE4XfLHu+qKPY8GQf
# sZdigQ9clUAiydFmVt61hytoxZP7LmXbzjD0VecyzZoL4Equ1XszBsulAr5Ld2Kw
# cwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFO0wsLKdDGpT97cx3Iymyo/SBm4SMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQB23GZOfe9ThTUvD29i4t6lDpxJhpVRMme+
# UbyZhBFCZhoGTtjDdphAArU2Q61WYg3YVcl2RdJm5PUbZ2bA77zk+qtLxC+3dNxV
# sTcdtxPDSSWgwBHxTj6pCmoDNXolAYsWpvHQFCHDqEfAiBxX1dmaXbiTP1d0Xffv
# gR6dshUcqaH/mFfjDZAxLU1s6HcVgCvBQJlJ7xEG5jFKdtqapKWcbUHwTVqXQGbI
# lHVClNJ3yqW6Z3UJH/CFcYiLV/e68urTmGtiZxGSYb4SBSPArTrTYeHOlQIj/7lo
# VWmfWX2y4AGV/D+MzyZMyvFw4VyL0Vgq96EzQKyteiVeBaVEjxQKo3AcPULRF4Uz
# z98P2tCM5XbFZ3Qoj9PLg3rgFXr0oJEhfh2tqUrhTJd13+i4/fek9zWicoshlwXg
# Fu002ZWBVzASEFuqED48qyulZ/2jGJBcta+Fdk2loP2K3oSj4PQQe1MzzVZO52AX
# O42MHlhm3SHo3/RhQ+I1A0Ny+9uAehkQH6LrxkrVNvZG4f0PAKMbqUcXG7xznKJ0
# x0HYr5ayWGbHKZRcObU+/34ZpL9NrXOedVDXmSd2ylKSl/vvi1QwNJqXJl/+gJkQ
# EetqmHAUFQkFtemi8MUXQG2w/RDHXXwWAjE+qIDZLQ/k4z2Z216tWaR6RDKHGkwe
# CoDtQtzkHTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNN
# MIICNQIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjdGMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAE
# a0f118XHM/VNdqKBs4QXxNnN96CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7DOEAzAiGA8yMDI1MDcyOTE3MzE0
# N1oYDzIwMjUwNzMwMTczMTQ3WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDsM4QD
# AgEAMAcCAQACAg6GMAcCAQACAhN5MAoCBQDsNNWDAgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQELBQADggEBAIxzNWOsW5WI2gVo69VfFjVikarl6ng14eJIL5Rb1a0DZXN0
# icXq8WxaGmb2UevxfBDF2Mk2mCEGmgghyYBAW+f5r78YxCOuHLHHSq5pZQfMJXMw
# SqBFUAyjymPNLOf/rDUZlCqArrfvJIj3W5DsWcoaxTfXaDfAUuK/8eOEFyJNwyIq
# uVg0geTU1Sier04JLFvyxz8o753v2g6lcB8c5MqedODn30RFmZKXTBBuUrkavTyk
# MAY+C94hFoO2hMR4oGrtIa0hdjIfBz92wZXnWW2zfLppkCDE2WlYeWX0lc84kQ6w
# D7rVNBaIy7SGlagIa4VzuEiCCZKmgJmoG1qkWoYxggQNMIIECQIBATCBkzB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgbXvFE4mCPsLAABAAACBjAN
# BglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8G
# CSqGSIb3DQEJBDEiBCBO8GeNwsKygmwbDMjRw55b+RsMvQjNfVXvrPlhsFfF/zCB
# +gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIODo9ZSIkZ6dVtKT+E/uZx2WAy7K
# iXM5R1JIOhNJf0vSMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAIG17xROJgj7CwAAQAAAgYwIgQgx6Ai4KQzeZzpdGRY4OdGIvFlP3KQ
# 2uGK6uSaTJqqVPYwDQYJKoZIhvcNAQELBQAEggIAvpaK+pRJaG4DXAaYhEasqRiv
# CrtqsvM7czr8BNow+N+jhoqQtcCsDMlWXkr37hzsllqZw9oezTmAmNqk7ZDrnqjA
# ErMIn+YueiKwUJzOqoXZpOgXur3h9skP1Tk5HrCApq4TtJNQAqXlfLN4FRsjrdJG
# 7Kp6U5fyo944dCVXxGf3LD8LFBWjl78ZBxy2RQNMjDh3Tu7OjVMVgOOCmj4pVIJ5
# iN+oZuDcQLdZhGb0csPeNmWCpXWRj1KeMo7RbJ/KWDAPvWSBPbqtwZG9q/CXRCOy
# 5RIEWt47uze2N4eE6awCj+wWJbWmnGYPk/VnWjYOYvvdprWV5GXM+s8csBXP9nAu
# 7Dez4fR/4oMe/CNHMnVLjd4to4y7+Ie5j3KY4L9475KjYwkXXbcWfrNCyRZSO4QB
# z3+AzFZghxxOxOQHmO+6tXjUTZzVs+wbilbggZyRr2RyH6+9hyzzsr8E6mxl0Ax0
# 46UOYFWeQHcU65jkTYTjD11agG15CB0tRiqrqiEK+u9jZthF0vLQfQltDtBLF4iE
# j+ZlL5bQfvBcdO3as+b7knQfV0ThyP1E9IeT/pAdIozWIbF1TBNxvlyKXhDJ93jv
# 718onKdhLY/SHVP98KT59iuFIjvoGBYbyHjzSasNzfEUH8XrmvpHc0FbyQ/C8AuV
# yjVk9VomPJVp5Wmz8/8=
# SIG # End signature block
