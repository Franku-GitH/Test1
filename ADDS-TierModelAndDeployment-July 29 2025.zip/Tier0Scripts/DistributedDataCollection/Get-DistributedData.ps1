﻿# Written by Kip Gumenberg, Microsoft Security Enterprise Services, February 2024
############
### Init ###
############
Param
(
    $DestinationFolder,
    [switch]$IncludeTMIS,
    [switch]$SkipRegistry,
    [switch]$Debug,
    [switch]$IncludeFirewall
)
if ($DestinationFolder -eq "" -or $DestinationFolder -eq $null)
{
    write-host "Syntax: .\Get-DistributedData.ps1 \\Server.contoso.com\DistData"
    exit
}

$CurFolder = $PSScriptRoot
$FileTime = get-date -format "MM-dd-yyyy-HH-mm"

$DebugFlag = "off"
if ($Debug.IsPresent -eq $True) 
{
    $DebugFlag = "on"
    $LogFile = $CurFolder + "\" + "Get-DistributedData-$FileTime.LOG"
    Set-Content -Path $LogFile -Value $LineOut -Encoding Unicode
}

$productType = (Get-CimInstance -ClassName Win32_OperatingSystem).ProductType
$computerName = $env:COMPUTERNAME
switch ($productType) {
    1 { $IsDC=$false }
    2 { $IsDC=$true }
    3 { $IsDC=$false }
    default { $IsDC=$false }
}
Write-Host "IsDC: $IsDC"


#################
### Write Log ###
#################
Function WriteLog
{
    param ($LineIn)
    $CurTime =  get-date -UFormat "%m/%d/%Y %T"
    $LineOut = "$CurTime $LineIn"
    write-host "$LineOut"

    if ($DebugFlag -eq "on") {
        Add-Content -Path $LogFile -Value $LineOut -Encoding Unicode
    }

}

Get-ChildItem $CurFolder\*.LOG | Remove-Item

$StartTime = Get-Date
WriteLog "Start time: $StartTime"

$ServerFQDN = [System.Net.Dns]::GetHostEntry([string]"localhost").HostName

$ProductType = (Get-CimInstance -ClassName Win32_OperatingSystem).ProductType

switch ($ProductType) {
    1 { $ComputerType = "Workstation" }
    2 { $ComputerType = "Domain Controller" }
    3 { $ComputerType = "Member Server" }
}

$RegCounter = 0
$dicRegPerms = @{}

$Index = $ServerFQDN.IndexOf(".")
$ServerShortName = $ServerFQDN.Substring(0,$Index)

$Index = $DestinationFolder.LastIndexOf("\")
$ToolsServer = $DestinationFolder.Substring(0,$Index) + "\Upload$"



####################
### Output Files ###
####################
$URAFilename = "$CurFolder\UserRightsAssignment-$ServerFQDN.CSV"
$LocalGroupsFilename = "$CurFolder\LocalGroupMembership-$ServerFQDN.CSV"
$RegistryFilename = "$CurFolder\RegistryPermissions-$ServerFQDN.CSV"
$ShareFilename = "$CurFolder\SharePermissions-$ServerFQDN.CSV"
$ServicesFilename = "$CurFolder\Services-$ServerFQDN.CSV"
$TasksFilename = "$CurFolder\ScheduledTasks-$ServerFQDN.CSV"
$InstalledSoftware = "$CurFolder\InstalledSoftware-$ServerFQDN.CSV"
$GPResultsHTMFilename = "$CurFolder\GPRESULT-HTM-$ServerFQDN.html"
$GPResultsXMLFilename = "$CurFolder\GPRESULT-XML-$ServerFQDN.xml"
$WindowsFeatures = "$CurFolder\WindowsFeatures-$ServerFQDN.CSV"
$HotfixFilename = "$CurFolder\Hotfixes-$ServerFQDN.CSV"
$LocalUsersFilename = "$CurFolder\LocalUsers-$ServerFQDN.CSV"
$OSInfoFilename = "$CurFolder\OSInfo-$ServerFQDN.CSV"
$DCRegistryValuesFilename = "$CurFolder\DCRegistryValues-$ServerFQDN.CSV"
$CredGuardFilename = "$CurFolder\CredentialGuardStatus-$ServerFQDN.CSV"

$LineOut = '"ServerFqdn",'`
            + '"UserRightInternalName",'`
            + '"UserRightDisplayName",'`
            + '"IdentityReference"'

Set-Content -Path $URAFilename -Value $LineOut -Encoding Unicode

if ($IsDC -eq $false)
{

    $LineOut = '"ServerFqdn",'`
                + '"LocalGroupName",'`
                + '"LocalGroupSID",'`
                + '"MemberIdentityReference",'`
                + '"MemberObjectClass",'`
                + '"MemberSID"'

    Set-Content -Path $LocalGroupsFilename -Value $LineOut -Encoding Unicode

}

$LineOut = '"ServerFqdn",'`
            + '"RegistryKey",'`
            + '"AccessRulesProtected",'`
            + '"OwnerIdentityReference",'`
            + '"RegistryRights",'`
            + '"AccessType",'`
            + '"IdentityReference",'`
            + '"IsInherited",'`
            + '"InheritanceFlags",'`
            + '"PropagationFlags"'


if (!$SkipRegistry.IsPresent)
{
    Set-Content -Path $RegistryFilename -Value $LineOut -Encoding Unicode
}

$LineOut = '"ServerFqdn",'`
            + '"ShareName",'`
            + '"SharePath",'`
            + '"IdentityReference",'`
            + '"Domain",'`
            + '"SID",'`
            + '"AccessMask",'`
            + '"AccessType",'`
            + '"Access"'

Set-Content -Path $ShareFilename -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFqdn",'`
            + '"DisplayName",'`
            + '"PathName",'`
            + '"StartName",'`
            + '"StartMode",'`
            + '"State"'

Set-Content -Path $ServicesFilename -Value $LineOut -Encoding Unicode

 
$LineOut = '"ServerFqdn",'`
            + '"TaskName",'`
            + '"Principal"'

Set-Content -Path $TasksFilename -Value $LineOut -Encoding Unicode

$LineOut = '"ServerFQDN",'`
            + '"DisplayName",'`
            + '"DisplayVersion",'`
            + '"Publisher",'`
            + '"InstallDate"'

Set-Content -Path $InstalledSoftware -Value $LineOut -Encoding Unicode

$LineOut = '"Name",'`
            + '"DisplayName",'`
            + '"Description",'`
            + '"Installed",'`
            + '"InstalledState",'`
            + '"Type",'`
            + '"Path",'`
            + '"Depth",'`
            + '"DependsOn",'`
            + '"Parent",'`
            + '"ServerComponentDescriptor",'`
            + '"SubFeatures",'`
            + '"SystemService",'`
            + '"Notification",'`
            + '"BestPracticesNodeId",'`
            + '"EventQuery",'`
            + '"PostConfigurationNeeded",'`
            + '"MajorVersion",'`
            + '"MinorVersion",'`
            + '"NumericId",'`
            + '"InstallName"'

Set-Content -Path $WindowsFeatures -Value $LineOut -Encoding Unicode

$LineOut = '"Description",'`
            + '"HotFixId",'`
            + '"InstalledBy",'`
            + '"InstalledOn"'

Set-Content -Path $HotfixFilename -Value $LineOut -Encoding Unicode

if ($IsDC -eq $false)
{

    $LineOut = '"UserName",'`
                + '"PasswordLastSet",'`
                + '"LastLogon",'`
                + '"AccountCreated",'`
                + '"UserSID",'`
                + '"Enabled",'`
                + '"Description",'`
                + '"FullName",'`
                + '"PrincipalSource"'

    Set-Content -Path $LocalUsersFilename -Value $LineOut -Encoding Unicode
}

$LineOut = '"Name",'`
            + '"Value"'

Set-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode

if ($IsDC -eq $true)
{

    $LineOut = '"Name",'`
             + '"Value"'

    Set-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode
}

$LineOut = '"CredentialGuardEnabled"'

Set-Content -Path $CredGuardFilename -Value $LineOut -Encoding Unicode



$UserLogonRights = @{
    "SeTrustedCredManAccessPrivilge"    = "Access Credential Managager as a trusted caller"
    "SeNetworkLogonRight"               = "Access this computer from the network"
    "SeTcbPrivilege"                    = "Act as part of the operating system"
    "SeInteractiveLogonRight"           = "Allow log on locally"
    "SeRemoteInteractiveLogonRight"     = "Allow log on through Remote Desktop Services"
    "SeBackupPrivilege"                 = "Back up files and directories"
    "SeCreateTokenPrivilege"            = "Create a token object"
    "SeCreateGlobalPrivilege"           = "Create global objects"
    "SeCreatePermanentPrivilege"        = "Create permanent shared objects"
    "SeCreateSymbolicLinkPrivilege"     = "Create symbolic links"
    "SeDebugPrivilege"                  = "Debug programs"
    "SeDenyBatchLogonRight"             = "Deny log on as a batch job"
    "SeDenyInteractiveLogonRight"       = "Deny log on locally"
    "SeDenyNetworkLogonRight"           = "Deny access to this computer from the network"
    "SeDenyRemoteInteractiveLogonRight" = "Deny log on through Remote Desktop Services"
    "SeDenyServiceLogonRight"           = "Deny log on as a service"
    "SeEnableDelegationPrivilege"       = "Enable computer and user accounts to be trusted for delegation"
    "SeAuditPrivilege"                  = "Generate Security Audits"
    "SeImpersonatePrivilege"            = "Impersonate a client after authentication"
    "SeLoadDriverPrivilege"             = "Load and unload device drivers"
    "SeBatchLogonRight"                 = "Log on as a batch job"
    "SeServiceLogonRight"               = "Log on as a service"
    "SeSecurityPrivilege"               = "Manage auditing and security log"
    "SeRelabelPrivilege"                = "Modify an object label"
    "SeSystemEnvironmentPrivilege"      = "Modify firmware environment values"
    "SeManageVolumePrivilege"           = "Perform volume maintenance tasks"
    "SeAssignPrimaryTokenPrivilege"     = "Replace a process level token"
    "SeRestorePrivilege"                = "Restore files and directories"  
    "SeSyncAgentPrivilege"              = "Synchronize directory service data"
    "SeTakeOwnershipPrivilege"          = "Take ownership of files or other objects"
}

$LocalGroupSIDsToFilterOut = @{
    "S-1-5-32-579"                      = "Access Control Assistance Operators"
    "S-1-5-32-574"                      = "Certificate Service DCOM Access"
    "S-1-5-32-583"                      = "Device Owners"
    "S-1-5-32-573"                      = "Event Log Readers"
    "S-1-5-32-578"                      = "Hyper-V Administrators"
    "S-1-5-32-568"                      = "IIS_IUSRS"
    "S-1-5-32-556"                      = "Network Configuration Operators"
    "S-1-5-32-559"                      = "Performance Log Users"
    "S-1-5-32-558"                      = "Performance Monitor Users"
    "S-1-5-32-550"                      = "Print Operators"
    "S-1-5-32-552"                      = "Replicator"
    "S-1-5-32-582"                      = "Storage Replica Administrators"
    "S-1-5-32-581"                      = "System Managed Accounts Group"
    "S-1-5-32-545"                      = "Users"
}

$Win32APISignature = @'
[DllImport("advapi32.dll", SetLastError=true)]
public static extern bool LookupPrivilegeDisplayName(
  string systemName,
  string privilegeName,
  System.Text.StringBuilder displayName,
  ref uint cbDisplayName,
  out uint languageId
);
'@
$AdvApi32 = Add-Type advapi32 $Win32APISignature -Namespace LookupPrivilegeDisplayName -PassThru

##################################
### Get Privilege Display Name ###
##################################
function GetPrivilegeDisplayName {
  param(
    [String] $name
  )
  $displayNameSB = New-Object System.Text.StringBuilder 1024
  $languageId = 0
  $ok = $AdvApi32::LookupPrivilegeDisplayName($null, $name, $displayNameSB, [Ref] $displayNameSB.Capacity, [Ref] $languageId)
  if ( $ok ) {
    $displayNameSB.ToString()
  }
  else {
    if ( $UserLogonRights[$name] ) {
      $UserLogonRights[$name]
    }
    else {
      $name
    }
  }
}


###################################
### Get User Rights Assignments ###
###################################
function GetUserRightsAssignments 
{
    $SecEdit = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::System)) "SecEdit.exe"
    if ( -not (Test-Path $SecEdit) ) {
      Write-Error "File not found - '$SecEdit'" -Category ObjectNotFound
      return
    }
    WriteLog "Getting User Rights Assignments."
    $TemplateFilename = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
    $LogFilename = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
    $StdOut = & $SecEdit /export /cfg $TemplateFilename /areas USER_RIGHTS /log $LogFilename

    $URAData = Get-Content -Path $TemplateFilename -Encoding Unicode

    if ( $LASTEXITCODE -eq 0 ) 
    {
        foreach ( $Line in $URAData ) 
        {
            if ($Line.Contains(" = ") -eq $true)
            {
                $Index = $Line.IndexOf(" = ")
                $Length = $Line.Length + 1
                $AppliedLength = $Length - ($Index+4)
                $Privilege = $Line.Substring(0,$Index)
                $Principals = $Line.Substring($Index+3,$AppliedLength)
                $PrincipalsArray = $Principals.Split(',')
                $PrivilegeName = GetPrivilegeDisplayName $Privilege

                foreach ($Principal in $PrincipalsArray)
                {
                    $PrincipalOut = $Principal
                    if ($PrincipalOut.Contains("*S-") -eq $true)
                    {
                        $PrincipalOut = $PrincipalOut.Replace("*","")
                    }

                    $LineOut = '"' + $ServerFQDN + '",'`
                                + '"' + $Privilege  + '",'`
                                + '"' + $PrivilegeName  + '",'`
                                + '"' + $PrincipalOut  + '"'

                    Add-Content -Path $URAFilename -Value $LineOut -Encoding Unicode

                }
            }
        }
    }
    else {
      $OFS = ""
      Write-Error "$StdOut"
    }
    Remove-Item $TemplateFilename,$LogFilename -ErrorAction SilentlyContinue
}

##################################
### Get Local Group Membership ###
##################################
function GetLocalGroupMembership
{
    if ($ComputerType -eq "Workstation" -or $ComputerType -eq "Member Server")
    {
        WriteLog "Getting Local Group Membership."
        $Groups = Get-LocalGroup | Select-Object Name,SID
        foreach ($Group in $Groups)
        {
            $GroupName = $Group.Name
            $GroupSID = [string]$Group.SID

            if ($LocalGroupSIDsToFilterOut.ContainsKey($GroupSID) -eq $false)
            {
                $Members = $group | Get-LocalGroupMember -ErrorAction SilentlyContinue

                foreach ($Member in $Members)
                {
                    $MemberSource = $Member.PrincipalSource
                    $MemberObjectClass = $Member.ObjectClass
                    $MemberName = $Member.Name 
                    $MemberSID = [string]$Member.SID  
                
                    if ($MemberSource -ne "Local" -and $MemberSID.Contains("S-1-5-80-") -eq $false)
                    {
                        $LineOut = '"' + $ServerFQDN + '",'`
                                    + '"' + $GroupName  + '",'`
                                    + '"' + $GroupSID  + '",'`
                                    + '"' + $MemberName  + '",'`
                                    + '"' + $MemberObjectClass  + '",'`
                                    + '"' + $MemberSID  + '"'

                        Add-Content -Path $LocalGroupsFilename -Value $LineOut -Encoding Unicode
                    }
                }
            }
        }
    }
}

################################
### Get Registry Permissions ###
################################
function GetRegistryPermissions
{
    param (
        [string]$RootKey
    )

    if ($RootKey.Contains("*") -eq $true)
    {
        return
    }

    $Registry = Get-ChildItem -Path $RootKey -recurse -ErrorAction silentlycontinue
    foreach ($Reg in $Registry)
    {
        $RegKey = $Reg.Name
        $RegKey = $RegKey.Replace("HKEY_LOCAL_MACHINE\","HKLM:")
        if ($RegKey.Contains("*") -eq $false)
        {
            Try
            {
                $ACL = Get-Acl $RegKey -ErrorAction SilentlyContinue
                $AccessRulesProtected = $ACL.AreAccessRulesProtected
                $Owner = $ACL | select-object -expandproperty Owner
                foreach ($ACE in $ACL.Access)
                {
                    $RegistryRights = $ACE.RegistryRights
                    $AccessType = $ACE.AccessControlType
                    $IdentityReference = $ACE.IdentityReference
                    $IsInherited = $ACE.IsInherited
                    $InheritanceFlags = $ACE.InheritanceFlags
                    $PropagationFlags = $ACE.PropagationFlags

                    $Key = [string]$AccessRulesProtected + [string]$Owner + [string]$AccessRights + [string]$IdentityReference + [string]$IsInherited

                    if ($dicRegPerms.ContainsKey($Key) -eq $false)
                    {
                        $dicRegPerms.Add($Key,"")

                        $LineOut = '"' + $ServerFQDN + '",'`
                                    + '"' + $RegKey  + '",'`
                                    + '"' + $AccessRulesProtected  + '",'`
                                    + '"' + $Owner  + '",'`
                                    + '"' + $RegistryRights  + '",'`
                                    + '"' + $AccessType  + '",'`
                                    + '"' + $IdentityReference  + '",'`
                                    + '"' + $IsInherited  + '",'`
                                    + '"' + $InheritanceFlags  + '",'`
                                    + '"' + $PropagationFlags  + '"'

                        Add-Content -Path $RegistryFilename -Value $LineOut -Encoding Unicode
                    }
                } 
            } Catch {}
        }
    }
}

#############################
### Get Share Permissions ###
#############################
function GetSharePermissions
{
    WriteLog "Getting Share Permissions."
    # Get all shared folders on the local machine
    $sharedFolders = Get-WmiObject -Class Win32_Share

    # Iterate through each shared folder
    foreach ($folder in $sharedFolders) 
    {
        $ShareName = $folder.Name
        $SharePath = $folder.Path
        $ShareDesc = $folder.Description

        if ($SharePath -ne "")
        {
            $securityDescriptor = Get-WmiObject -Query "SELECT * FROM Win32_LogicalShareSecuritySetting WHERE Name = '$ShareName'"
            Try 
            {
                $permissions = $securityDescriptor.GetSecurityDescriptor().Descriptor.DACL
                foreach ($ace in $permissions) 
                {
                    $Trustee = $ace.Trustee.Name
                    $Domain = $ace.Trustee.Domain
                    $SID = $ace.Trustee.SIDString
                    $AccessMask = $ace.AccessMask
                    $AceType = $ace.AceType

                    if ($AceType -eq 0)
                    {
                        $AccessType = "Allow"
                    } else {
                        $AccessType = "Deny"
                    }
                
                    Switch ($AccessMask)
                    {   
                        2032127 
                        {
                            $Access = "FULL CONTROL"        
                        }
                        1245631
                        {
                            $Access = "READ, CHANGE"        
                        }
                        1179817
                        {
                            $Access = "READ"        
                        }
                    }
            
                    $LineOut = '"' + $ServerFQDN + '",'`
                                + '"' + $ShareName  + '",'`
                                + '"' + $SharePath  + '",'`
                                + '"' + $Trustee  + '",'`
                                + '"' + $Domain  + '",'`
                                + '"' + $SID  + '",'`
                                + '"' + $AccessMask  + '",'`
                                + '"' + $AccessType  + '",'`
                                + '"' + $Access  + '"'

                    Add-Content -Path $ShareFilename -Value $LineOut -Encoding Unicode

                }
            } catch {}
        }
    }
}

####################
### Get Services ###
####################
Function GetServices
{
    WriteLog "Getting Services."

    $Services = Get-WmiObject -ComputerName $ServerFQDN Win32_Service | Select-Object DisplayName, PathName, StartName, StartMode, State
    foreach ($Service in $Services)
    {
        $DisplayName = $Service.DisplayName
        $PathName = $Service.PathName
        $StartName = $Service.StartName
        $StartMode = $Service.StartMode
        $State = $Service.State
        $Status = $Service.Status
        $PathName = $PathName -replace '"',''
        $PathName = $PathName -replace ',',''

        $LineOut = '"' + $ServerFQDN + '",'`
                    + '"' + $DisplayName + '",'`
                    + $PathName  + ','`
                    + '"' + $StartName  + '",'`
                    + '"' + $StartMode  + '",'`
                    + '"' + $State  + '"'

        Add-Content -Path $ServicesFilename -Value $LineOut -Encoding Unicode
    }
}

###########################
### Get Scheduled Tasks ###
###########################
Function GetScheduledTasks
{
    WriteLog "Getting Scheduled Tasks."

    $Tasks = Get-ScheduledTask


    foreach ($task in $tasks) 
    {
        $taskName = $task.TaskName
        $principal = $task.Principal.UserID

        $LineOut = '"' + $ServerFQDN + '",'`
                    + '"' + $taskName  + '",'`
                    + '"' + $principal  + '"'

        Add-Content -Path $TasksFilename -Value $LineOut -Encoding Unicode
    }
}

##############################
### Get Installed Software ###
##############################
Function GetInstalledSoftware
{
    WriteLog "Getting Installed Software."

    $Software = Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*", "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" 
    
    foreach ($Pkg in $Software)
    {
        $DisplayName = $Pkg.DisplayName
        $DisplayVersion = $Pkg.DisplayVersion
        $Publisher = $Pkg.Publisher
        $InstallDate = $Pkg.InstallDate

        if ($DisplayName -ne "" -and $DisplayName -ne $null) 
        {
            $LineOut = '"' + $ServerFQDN + '",'`
                        + '"' + $DisplayName  + '",'`
                        + '"' + $DisplayVersion  + '",'`
                        + '"' + $Publisher  + '",'`
                        + '"' + $InstallDate  + '"'

            Add-Content -Path $InstalledSoftware -Value $LineOut -Encoding Unicode
        }
    }
}

#########################
### Get GPRESULT Data ###
#########################
Function GetGpResultData
{
    WriteLog "Getting GPRESULT Data."

    $gpresultParams = '/SCOPE:COMPUTER /H ' + '"' + $GPResultsHTMFilename + '"'
    Start-Process -WindowStyle Hidden -Wait -FilePath "C:\windows\system32\gpresult.exe" -ArgumentList $gpresultParams

    $gpresultParams = '/SCOPE:COMPUTER /X ' + '"' + $GPResultsXMLFilename + '"'
    Start-Process -WindowStyle Hidden -wait -FilePath "C:\windows\system32\gpresult.exe" -ArgumentList $gpresultParams


}

############################
### Get Windows Features ###
############################
Function GetWindowsFeatures
{
    WriteLog "Getting Windows Roles and Features Data."

    $Features = Get-WindowsFeature | Where-Object { $_.Installed -eq $true } | Select-Object *
    foreach ($Feature in $Features)
    {
        $FeatureName = $Feature.Name
        $FeatureDisplayName = $Feature.DisplayName
        $FeatureDescription = $Feature.Description
        $FeatureInstalled = $Feature.Installed
        $FeatureInstalledState = $Feature.InstalledState
        $FeatureType = $Feature.FeatureType
        $FeaturePath = $Feature.Path
        $FeatureDepth = $Feature.Depth
        $FeatureDependsOn = $Feature.DependsOn
        $FeatureParent = $Feature.Parent
        $FeatureServerComponentDescriptor = $Feature.ServerComponentDescriptor
        $FeatureSubFeatures = $Feature.SubFeatures
        $FeatureSystemService = $Feature.SystemService
        $FeatureNotification = $Feature.Notification
        $FeatureBestPracticesNodeId = $Feature.BestPracticesNodeId
        $FeatureEventQuery = $Feature.EventQuery
        $FeaturePostConfigurationNeeded = $Feature.PostConfigurationNeeded
        $FeatureMajorVersion = $Feature.AdditionalInfo.MajorVersion
        $FeatureMinorVersion = $Feature.AdditionalInfo.MinorVersion
        $FeatureNumericId = $Feature.AdditionalInfo.NumericId
        $FeatureInstallName = $Feature.AdditionalInfo.InstallName

        $LineOut = '"' + $FeatureName + '",'`
                    + '"' + $FeatureDisplayName  + '",'`
                    + '"' + $FeatureDescription  + '",'`
                    + '"' + $FeatureInstalled  + '",'`
                    + '"' + $FeatureInstalledState  + '",'`
                    + '"' + $FeatureType  + '",'`
                    + '"' + $FeaturePath  + '",'`
                    + '"' + $FeatureDepth  + '",'`
                    + '"' + $FeatureDependsOn  + '",'`
                    + '"' + $FeatureParent  + '",'`
                    + '"' + $FeatureServerComponentDescriptor  + '",'`
                    + '"' + $FeatureSubFeatures  + '",'`
                    + '"' + $FeatureSystemService  + '",'`
                    + '"' + $FeatureNotification  + '",'`
                    + '"' + $FeatureBestPracticesNodeId  + '",'`
                    + '"' + $FeatureEventQuery  + '",'`
                    + '"' + $FeaturePostConfigurationNeeded  + '",'`
                    + '"' + $FeatureMajorVersion  + '",'`
                    + '"' + $FeatureMinorVersion  + '",'`
                    + '"' + $FeatureNumericId  + '",'`
                    + '"' + $FeatureInstallName  + '"'

        Add-Content -Path $WindowsFeatures -Value $LineOut -Encoding Unicode
    }

}

####################
### Get Hotfixes ###
####################
Function GetHotfixes
{
    WriteLog "Getting Hotfix Data."

    $Hotfixes = Get-HotFix
    foreach($Hotfix in $Hotfixes)
    {
        $Source = $Hotfix.Source
        $Description = $Hotfix.Description
        $HotFixId = $Hotfix.HotFixID
        $InstalledBy = $Hotfix.InstalledBy
        $InstalledOn = $Hotfix.InstalledOn

        $LineOut = '"' + $Description + '",'`
                    + '"' + $HotFixId  + '",'`
                    + '"' + $InstalledBy  + '",'`
                    + '"' + $InstalledOn  + '"'

        Add-Content -Path $HotfixFilename -Value $LineOut -Encoding Unicode

    }
}

#######################
### Get Local Users ###
#######################
Function GetLocalUsers
{
    WriteLog "Getting Local Users."

    $users = Get-LocalUser

    # Loop through each user and get the Password Last Set and Last Logon information
    foreach ($user in $users) {
        $UserName = $user.Name
        $PasswordLastSet = $user.PasswordLastSet
        $LastLogon = $user.LastLogon
        $AccountCreated = $user.AccountCreated
        $UserSID = $user.SID
        $Enabled = $user.Enabled
        $Description = $user.Description
        $FullName = $user.FullName
        $PrincipalSource = $user.PrincipalSource


        $LineOut = '"' + $UserName + '",'`
                    + '"' + $PasswordLastSet  + '",'`
                    + '"' + $LastLogon  + '",'`
                    + '"' + $AccountCreated  + '",'`
                    + '"' + $UserSID  + '",'`
                    + '"' + $Enabled  + '",'`
                    + '"' + $Description  + '",'`
                    + '"' + $FullName  + '",'`
                    + '"' + $PrincipalSource  + '"'

        Add-Content -Path $LocalUsersFilename -Value $LineOut -Encoding Unicode

    }

}

###################
### Get OS Info ###
###################
Function GetOSInfo
{

    WriteLog "Getting Operating System Info."

    $osInfo = Get-ComputerInfo | Select-Object -Property WindowsProductName, WindowsVersion, WindowsBuildLabEx
    $OSNiceName = "$($osInfo.WindowsProductName)"
    $OSVersion = "$($osInfo.WindowsVersion)"
    $OSBuild = "$($osInfo.WindowsBuildLabEx)"

    $lastBootTime = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime

    $LineOut = '"OSNiceName",'`
        + '"' + $OSNiceName  + '"'`
    
    Add-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"OSVersion",'`
        + '"' + $OSVersion  + '"'`
    
    Add-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"OSBuild",'`
        + '"' + $OSBuild  + '"'
    
    Add-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode


    $LastBootTime = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime

    $Uptime = (Get-Date) - $LastBootTime

    $UptimeFormatted = "{0} days, {1} hours, {2} minutes, {3} seconds" -f $uptime.Days, $uptime.Hours, $uptime.Minutes, $uptime.Seconds

    $LineOut = '"LastBootTime",'`
        + '"' + $LastBootTime  + '"'
    
    Add-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"Uptime",'`
        + '"' + $Uptime  + '"'
    
    Add-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"UptimeFormatted",'`
        + '"' + $UptimeFormatted  + '"'
    
    Add-Content -Path $OSInfoFilename -Value $LineOut -Encoding Unicode
    


}


###########################
### Read Registry Value ###
###########################
Function ReadRegistryValue
{
    Param (
        $RegistryPath,
        $RegistryValueName
    )
    $error.Clear()
    $RegistryValue = Get-ItemProperty -Path $RegistryPath -Name $RegistryValueName -ErrorAction SilentlyContinue
    if ($error -ne $null)
    {
        $RegistryValueOut = "<Not Found>"
    } else {
	$RegistryValueOut = $RegistryValue.$RegistryValueName
    }
    return $RegistryValueOut
}

###################################
### Get Credential Guard Status ###
###################################
Function GetCredentialGuardStatus
{

    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard"
    $regKey = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue

    if ($regKey -and $regKey.HypervisorEnforcedCodeIntegrity -ne $null) {
        $cgStatus = Get-CimInstance -ClassName Win32_DeviceGuard | Select-Object -ExpandProperty SecurityServicesConfigured
        if ($cgStatus -contains 1) {
            $CredGuardEnabled = $true
        } else {
            $CredGuardEnabled = $false
        }
    } else {
        $CredGuardEnabled = $false
    }

    $LineOut = '"' + $CredGuardEnabled + '"'

    Add-Content -Path $CredGuardFilename -Value $LineOut -Encoding Unicode


}

############
### Main ###
############
GetGpResultData
GetUserRightsAssignments
if ($IsDC -eq $false)
{
    GetLocalGroupMembership
}
GetSharePermissions
GetServices
GetScheduledTasks
GetInstalledSoftware
GetWindowsFeatures
GetHotfixes
if ($IsDC -eq $False)
{
    GetLocalUsers
}
GetOSInfo
GetCredentialGuardStatus

if ($IsDC -eq $True)
{
    WriteLog "Getting Domain Controller Registry Values."

    $LdapEnforceChannelBinding = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" "LdapEnforceChannelBinding"
    $TLS1Enabled = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" "Enabled"
    $TLS1DisabledByDefault = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" "DisabledByDefault"
    $TLS11Enabled = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" "Enabled"
    $TLS11DisabledByDefault = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" "DisabledByDefault"
    $TLS12Enabled = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server" "Enabled"
    $TLS12DisabledByDefault = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server" "DisabledByDefault"
    $SSL3Enabled = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server" "Enabled"
    $SSL3DisabledByDefault = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server" "DisabledByDefault"
    $SMB1 = ReadRegistryValue "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" "SMB1"

    $LineOut = '"LdapEnforceChannelBinding",'`
        + '"' + $LdapEnforceChannelBinding  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"TLS1Enabled",'`
        + '"' + $TLS1Enabled  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"TLS1DisabledByDefault",'`
        + '"' + $TLS1DisabledByDefault  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"TLS11Enabled",'`
        + '"' + $TLS11Enabled  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"TLS11DisabledByDefault",'`
        + '"' + $TLS11DisabledByDefault  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"TLS12Enabled",'`
        + '"' + $TLS12Enabled  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"TLS12DisabledByDefault",'`
        + '"' + $TLS12DisabledByDefault  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"SSL3Enabled",'`
        + '"' + $SSL3Enabled  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"SSL3DisabledByDefault",'`
        + '"' + $SSL3DisabledByDefault  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode

    $LineOut = '"SMB1",'`
        + '"' + $SMB1  + '"'
    Add-Content -Path $DCRegistryValuesFilename -Value $LineOut -Encoding Unicode
    
}


if (!$SkipRegistry.IsPresent)
{
    WriteLog "Getting Registry Permissions."
    GetRegistryPermissions HKLM:HARDWARE
    GetRegistryPermissions HKLM:SYSTEM
}

if ($IncludeTMIS.IsPresent)
{

    $CheckFile = Test-Path "$CurFolder\Output"
    if ($CheckFile -eq $false)
    {
        New-Item "$CurFolder\Output" -ItemType Directory | Out-Null
    }

	# Unblock the file from security protections
	Unblock-File "$CurFolder\DSA\DeltaSecurityAssessment.ps1"

	# Execute DSA script
    Set-Location -Path "$CurFolder\DSA"
	$command1 = ".\DeltaSecurityAssessment.ps1 -Capture -deltaLocation '$CurFolder\Output'"
    WriteLog "$command1"
	iex $command1

	# Execute LGPO
    Set-Location -Path "$CurFolder\LGPO"
	$command2 = ".\LGPO.exe /b '$CurFolder\Output'"
    WriteLog "$command2"
    iex $command2

    if ($IncludeFirewall.IsPresent -eq $True) 
    {
        $FileSize = (Get-Item "c:\windows\System32\LogFiles\Firewall\pfirewall.log").Length
        
        if ($FileSize -gt 10000)
        {
            copy-item -path "c:\windows\System32\LogFiles\Firewall\pfirewall.log" -destination "$CurFolder\Output\$ServerShortname-pfirewall.txt"
        }
        #$command3 = "netsh.exe advfirewall export '$CurFolder\Output\$ServerShortName.wfw'"
        #iex $Command3
    }

    Set-Location -Path "$CurFolder"
    $PathToCheck = "$ToolsServer\$ServerShortname"
    $CheckFile = Test-Path $PathToCheck

    if ($CheckFile -eq $true)
    {
        Remove-Item -path "$ToolsServer\$ServerShortname" -Force -Recurse
    }



    WriteLog "CopyFrom: $CurFolder\Output\"
    WriteLog "CopyTo: $ToolsServer\$ServerShortname"
    Copy-Item $GPResultsHTMFilename -Destination "$CurFolder\Output\"
    Copy-Item $GPResultsXMLFilename -Destination "$CurFolder\Output\"

    Copy-item -Path "$CurFolder\Output\" -Destination "$ToolsServer\$ServerShortname" -Recurse -Force -ErrorAction Stop


	Remove-Item -path "$CurFolder\DSA" -Force -Recurse | Out-Null
	Remove-Item -path "$CurFolder\LGPO" -Force -Recurse | Out-Null
	Remove-Item -path "$CurFolder\Output" -Force -Recurse | Out-Null

}
Copy-Item $URAFilename -Destination $DestinationFolder

if (!$SkipRegistry.IsPresent)
{
    Copy-Item $RegistryFilename -Destination $DestinationFolder
}
Copy-Item $ShareFilename -Destination $DestinationFolder
Copy-Item $ServicesFilename -Destination $DestinationFolder
Copy-Item $TasksFilename -Destination $DestinationFolder
Copy-Item $InstalledSoftware -Destination $DestinationFolder
Copy-Item $GPResultsHTMFilename -Destination $DestinationFolder
Copy-Item $GPResultsXMLFilename -Destination $DestinationFolder
Copy-Item $WindowsFeatures -Destination $DestinationFolder
Copy-Item $HotfixFilename -Destination $DestinationFolder
if ($IsDC -eq $false)
{
    Copy-Item $LocalGroupsFilename -Destination $DestinationFolder
    Copy-Item $LocalUsersFilename -Destination $DestinationFolder
}
Copy-Item $OSInfoFilename -Destination $DestinationFolder
if ($IsDC -eq $true)
{
    Copy-Item $DCRegistryValuesFilename -Destination $DestinationFolder
}
Copy-Item $CredGuardFilename -Destination $DestinationFolder


Remove-Item $URAFilename
if (!$SkipRegistry.IsPresent)
{
    Remove-Item $RegistryFilename
}
Remove-Item $ShareFilename
Remove-Item $ServicesFilename
Remove-Item $TasksFilename
Remove-Item $InstalledSoftware
Remove-Item $GPResultsHTMFilename
Remove-Item $GPResultsXMLFilename
Remove-Item $WindowsFeatures
Remove-Item $HotfixFilename
if ($IsDC -eq $false)
{
    Remove-Item $LocalGroupsFilename
    Remove-Item $LocalUsersFilename
}
Remove-Item $OSInfoFilename
if ($IsDC -eq $true)
{
    Remove-Item $DCRegistryValuesFilename
}
Remove-Item $CredGuardFilename

$EndTime = Get-Date
$ElapsedTime = $EndTime - $StartTime
WriteLog "Elapsed time: $ElapsedTime"



# SIG # Begin signature block
# MIIoPAYJKoZIhvcNAQcCoIIoLTCCKCkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD41ITbtwlm45Cp
# Nc4FM38Oxcn83ATcgma+sJSjZ1S29KCCDYUwggYDMIID66ADAgECAhMzAAAEhJji
# EuB4ozFdAAAAAASEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM1WhcNMjYwNjE3MTgyMTM1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDtekqMKDnzfsyc1T1QpHfFtr+rkir8ldzLPKmMXbRDouVXAsvBfd6E82tPj4Yz
# aSluGDQoX3NpMKooKeVFjjNRq37yyT/h1QTLMB8dpmsZ/70UM+U/sYxvt1PWWxLj
# MNIXqzB8PjG6i7H2YFgk4YOhfGSekvnzW13dLAtfjD0wiwREPvCNlilRz7XoFde5
# KO01eFiWeteh48qUOqUaAkIznC4XB3sFd1LWUmupXHK05QfJSmnei9qZJBYTt8Zh
# ArGDh7nQn+Y1jOA3oBiCUJ4n1CMaWdDhrgdMuu026oWAbfC3prqkUn8LWp28H+2S
# LetNG5KQZZwvy3Zcn7+PQGl5AgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUBN/0b6Fh6nMdE4FAxYG9kWCpbYUw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwNTM2MjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AGLQps1XU4RTcoDIDLP6QG3NnRE3p/WSMp61Cs8Z+JUv3xJWGtBzYmCINmHVFv6i
# 8pYF/e79FNK6P1oKjduxqHSicBdg8Mj0k8kDFA/0eU26bPBRQUIaiWrhsDOrXWdL
# m7Zmu516oQoUWcINs4jBfjDEVV4bmgQYfe+4/MUJwQJ9h6mfE+kcCP4HlP4ChIQB
# UHoSymakcTBvZw+Qst7sbdt5KnQKkSEN01CzPG1awClCI6zLKf/vKIwnqHw/+Wvc
# Ar7gwKlWNmLwTNi807r9rWsXQep1Q8YMkIuGmZ0a1qCd3GuOkSRznz2/0ojeZVYh
# ZyohCQi1Bs+xfRkv/fy0HfV3mNyO22dFUvHzBZgqE5FbGjmUnrSr1x8lCrK+s4A+
# bOGp2IejOphWoZEPGOco/HEznZ5Lk6w6W+E2Jy3PHoFE0Y8TtkSE4/80Y2lBJhLj
# 27d8ueJ8IdQhSpL/WzTjjnuYH7Dx5o9pWdIGSaFNYuSqOYxrVW7N4AEQVRDZeqDc
# fqPG3O6r5SNsxXbd71DCIQURtUKss53ON+vrlV0rjiKBIdwvMNLQ9zK0jy77owDy
# XXoYkQxakN2uFIBO1UNAvCYXjs4rw3SRmBX9qiZ5ENxcn/pLMkiyb68QdwHUXz+1
# fI6ea3/jjpNPz6Dlc/RMcXIWeMMkhup/XEbwu73U+uz/MIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAASEmOIS4HijMV0AAAAA
# BIQwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDVC
# BAiNK7HaroAyRfUUuYL6Odplrmt64KtZhdybZzXmMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEA10ihJxiJORP80JBRBMUBLFAxEuIgXgoZ2kec
# Tt7sMhVtmfKhKoR2cs3DL4dojYXtjhwmIPErfSurcNSznRjKr7ySdf4m1unapnyi
# B0KHh1HlFYTEuS6C/Dtp6yN2TWzO9pphE/1n3n9Fkohu+dSjfNLK670iM1fu8fnu
# IB+uzRP9hCdTwBBJfjyDqBzM5p6N+RQ/jbEkkpVQFdxcB02SPt7ttjB+8S5XSScI
# aF70SN4sIwLvElXlXQI7/WkuBhxVHqvzc+vSzD/7fGdJ/VqDP5VIR3QHqNJygzZZ
# O1DiqdE9Vm23NfBKykZdOyjU6tT/hroSsjr/X+7UuxsdoEONb6GCF5cwgheTBgor
# BgEEAYI3AwMBMYIXgzCCF38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFSBgsqhkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCBVGoWX9g9iPN8CS8yQpJRFAfp/vsGBN/EK
# J2fXmSjSbgIGaFuGatdgGBMyMDI1MDcyOTE4MjczOC40OTlaMASAAgH0oIHRpIHO
# MIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxk
# IFRTUyBFU046OTYwMC0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFNlcnZpY2WgghHtMIIHIDCCBQigAwIBAgITMwAAAgTY4A4HlzJYmAAB
# AAACBDANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDAeFw0yNTAxMzAxOTQyNDdaFw0yNjA0MjIxOTQyNDdaMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDw3Sbcee2d66vkWGTIXhfG
# qqgQGxQXTnq44XlUvNzFSt7ELtO4B939jwZFX7DrRt/4fpzGNkFdGpc7EL5S86qK
# Yv360eXjW+fIv1lAqDD31d/p8Ai9/AZz8M95zo0rDpK2csz9WAyR9FtUDx52VOs9
# qP3/pgpHvgUvD8s6/3KNITzms8QC1tJ3TMw1cRn9CZgVIYzw2iD/ZvOW0sbF/DRd
# gM8UdtxjFIKTXTaI/bJhsQge3TwayKQ2j85RafFFVCR5/ChapkrBQWGwNFaPzpmY
# N46mPiOvUxriISC9nQ/GrDXUJWzLDmchrmr2baABJevvw31UYlTlLZY6zUmjkgaR
# fpozd+Glq9TY2E3Dglr6PtTEKgPu2hM6v8NiU5nTvxhDnxdmcf8UN7goeVlELXbO
# m7j8yw1xM9IyyQuUMWkorBaN/5r9g4lvYkMohRXEYB0tMaOPt0FmZmQMLBFpNRVn
# XBTa4haXvn1adKrvTz8VlfnHxkH6riA/h2AlqYWhv0YULsEcHnaDWgqA29ry+jH0
# 97MpJ/FHGHxk+d9kH2L5aJPpAYuNmMNPB7FDTPWAx7Apjr/J5MhUx0i07gV2brAZ
# 9J9RHi+fMPbS+Qm4AonC5iOTj+dKCttVRs+jKKuO63CLwqlljvnUCmuSavOX54IX
# OtKcFZkfDdOZ7cE4DioP1QIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFBp1dktAcGpW
# /Km6qm+vu4M1GaJfMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQBecv6sRw2HTLMy
# UC1WJJ+FR+DgA9Jkv0lGsIt4y69CmOj8R63oFbhSmcdpakxqNbr8v9dyTb4RDyNq
# tohiiXbtrXmQK5X7y/Q++F0zMotTtTpTPvG3eltyV/LvO15mrLoNQ7W4VH58aLt0
# 30tORxs8VnAQQF5BmQQMOua+EQgH4f1F4uF6rl3EC17JBSJ0wjHSea/n0WYiHPR0
# qkz/NRAf8lSUUV0gbIMawGIjn7+RKyCr+8l1xdNkK/F0UYuX3hG0nE+9Wc0L4A/e
# nluUN7Pa9vOV6Vi3BOJST0RY/ax7iZ45leM8kqCw7BFPcTIkWzxpjr2nCtirnkw7
# OBQ6FNgwIuAvYNTU7r60W421YFOL5pTsMZcNDOOsA01xv7ymCF6zknMGpRHuw0Rb
# 2BAJC9quU7CXWbMbAJLdZ6XINKariSmCX3/MLdzcW5XOycK0QhoRNRf4WqXRshEB
# aY2ymJvHO48oSSY/kpuYvBS3ljAAuLN7Rp8jWS7t916paGeE7prmrP9FJsoy1LFK
# mFnW+vg43ANhByuAEXq9Cay5o7K2H5NFnR5wj/SLRKwK1iyUX926i1TEviEiAh/P
# VyJbAD4koipig28p/6HDuiYOZ0wUkm/a5W8orIjoOdU3XsJ4i08CfNp5I73CsvB5
# QPYMcLpF9NO/1LvoQAw3UPdL55M5HTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKb
# SZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIy
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXI
# yjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjo
# YH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1y
# aa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v
# 3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pG
# ve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viS
# kR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYr
# bqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlM
# jgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSL
# W6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AF
# emzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIu
# rQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIE
# FgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWn
# G1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEW
# M2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5
# Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBi
# AEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV
# 9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3Js
# Lm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv
# 6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZn
# OlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1
# bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4
# rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU
# 6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDF
# NLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/
# HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdU
# CbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKi
# excdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTm
# dHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZq
# ELQdVTNYs6FwZvKhggNQMIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJp
# Y2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjk2MDAtMDVF
# MC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMK
# AQEwBwYFKw4DAhoDFQC6PYHRw9+9SH+1pwy6qzVG3k9lbqCBgzCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7DN9lTAi
# GA8yMDI1MDcyOTE3MDQyMVoYDzIwMjUwNzMwMTcwNDIxWjB3MD0GCisGAQQBhFkK
# BAExLzAtMAoCBQDsM32VAgEAMAoCAQACAg2rAgH/MAcCAQACAhJOMAoCBQDsNM8V
# AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSCh
# CjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBABilskyLLW4fBoChYwP0BBR4
# B8w8FO8T6U/DraF4oMK1HXIqbSmXx4rEIUFQAkgKnCxZwN2vz2zWe0wsijTDuq9G
# YCxSQxWIDVFD3IgUIbfDypN1QRpX2rCYJ7pFuuHeIWF5wqEOUrbVXrWlINj+S366
# MbIugC8WsoJL/Qqp8eei56V28oFKO/TOhRyIgwp5Um/JuvjaAHIamNsNUPJtVZ0D
# KfAUC3EhTcY0C1rFjWGJZLHEgwSg/6loE9ErTVHv6Oj3j8JDOXl65aZb7lPrstOR
# xm+H2g0JxT5lQ85CZt+cw3Bbx/wrjTizxLNQ+DJ0/cJRYAc3NtuTRshIiiUoTQQx
# ggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AgTY4A4HlzJYmAABAAACBDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAC3F5L/nCvlKzx1FVmQe8P
# CkNe4IHkDbDTc28M/u/dczCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIPnt
# eGX9Wwq8VdJM6mjfx1GEJsu7/6kU6l0SS5rcebn+MIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAIE2OAOB5cyWJgAAQAAAgQwIgQgh/fk
# iA9Eo3XnglAYDfhyjvGyCbtbCTgy6Qq05PIuALUwDQYJKoZIhvcNAQELBQAEggIA
# JTmmsKm95XOW+snS1tmTKXdmSuOwqgxkzXRNzruLYpdBUvPkjjMHF8TilRBoJZkG
# jhaVBPKHkMfiURysbwyH+c5vX/WpDMcbUKpGRrXey9Jgvbeg9i6JdG88H7xmrXDq
# c0HY18JNl7Luce33BjG196eyDY2VjXp52cB4stTSI95nOv+7rjnO1K7qQLnIcX0x
# d9y1eCi8Jf7AVh8SDYfXtamLJqnZaJQeT9aoLoPGfPL8+J4OY7DJM+DTsmrMxOvt
# mJBijLUgtXQJs9KuDygnGhX3IySVI81w5lD4DMuE78N/9uUtuG9e1OqlSIB8agQw
# Ff7WdkGKXmX4NNZvlpRGi9GziHWvm0S8A12/uxt3buZ1Iem8tNFtueU9aGNiTyP6
# IovVmMUOdWehdC+c6yF1SogA2okcVr0P2j/3ZGdh7iCzMO3nH9pOgL9lgnfQ+baT
# Ukbf5IUHCeeXEdEy6wxaMiasatlsvq1FBeXwHNj0up9hTQYxaFNUzottetCQ9vhz
# zGlGkm8VaZxgghtygBy6G9dNLGp78+eDCbbr01Di5SNhwDQtlGbYS8KWMNfnR2lA
# 9VIni88+XrVoN3PTxEuOBHEsqgQpbZUH8Pes0b2yqSFFsmI89OalVh/R4ipSV2S2
# IwaTOCuqG8AdbOOuJL8WHAbvZbW3+q2zhz6TRFMjW+0=
# SIG # End signature block
