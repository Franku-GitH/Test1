<#
    The sample scripts provided here are not supported under any Microsoft
    standard support program or service. All scripts are provided AS IS without
    warranty of any kind. Microsoft further disclaims all implied warranties
    including, without limitation, any implied warranties of merchantability or
    of fitness for a particular purpose. The entire risk arising out of the use
    or performance of the sample scripts and documentation remains with you. In
    no event shall Microsoft, its authors, or anyone else involved in the
    creation, production, or delivery of the scripts be liable for any damages
    whatsoever (including, without limitation, damages for loss of business
    profits, business interruption, loss of business information, or other
    pecuniary loss) arising out of the use of or inability to use the sample
    scripts or documentation, even if Microsoft has been advised of the
    possibility of such damages.

    Written by Kip Gumenberg, Microsoft Security CyberOps Resilience, August 1, 2023

    1. Produce OusWithGpoBlockInheritance.CSV with a list of OUs with GPO Block Inheritance set.
    2. Find all GPOs that have one or more DENY User Rights Assignments.
        2.1 Produce a GpoRawData.csv that lists:
            GPO Name, Has Deny URA, Link Status, Link Enabled, Link Enforced, Linked to, Deny URA1 IDs, Deny URA2 IDs, Deny URA3 IDs, Deny URA4 IDs, Deny URA5 IDs, GPO ID, DomainName, Owner, GPOStatus, CreationTime, 
            ModificationTime, UserVersion, ComputerVersion
    3. Produce AllUserRightsAssignments.csv that list all User Rights Assignments for all GPOs linked to the domain along with link order.
    4. Produce GpoPatternMap.csv that lists all unique patterns of the 5 Deny URAs which are compared to existing GPOs that have Deny URAs, that are linked, and the link is enabled anywhere in the domain.  It will contain "Tier 0 Account Restrictions XXX" for each unique pattern.
    5. Produce GpoMasterPlan.csv that lists which embeds the "Tier 0 Account Restrictions XXX" GPO name with the data from step 2 that provides which "Tier 0 Account Restrictions XXX" GPO should be linked to the appropriate locations in the domain as link order 1 on each OU.
    6. Produce SecurityOptions.csv that list all Security Options settings for all GPOs linked to the domain along with link order.
    7. Produce OUPermissions.csv that lists out all the Access Control Entries for every OU.
        7.1 To filter this info down to anyone who can link or modify GPLinks at any OU, follow these instructions:
            1. Open OUPermissions.csv in Excel
            2. Filter top row.
            3. Filter objectTypeName to only select: GP-Link, GP-Options, and (Blanks).
            4. Filter inheritedObjectTypeName to only select: (Blanks).
            5. Filter ActiveDirectoryRights to only: "ReadProperty, WriteProperty", and "GenericAll".
            6. Filter AccessControlType to only: "Allow".
            7. Filter IdentityReference to remove default well-known groups: "Domain Admins", "Enterprise Admins", "NT AUTHORITY\SYSTEM"

            The remaining list will show only custom AD Delegations allowed to link GPOs and modify GPO Links in the entire domain.


#>

param (
    $DomainFQDN,
    [switch]$IncludeMSFTRecommendations,
    [switch]$Debug
)


if ($DomainFQDN -eq $null) {
    write-host "Syntax: .\AnalyzeGPOs.ps1 -DomainFQDN <DomainFQDN> [-IncludeMSFTRecommendations] [-Debug]"
    write-host ""
    write-host "Example:"
    write-host ""
    write-host ".\AnalyzeGPOs.ps1 -DomainFQDN contoso.com -IncludeMSFTRecommendations -Debug"
    Exit
}

$DomainLdap = ""
$Domain = $DomainFQDN
$DomainParts = $Domain -split '\.'
foreach ($Part in $DomainParts) {
    if ($DomainLdap -eq "") {
        $DomainLdap = "DC=" + $Part
    } else {
        $DomainLdap = $DomainLdap + ",DC=" + $Part
    }
}

$FileTime = get-date -format "MM-dd-yyyy-HH-mm"
$ScriptRoot = $PSScriptRoot
$CurFolder = $PSScriptRoot + "\Reports"


$ReportsFolder = $CurFolder + "\Reports"

if ($IncludeMSFTRecommendations.IsPresent -eq $true) {
    write-host "Including Microsoft recommded values for URAs and Security Options." -ForegroundColor Green
}

Import-Module GroupPolicy
import-module ActiveDirectory
Add-Type -AssemblyName System.DirectoryServices


###################
### Hash Tables ###
###################
$dicPreferredDCs = @{}                   # Key = Domain DNS Name,                                             Item = Preferred Domain Controller FQDN
$dicDomainDC = @{}                       # Key = Domain FQDN,                                                 Item = Target DC FQDN
$dic_Patterns = @{}                      # Key = Deny Pattern,                                                Item = GPO GUID
$dic_PatternCount = @{}                  # Key = Deny Pattern,                                                Item = Pattern Count
$dic_GPOGUID = @{}                       # Key = GPO GUID,                                                    Item = Linked GPO Name
$schemaIDGUID = @{}                      # Key = Schema GUID,                                                 Item = Name


###################
### Input Files ###
###################
$PreferredDomainControllersFile = $ScriptRoot + "\PreferredDomainControllers.CSV"

####################
### Output Files ###
####################
$LogFile = $CurFolder + "\" + "Get-Tier0Permissions-$FileTime.LOG"
$GPOInheritance = $CurFolder + "\" + "OUsWithGPOBlockInheritance-" + $Domain + ".csv"
$GPOOutputFile = $CurFolder + "\" + "GpoRawData-" + $Domain + ".csv"
$DcUraOutputFile = $CurFolder + "\" + "AllUserRightsAssignments-" + $Domain + ".csv"
$GPOPatternMapOutputFile = $CurFolder + "\" + "GPOPatternMap-" + $Domain + ".csv"
$GPOMasterOutputFile = $CurFolder + "\" + "GPOMasterPlan-" + $Domain + ".csv"
$SecurityOptionsOutputFile = $CurFolder + "\" + "SecurityOptions-" + $Domain + ".csv"
$OUPermissionFile = $CurFolder + "\" + "OUPermissions-" + $Domain + ".csv"
$CurXml = $CurFolder + "\CurGPO.xml"
$GPOPermissionsFilename = $CurFolder + "\" + "GPOPermissions-" + $Domain + ".csv"
$GPOAuditingFilename = $CurFolder + "\" + "GPOAuditingOptions-" + $Domain + ".csv"
$GPOAdministrativeTemplateValuesFilename = $CurFolder + "\" + "GPOAdminTemplateValues-" + $Domain + ".csv"
$GPORestrictedGroupsFilename = $CurFolder + "\" + "GPORestrictedGroupSettings-" + $Domain + ".csv"
$GPOPreferencesFilename = $CurFolder + "\" + "GPOPreferenceSettings-" + $Domain + ".csv"
$GPOsWithPasswordsFilename = $CurFolder + "\" + "GPOsWithPasswords-" + $Domain + ".csv"


$LineOut = '"OUs with Block Inheritance"'
Set-Content -Path $GPOInheritance -Value $LineOut -Encoding Unicode
$LineOut = '"GPO_Name","Has_Deny_URA","Linked","Link_Enabled","Link_Enforced","Linked_To","Deny_access_to_this_computer_from_the_network","Deny_log_on_as_a_batch_job","Deny_Log_on_as_a_service","Deny_log_on_locally","Deny_log_on_through_terminal_services","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version"'
Set-Content -Path $GPOOutputFile -Value $LineOut -Encoding Unicode
$LineOut = '"Link Order","GPO Name","Linked","Link Enabled","Link Enforced","Linked To","Access Credential Manager as a trusted caller","Access this computer from the network","Act as part of the operating system","Add workstations to domain","Adjust memory quotas for a process","Allow log on locally","Allow log on through Remote Desktop Services","Back up files and directories","Bypass traverse checking","Change the system time","Change the time zone","Create a pagefile","Create a token object","Create global objects","Create permanent shared objects","Create symbolic links","Debug programs","Deny access to this computer from the network","Deny log on as a batch job","Deny log on as a service","Deny log on locally","Deny log on through Remote Desktop Services","Enable computer and user accounts to be trusted for delegation","Force shutdown from a remote system","Generate security audits","Impersonate a client after authentication","Increase a process working set","Increase scheduling priority","Load and unload device drivers","Lock pages in memory","Log on as a batch job","Log on as a service","Manage auditing and security log","Modify an object label","Modify firmware environment values","Obtain an impersonation token for another user in the same session","Perform volume maintenance tasks","Profile single process","Profile system performance","Remove computer from docking station","Replace a process level token","Restore files and directories","Shut down the system","Synchronize directory service data","Take ownership of files or other objects","GPO GUID","Domain","Owner","GPO Status","Creation Time","Modification Time","User Version","Computer Version"'
Set-Content -Path $DcUraOutputFile -Value $LineOut -Encoding Unicode
$LineOut = '"GPO_Name","Deny_access_to_this_computer_from_the_network","Deny_log_on_as_a_batch_job","Deny_log_on_as_a_service","Deny_log_on_locally","Deny_log_on_through_terminal_services","GPO_GUIDs"'
Set-Content -Path $GPOPatternMapOutputFile -Value $LineOut -Encoding Unicode
$LineOut = '"GPO_Name","Has_Deny_URA","Linked","Link_Enabled","Link_Enforced","Linked_To","Deny_access_to_this_computer_from_the_network","Deny_log_on_as_a_batch_job","Deny_Log_on_as_a_service","Deny_log_on_locally","Deny_log_on_through_terminal_services","GPO_Pattern_Name","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version"'
Set-Content -Path $GPOMasterOutputFile -Value $LineOut -Encoding Unicode
$LineOut = '"LinkOrder","GPO_Name","Linked","Link_Enabled","Link_Enforced","Linked_To","KeyName","Setting","DisplayName","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version"'
Set-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode

$LineOut = '"LinkOrder","GPO_Name","Linked","Link_Enabled","Link_Enforced","Linked_To","PolicyTarget","SubcategoryName","SubcategoryGuid","SettingValue","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version"'
Set-Content -Path $GPOAuditingFilename -Value $LineOut -Encoding Unicode

$LineOut = '"LinkOrder","GPO_Name","Linked","Link_Enabled","Link_Enforced","Linked_To","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version","Name","State","Supported","Category","Name2","State2","Name3"'
Set-Content -Path $GPOAdministrativeTemplateValuesFilename -Value $LineOut -Encoding Unicode

$LineOut = '"LinkOrder","GPO_Name","Linked","Link_Enabled","Link_Enforced","Linked_To","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version","GroupName","GroupSID","MemberName","MemberSID"'
Set-Content -Path $GPORestrictedGroupsFilename -Value $LineOut -Encoding Unicode

$LineOut = '"LinkOrder","GPO_Name","Linked","Link_Enabled","Link_Enforced","Linked_To","GPO_GUID","Domain","Owner","GPO_Status","Creation_Time","Modification_Time","User_Version","Computer_Version","GroupName","GroupAction","GroupNewName","GroupDescription","GroupDeleteAllUsers","GroupDeleteAllGroups","GroupRemoveAccounts","MemberName","MemberAction","MemberSID"'
Set-Content -Path $GPOPreferencesFilename -Value $LineOut -Encoding Unicode

$LineOut = '"GPOName","Filename","Matches"'
Set-Content -Path $GPOsWithPasswordsFilename -Value $LineOut -Encoding Unicode

$LineOut = '"GPOName","IdentityReference","ActiveDirectoryRights","GPODistinguishedName"'
Set-Content -Path $GPOPermissionsFilename -Value $LineOut -Encoding Unicode


#################
### Write Log ###
#################
Function WriteLog
{
    param (
        $LineIn,
        $WriteToScreen,
        $Color
    )

    $CurTime =  get-date -UFormat "%m/%d/%Y %T"
    $LineOut = "$CurTime $LineIn"

    if ($WriteToScreen -eq $true)
    {
        if ($Color)
        {
            write-host $LineIn -ForegroundColor $Color
        } else {
            write-host $LineIn
        }
    }
    if ($DebugFlag -eq "on") {
        Add-Content -Path $LogFile -Value $LineOut -Encoding Unicode
    }
}


####################################################
### Determine If Preferred DCs Have Been Defined ###
####################################################
Function DetermineIfPreferredDCsHaveBeenDefined
{
    WriteLog ""
    WriteLog "####################################################"
    WriteLog "### Determine If Preferred DCs Have Been Defined ###"
    WriteLog "####################################################"

    WriteLog "Checking for entries in $PreferredDomainControllersFile" $true
    $CSV = Import-Csv $PreferredDomainControllersFile
    foreach ($Row in $CSV)
    {    
        $DomainControllerFQDN = $Row.PreferredDomainControllerFQDN

        $Index = $DomainControllerFQDN.IndexOf(".")
        $Length = $DomainControllerFQDN.Length

        $DCDomain = $DomainControllerFQDN.Substring($Index+1,$Length-($Index+1))
        if ($dicPreferredDCs.ContainsKey($DCDomain) -eq $false)
        {
            $dicPreferredDCs.Add($DCDomain,$DomainControllerFQDN)
        }

        WriteLog "Preferred Domain Controller for $DCDomain found: $DomainControllerFQDN" $true Green
    }
    $PrefDCCount = $dicPreferredDCs.Count
    WriteLog "Number of Preferred Domain Controllers Found: $PrefDCCount" $true

}

######################
### Get Closest DC ###
######################
Function GetClosestDC
{
    param 
    (
        $TargetDomain
    )
    writeLog ""
    WriteLog "######################"
    WriteLog "### Get Closest DC ###"
    WriteLog "######################"
    WriteLog "GetClosestDC: $TargetDomain"

    if ($dicPreferredDCs.ContainsKey($TargetDomain) -eq $true)
    {
        $ClosestDC = $dicPreferredDCs.$TargetDomain
        WriteLog "Using preffered DC: $ClosestDC"
        if ($dicDomainDC.ContainsKey($TargetDomain) -eq $false)
        {
            $dicDomainDC.add($TargetDomain,$ClosestDC)
        }
    } else {
        if ($dicDomainDC.ContainsKey($TargetDomain) -eq $true)
        {
            $ClosestDC = $dicDomainDC.$TargetDomain
            WriteLog "Using cached DC $ClosestDC for Domain: $TargetDomain" 
       
        } else {
        
            WriteLog "Discovering Domain Controller for domain: $TargetDomain"
            $DCObj = Get-ADDomainController -Discover -Domain $TargetDomain -ErrorAction SilentlyContinue
            if ($DCObj)
            {
                $ClosestDC = [string]$DCObj.HostName
                $dicDomainDC.Add($TargetDomain,$ClosestDC)
                WriteLog "Using discovered DC: $ClosestDC"
            } else {
                WriteLog "The following error occured trying to discover a DC in $TargetDomain : $Error"
            }
        }
    }
    WriteLog ""

    return $ClosestDC
}




##########################################
### Get OUs with GPO Block Inheritance ###
##########################################
Function GetOUsWithGPOBlockInheritance
{
    WriteLog "OUs with block inheritance:" $True "Green"
    $OUsBlocked = Get-ADOrganizationalUnit -Filter * -SearchBase $DomainLdap -Server $Server | Get-GPInheritance | Where-Object {$_.GPOInheritanceBlocked} | select-object Path 
    foreach ($OU in $OUsBlocked) {
        $LineOut = '"' + $OU.Path + '"'
        Add-Content -Path $GPOInheritance -Value $LineOut -Encoding Unicode
    }
    WriteLog "-->OUs with GPO Block Inheritance written to $GPOInheritance." $True "Yellow"
}

####################
### Get All GPOs ###
####################
Function GetAllGPOs
{
    WriteLog "Retrieving a list of all GPOs in the domain." $true "Green"

    $AllGPOs = get-GPO -all -Domain $Domain

    foreach ($GPO in $allGpOs) {

        $ID = $GPO.ID
        $DisplayName = $GPO.DisplayName
        $DomainName = $GPO.DomainName
        $Owner = $GPO.Owner
        $GpoStatus = $GPO.GpoStatus
        $CreationTime = $GPO.CreationTime
        $ModificationTime = $GPO.ModificationTime
        $UserVersion = "AD Version: " + $GPO.User.DSVersion + ", Sysvol Version: " + $GPO.User.SysvolVersion
        $ComputerVersion = "AD Version: " + $GPO.Computer.DSVersion + ", Sysvol Version: " + $GPO.Computer.SysvolVersion
        $WmiFilter = $GPO.WmiFilter
        $Description = $GPO.Description

        WriteLog "-->Processing: $ID $DisplayName" $True "Yellow"

        get-gporeport -guid $ID -ReportType xml -path $CurXml -Domain $Domain
        [xml]$CurGPO = Get-Content -Path $CurXml

        $SeDenyBatchLogonRight = "<not set>"
        $SeDenyInteractiveLogonRight = "<not set>"
        $SeDenyNetworkLogonRight = "<not set>"
        $SeDenyRemoteInteractiveLogonRight = "<not set>"
        $SeDenyServiceLogonRight = "<not set>"
        $HasDenyUra = "FALSE"
        foreach ($URA in $CurGPO.GPO.Computer.ExtensionData.Extension.UserRightsAssignment) {
    
            $URAName = $URA.Name

            If ($URAName -eq "SeDenyBatchLogonRight" -or $URAName -eq "SeDenyInteractiveLogonRight" -or $URAName -eq "SeDenyNetworkLogonRight" -or $URAName -eq "SeDenyRemoteInteractiveLogonRight" -or $URAName -eq "SeDenyServiceLogonRight") {
                $HasDenyUra = "TRUE"
                $Members = ""

                foreach ($Member in $URA.Member.Name) {
                    If ($Members -eq "") {
                        $Members = $Member.InnerXML
                    } else {
                        $Members = $Members + ", " + $Member.InnerXML
                    }
                }

                $SortedMembers = $Members -split '\, ' | Sort-Object
                $MembersOut = ""
                foreach ($Member in $SortedMembers) {
                    If ($MembersOut -eq "") {
                        $MembersOut = $Member
                    } else {
                        $MembersOut = $MembersOut + ", " + $Member
                    }
                }

                if ($URAName -eq "SeDenyBatchLogonRight") {
                    $SeDenyBatchLogonRight = $MembersOut
                }
                if ($URAName -eq "SeDenyInteractiveLogonRight") {
                    $SeDenyInteractiveLogonRight = $MembersOut
                }
                if ($URAName -eq "SeDenyNetworkLogonRight") {
                    $SeDenyNetworkLogonRight = $MembersOut
                }
                if ($URAName -eq "SeDenyRemoteInteractiveLogonRight") {
                    $SeDenyRemoteInteractiveLogonRight = $MembersOut
                }
                if ($URAName -eq "SeDenyServiceLogonRight") {
                    $SeDenyServiceLogonRight = $MembersOut
                }
            }
        }

        $IsLinked = "FALSE"
        foreach ($Link in $CurGPO.GPO.LinksTo) {
            $IsLinked = "TRUE"
        }

        If ($IsLinked -eq "TRUE") {
            foreach ($Link in $CurGPO.GPO.LinksTo) {

                $LinkTo = $Link.SOMPath
                $LinkEnabled = $Link.Enabled
                $LinkEnforced = $Link.NoOverride

                $LineOut = '"' + $DisplayName + '",'`
                           + '"' + $HasDenyUra  + '",'`
                           + '"' + $IsLinked  + '",'`
                           + '"' + $LinkEnabled  + '",'`
                           + '"' + $LinkEnforced  + '",'`
                           + '"' + $LinkTo  + '",'`
                           + '"' + $SeDenyNetworkLogonRight  + '",'`
                           + '"' + $SeDenyBatchLogonRight  + '",'`
                           + '"' + $SeDenyServiceLogonRight  + '",'`
                           + '"' + $SeDenyInteractiveLogonRight  + '",'`
                           + '"' + $SeDenyRemoteInteractiveLogonRight  + '",'`
                           + '"' + $ID  + '",'`
                           + '"' + $DomainName  + '",'`
                           + '"' + $Owner  + '",'`
                           + '"' + $GpoStatus  + '",'`
                           + '"' + $CreationTime  + '",'`
                           + '"' + $ModificationTime  + '",'`
                           + '"' + $UserVersion  + '",'`
                           + '"' + $ComputerVersion  + '"'

                Add-Content -Path $GPOOutputFile -Value $LineOut -Encoding Unicode

            }
        } else {
            $LineOut = '"' + $DisplayName + '",'`
                       + '"' + $HasDenyUra  + '",'`
                       + '"' + $IsLinked  + '",'`
                       + '"FALSE",'`
                       + '"FALSE",'`
                       + '"n/a",'`
                       + '"' + $SeDenyNetworkLogonRight  + '",'`
                       + '"' + $SeDenyBatchLogonRight  + '",'`
                       + '"' + $SeDenyServiceLogonRight  + '",'`
                       + '"' + $SeDenyInteractiveLogonRight  + '",'`
                       + '"' + $SeDenyRemoteInteractiveLogonRight  + '",'`
                       + '"' + $ID  + '",'`
                       + '"' + $DomainName  + '",'`
                       + '"' + $Owner  + '",'`
                       + '"' + $GpoStatus  + '",'`
                       + '"' + $CreationTime  + '",'`
                       + '"' + $ModificationTime  + '",'`
                       + '"' + $UserVersion  + '",'`
                       + '"' + $ComputerVersion  + '"'

            Add-Content -Path $GPOOutputFile -Value $LineOut -Encoding Unicode
        }
    }
    WriteLog "-->GPO Output file written to $GPOOutputFile" $True "Yellow"
}

#######################################################
### Get All URAs and Security Options for every GPO ###
#######################################################
Function GetAllURAsAndSecurityOptionsForEveryGPO
{
    WriteLog "Getting All URAs and Security Options for all GPOs." $True "Green"

    $OUs = Get-ADOrganizationalUnit -Server $Server -filter *

    if ($IncludeMSFTRecommendations.IsPresent -eq $true) {

                $LineOut = '"0",'`
                        + '"Microsoft Recommendations for URAs linked to OU=Domain Controllers",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"<blank>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\Authenticated Users, NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"BUILTIN\Administrators",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<blank>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\LOCAL SERVICE, NT AUTHORITY\NETWORK SERVICE, NT AUTHORITY\SERVICE",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\LOCAL SERVICE, NT AUTHORITY\NETWORK SERVICE, NT AUTHORITY\SERVICE",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a"'

                Add-Content -Path $DcUraOutputFile -Value $LineOut -Encoding Unicode

                $LineOut = '"0",'`
                        + '"Microsoft Recommendations for URAs linked to Tier 0 PAWs",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"<blank>",'`
                        + '"BUITIN\Administrators, BUILTIN\Remote Desktop Users",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators, BUILTIN\Users",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<blank>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\LOCAL SERVICE, NT AUTHORITY\NETWORK SERVICE, NT AUTHORITY\SERVICE",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"NT AUTHORITY\Local account",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"NT AUTHORITY\Local account",'`
                        + '"<blank>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\LOCAL SERVICE, NT AUTHORITY\NETWORK SERVICE, NT AUTHORITY\SERVICE",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a"'

                Add-Content -Path $DcUraOutputFile -Value $LineOut -Encoding Unicode

                $LineOut = '"0",'`
                        + '"Microsoft Recommendations for URAs linked to Tier 0 Member Servers",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"<blank>",'`
                        + '"BUITIN\Administrators, NT Authority\Authenticated Users",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<blank>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\LOCAL SERVICE, NT AUTHORITY\NETWORK SERVICE, NT AUTHORITY\SERVICE",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"NT AUTHORITY\Local account and member of Administrators group",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"NT AUTHORITY\Local account",'`
                        + '"<blank>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators, NT AUTHORITY\LOCAL SERVICE, NT AUTHORITY\NETWORK SERVICE, NT AUTHORITY\SERVICE",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<blank>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"<not set>",'`
                        + '"<not set>",'`
                        + '"BUILTIN\Administrators",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a",'`
                        + '"n/a"'

                Add-Content -Path $DcUraOutputFile -Value $LineOut -Encoding Unicode

                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\ScRemoveOption","1","Interactive logon: Smart card removal behavior","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin","2","User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorUser","0","User Account Control: Behavior of the elevation prompt for standard users","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableInstallerDetection","1","User Account Control: Detect application installations and prompt for elevation","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA","1","User Account Control: Run all administrators in Admin Approval Mode","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableSecureUIAPaths","1","User Account Control: Only elevate UIAccess applications that are installed in secure locations","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableVirtualization","1","User Account Control: Virtualize file and registry write failures to per-user locations","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\FilterAdministratorToken","1","User Account Control: Admin Approval Mode for the Built-in Administrator account","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\InactivityTimeoutSecs","900","Interactive logon: Machine inactivity limit","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\LimitBlankPasswordUse","1","Accounts: Limit local account use of blank passwords to console logon only","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers (Risky setting)","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\LmCompatibilityLevel","5","Network security: LAN Manager authentication level","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\allownullsessionfallback","0","Network security: Allow LocalSystem NULL session fallback","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinClientSec","537395200","Network security: Minimum session security for NTLM SSP based (including secure RPC) clients","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinServerSec","537395200","Network security: Minimum session security for NTLM SSP based (including secure RPC) servers","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\NoLMHash","1","Network security: Do not store LAN Manager hash value on next password change","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymous","1","Network access: Do not allow anonymous enumeration of SAM accounts and shares","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Doma -Encoding Unicodein Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymousSAM","1","Network access: Do not allow anonymous enumeration of SAM accounts","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy","1","Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Session Manager\ProtectionMode","1","System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters\requiresecuritysignature","1","Microsoft network server: Digitally sign communications (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters\RestrictNullSessAccess","1","Network access: Restrict anonymous access to Named Pipes and Shares","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\EnablePlainTextPassword","0","Microsoft network client: Send unencrypted password to third-party SMB servers","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\RequireSecuritySignature","1","Microsoft network client: Digitally sign communications (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LDAP\LDAPClientIntegrity","1","Network security: LDAP client signing requirements","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\requiresignorseal","1","Domain member: Digitally encrypt or sign secure channel data (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\requirestrongkey","1","Domain member: Require strong (Windows 2000 or later) session key","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\sealsecurechannel","1","Domain member: Digitally encrypt secure channel data (when possible)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\signsecurechannel","1","Domain member: Digitally sign secure channel data (when possible)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers (Risky setting)","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\NTDS\Parameters\LdapEnforceChannelBinding","2","Domain controller: LDAP server channel binding token requirements","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers (Risky setting)","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\NTDS\Parameters\LDAPServerIntegrity","2","Domain controller: LDAP server signing requirements","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Domain Controllers","n/a","n/a","n/a","n/a","LSAAnonymousNameLookup","0","Network access: Allow anonymous SID/Name translation","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode


                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\ScRemoveOption","1","Interactive logon: Smart card removal behavior","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin","2","User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorUser","0","User Account Control: Behavior of the elevation prompt for standard users","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableInstallerDetection","1","User Account Control: Detect application installations and prompt for elevation","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA","1","User Account Control: Run all administrators in Admin Approval Mode","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableSecureUIAPaths","1","User Account Control: Only elevate UIAccess applications that are installed in secure locations","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableVirtualization","1","User Account Control: Virtualize file and registry write failures to per-user locations","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\FilterAdministratorToken","1","User Account Control: Admin Approval Mode for the Built-in Administrator account","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\InactivityTimeoutSecs","900","Interactive logon: Machine inactivity limit","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\LimitBlankPasswordUse","1","Accounts: Limit local account use of blank passwords to console logon only","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs (Risky setting)","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\LmCompatibilityLevel","5","Network security: LAN Manager authentication level","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\allownullsessionfallback","0","Network security: Allow LocalSystem NULL session fallback","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinClientSec","537395200","Network security: Minimum session security for NTLM SSP based (including secure RPC) clients","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinServerSec","537395200","Network security: Minimum session security for NTLM SSP based (including secure RPC) servers","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\NoLMHash","1","Network security: Do not store LAN Manager hash value on next password change","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymous","1","Network access: Do not allow anonymous enumeration of SAM accounts and shares","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymousSAM","1","Network access: Do not allow anonymous enumeration of SAM accounts","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictRemoteSAM","O:BAG:BAD:(A;;RC;;;BA)","Network access: Restrict clients allowed to make remote calls to SAM","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy","1","Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Session Manager\ProtectionMode","1","System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters\requiresecuritysignature","1","Microsoft network server: Digitally sign communications (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters\RestrictNullSessAccess","1","Network access: Restrict anonymous access to Named Pipes and Shares","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\EnablePlainTextPassword","0","Microsoft network client: Send unencrypted password to third-party SMB servers","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\RequireSecuritySignature","1","Microsoft network client: Digitally sign communications (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LDAP\LDAPClientIntegrity","1","Network security: LDAP client signing requirements","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\requiresignorseal","1","Domain member: Digitally encrypt or sign secure channel data (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\requirestrongkey","1","Domain member: Require strong (Windows 2000 or later) session key","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\sealsecurechannel","1","Domain member: Digitally encrypt secure channel data (when possible)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\signsecurechannel","1","Domain member: Digitally sign secure channel data (when possible)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 PAWs","n/a","n/a","n/a","n/a","LSAAnonymousNameLookup","1","LSAAnonymousNameLookup","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode


                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\ScRemoveOption","1","Interactive logon: Smart card removal behavior","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorAdmin","2","User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\ConsentPromptBehaviorUser","0","User Account Control: Behavior of the elevation prompt for standard users","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableInstallerDetection","1","User Account Control: Detect application installations and prompt for elevation","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableLUA","1","User Account Control: Run all administrators in Admin Approval Mode","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableSecureUIAPaths","1","User Account Control: Only elevate UIAccess applications that are installed in secure locations","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\EnableVirtualization","1","User Account Control: Virtualize file and registry write failures to per-user locations","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\FilterAdministratorToken","1","User Account Control: Admin Approval Mode for the Built-in Administrator account","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System\InactivityTimeoutSecs","900","Interactive logon: Machine inactivity limit","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\LimitBlankPasswordUse","1","Accounts: Limit local account use of blank passwords to console logon only","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers (Risky setting)","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\LmCompatibilityLevel","5","Network security: LAN Manager authentication level","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\allownullsessionfallback","0","Network security: Allow LocalSystem NULL session fallback","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinClientSec","537395200","Network security: Minimum session security for NTLM SSP based (including secure RPC) clients","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\MSV1_0\NTLMMinServerSec","537395200","Network security: Minimum session security for NTLM SSP based (including secure RPC) servers","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\NoLMHash","1","Network security: Do not store LAN Manager hash value on next password change","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymous","1","Network access: Do not allow anonymous enumeration of SAM accounts and shares","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictAnonymousSAM","1","Network access: Do not allow anonymous enumeration of SAM accounts","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\RestrictRemoteSAM","O:BAG:BAD:(A;;RC;;;BA)","Network access: Restrict clients allowed to make remote calls to SAM","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy","1","Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Control\Session Manager\ProtectionMode","1","System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters\requiresecuritysignature","1","Microsoft network server: Digitally sign communications (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters\RestrictNullSessAccess","1","Network access: Restrict anonymous access to Named Pipes and Shares","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\EnablePlainTextPassword","0","Microsoft network client: Send unencrypted password to third-party SMB servers","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LanmanWorkstation\Parameters\RequireSecuritySignature","1","Microsoft network client: Digitally sign communications (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\LDAP\LDAPClientIntegrity","1","Network security: LDAP client signing requirements","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\requiresignorseal","1","Domain member: Digitally encrypt or sign secure channel data (always)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\requirestrongkey","1","Domain member: Require strong (Windows 2000 or later) session key","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\sealsecurechannel","1","Domain member: Digitally encrypt secure channel data (when possible)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters\signsecurechannel","1","Domain member: Digitally sign secure channel data (when possible)","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","ForceLogoffWhenHourExpire","1","ForceLogoffWhenHourExpire","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                $LineOut = '"0","Microsoft Recommended Security Options for Tier 0 Member Servers","n/a","n/a","n/a","n/a","LSAAnonymousNameLookup","1","LSAAnonymousNameLookup","n/a","n/a","n/a","n/a","n/a","n/a","n/a","n/a"'
                Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode


    }


    foreach ($OU in $OUs) {

        $Gpos = $OU.LinkedGroupPolicyObjects
        $LinkCount = $Gpos.Count
        Foreach ($Gpo in $Gpos) 
        {
            $LinkOrder = $LinkCount

            $LinkCount = $LinkCount - 1

            $GpoParts = $Gpo -split '\}'
            $GpoParts2 = $GpoParts[0] -split '\{'
            $GpoGuid = $GpoParts2[1]

            $AllGPOs = get-GPO -Guid $GpoGuid -Domain $Domain

            foreach ($GPO in $allGpOs) {

                $ID = $GPO.ID
                $DisplayName = $GPO.DisplayName
                $DomainName = $GPO.DomainName
                $Owner = $GPO.Owner
                $GpoStatus = $GPO.GpoStatus
                $CreationTime = $GPO.CreationTime
                $ModificationTime = $GPO.ModificationTime
                $UserVersion = "AD Version: " + $GPO.User.DSVersion + ", Sysvol Version: " + $GPO.User.SysvolVersion
                $ComputerVersion = "AD Version: " + $GPO.Computer.DSVersion + ", Sysvol Version: " + $GPO.Computer.SysvolVersion
                $WmiFilter = $GPO.WmiFilter
                $Description = $GPO.Description

                WriteLog "-->Processing: $ID $DisplayName" $true "Yellow"

                get-gporeport -guid $ID -ReportType xml -path $CurXml -Domain $Domain
                [xml]$CurGPO = Get-Content -Path $CurXml

                $SeTrustedCredManAccessPrivilege = "<not set>"              #Access Credential Manager as a trusted caller
                $SeNetworkLogonRight = "<not set>"                          #Access this computer from the network
                $SeTcbPrivilege = "<not set>"                               #Act as part of the operating system
                $SeMachineAccountPrivilege = "<not set>"                    #Add workstations to the domain
                $SeIncreaseQuotaPrivilege = "<not set>"                     #Adjust memory quotas for a process
                $SeInteractiveLogonRight = "<not set>"                      #Allow log on locally
                $SeRemoteInteractiveLogonRight = "<not set>"                #Allow log on through Remote Desktop Services
                $SeBackupPrivilege = "<not set>"                            #Backup up files and directories
                $SeChangeNotifyPrivilege = "<not set>"                      #Bypass traverse checking
                $SeSystemTimePrivilege = "<not set>"                        #Change the system time        
                $SeTimeZonePrivilege = "<not set>"                          #Change the time zone
                $SeCreatePagefilePrivilege = "<not set>"                    #Create a pagefile
                $SeCreateTokenPrivilege = "<not set>"                       #Create a token object
                $SeCreateGlobalPrivilege = "<not set>"                      #Create global objects
                $SeCreatePermanentPrivilege = "<not set>"                   #Create permanent shared objects
                $SeCreateSymbolicLinkPrivilege = "<not set>"                #Create symbolic links
                $SeDebugPrivilege = "<not set>"                             #Debug programs
                $SeDenyNetworkLogonRight = "<not set>"                      #Deny access to this computer from the network
                $SeDenyBatchLogonRight = "<not set>"                        #Deny log on as a batch job
                $SeDenyServiceLogonRight = "<not set>"                      #Deny log on as a service
                $SeDenyInteractiveLogonRight = "<not set>"                  #Deny log on locally
                $SeDenyRemoteInteractiveLogonRight = "<not set>"            #Deny log on through Remote Desktop Services
                $SeEnableDelegationPrivilege = "<not set>"                  #Enable computer and user accounts to be trusted for delegation
                $SeRemoteShutdownPrivilege = "<not set>"                    #Force shutdown from a remote system
                $SeAuditPrivilege = "<not set>"                             #Generate Security Audits
                $SeImpersonatePrivilege = "<not set>"                       #Impersonate a client after authentication
                $SeIncreaseWorkingSetPrivilege = "<not set>"                #Increase a process working set
                $SeIncreaseBasePriorityPrivilege = "<not set>"              #Increase scheduling priority
                $SeLoadDriverPrivilege = "<not set>"                        #Load and unload device drivers
                $SeLockMemoryPrivilege = "<not set>"                        #Lock pages in memory
                $SeBatchLogonRight = "<not set>"                            #Log on as a batch job
                $SeServiceLogonRight = "<not set>"                          #Log on as a service
                $SeSecurityPrivilege = "<not set>"                          #Manage auditing and security log
                $SeRelabelPrivilege = "<not set>"                           #Modify an object label
                $SeSystemEnvironmentPrivilege = "<not set>"                 #Modify firmware environment values
                $SeDelegateSessionUserImpersonatePrivilege = "<not set>"    #Obtain an impersonation token for another user in the same session
                $SeManageVolumePrivilege = "<not set>"                      #Perform volume maintenance tasks
                $SeProfileSingleProcessPrivilege = "<not set>"              #Profile single process
                $SeSystemProfilePrivilege = "<not set>"                     #Profile system performance
                $SeUndockPrivilege = "<not set>"                            #Remove computer from docking station
                $SeAssignPrimaryTokenPrivilege = "<not set>"                #Replace a process Level Token
                $SeRestorePrivilege = "<not set>"                           #Restore files and directories
                $SeShutdownPrivilege = "<not set>"                          #Shut down the system
                $SeSyncAgentPrivilege = "<not set>"                         #Synchronize directory service data
                $SeTakeOwnershipPrivilege = "<not set>"                     #Take ownership of files or other objects

                $HasDenyUra = "FALSE"

                foreach ($URA in $CurGPO.GPO.Computer.ExtensionData.Extension.UserRightsAssignment) {
    
                    $URAName = $URA.Name

                    $Members = ""

                    foreach ($Member in $URA.Member.Name) {
                        If ($Members -eq "") {
                            $Members = $Member.InnerXML
                        } else {
                            $Members = $Members + ", " + $Member.InnerXML
                        }
                    }

                    $SortedMembers = $Members -split '\, ' | Sort-Object
                    $MembersOut = ""
                    foreach ($Member in $SortedMembers) {
                        If ($MembersOut -eq "") {
                            $MembersOut = $Member
                        } else {
                            $MembersOut = $MembersOut + ", " + $Member
                        }
                    }

                    if ($URAName -eq "SeTrustedCredManAccessPrivilege") {$SeTrustedCredManAccessPrivilege = $MembersOut}
                    if ($URAName -eq "SeNetworkLogonRight") {$SeNetworkLogonRight = $MembersOut}
                    if ($URAName -eq "SeTcbPrivilege") {$SeTcbPrivilege = $MembersOut}
                    if ($URAName -eq "SeMachineAccountPrivilege") {$SeMachineAccountPrivilege = $MembersOut}
                    if ($URAName -eq "SeIncreaseQuotaPrivilege") {$SeIncreaseQuotaPrivilege = $MembersOut}
                    if ($URAName -eq "SeInteractiveLogonRight") {$SeInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeRemoteInteractiveLogonRight") {$SeRemoteInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeBackupPrivilege") {$SeBackupPrivilege = $MembersOut}
                    if ($URAName -eq "SeChangeNotifyPrivilege") {$SeChangeNotifyPrivilege = $MembersOut}
                    if ($URAName -eq "SeSystemtimePrivilege") {$SeSystemtimePrivilege = $MembersOut}
                    if ($URAName -eq "SeTimeZonePrivilege") {$SeTimeZonePrivilege = $MembersOut}
                    if ($URAName -eq "SeCreatePagefilePrivilege") {$SeCreatePagefilePrivilege = $MembersOut}
                    if ($URAName -eq "SeCreateTokenPrivilege") {$SeCreateTokenPrivilege = $MembersOut}
                    if ($URAName -eq "SeCreateGlobalPrivilege") {$SeCreateGlobalPrivilege = $MembersOut}
                    if ($URAName -eq "SeCreatePermanentPrivilege") {$SeCreatePermanentPrivilege = $MembersOut}
                    if ($URAName -eq "SeCreateSymbolicLinkPrivilege") {$SeCreateSymbolicLinkPrivilege = $MembersOut}
                    if ($URAName -eq "SeDebugPrivilege") {$SeDebugPrivilege = $MembersOut}
                    if ($URAName -eq "SeDenyNetworkLogonRight") {$SeDenyNetworkLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyBatchLogonRight") {$SeDenyBatchLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyServiceLogonRight") {$SeDenyServiceLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyInteractiveLogonRight") {$SeDenyInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyRemoteInteractiveLogonRight") {$SeDenyRemoteInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeEnableDelegationPrivilege") {$SeEnableDelegationPrivilege = $MembersOut}
                    if ($URAName -eq "SeRemoteShutdownPrivilege") {$SeRemoteShutdownPrivilege = $MembersOut}
                    if ($URAName -eq "SeAuditPrivilege") {$SeAuditPrivilege = $MembersOut}
                    if ($URAName -eq "SeImpersonatePrivilege") {$SeImpersonatePrivilege = $MembersOut}
                    if ($URAName -eq "SeIncreaseWorkingSetPrivilege") {$SeIncreaseWorkingSetPrivilege = $MembersOut}
                    if ($URAName -eq "SeIncreaseBasePriorityPrivilege") {$SeIncreaseBasePriorityPrivilege = $MembersOut}
                    if ($URAName -eq "SeLoadDriverPrivilege") {$SeLoadDriverPrivilege = $MembersOut}
                    if ($URAName -eq "SeLockMemoryPrivilege") {$SeLockMemoryPrivilege = $MembersOut}
                    if ($URAName -eq "SeBatchLogonRight") {$SeBatchLogonRight = $MembersOut}
                    if ($URAName -eq "SeServiceLogonRight") {$SeServiceLogonRight = $MembersOut}
                    if ($URAName -eq "SeSecurityPrivilege") {$SeSecurityPrivilege = $MembersOut}
                    if ($URAName -eq "SeRelabelPrivilege") {$SeRelabelPrivilege = $MembersOut}
                    if ($URAName -eq "SeSystemEnvironmentPrivilege") {$SeSystemEnvironmentPrivilege = $MembersOut}
                    if ($URAName -eq "SeDelegateSessionUserImpersonatePrivilege") {$SeDelegateSessionUserImpersonatePrivilege = $MembersOut}
                    if ($URAName -eq "SeManageVolumePrivilege") {$SeManageVolumePrivilege = $MembersOut}
                    if ($URAName -eq "SeProfileSingleProcessPrivilege") {$SeProfileSingleProcessPrivilege = $MembersOut}
                    if ($URAName -eq "SeSystemProfilePrivilege") {$SeSystemProfilePrivilege = $MembersOut}
                    if ($URAName -eq "SeUndockPrivilege") {$SeUndockPrivilege = $MembersOut}
                    if ($URAName -eq "SeAssignPrimaryTokenPrivilege") {$SeAssignPrimaryTokenPrivilege = $MembersOut}
                    if ($URAName -eq "SeRestorePrivilege") {$SeRestorePrivilege = $MembersOut}
                    if ($URAName -eq "SeShutdownPrivilege") {$SeShutdownPrivilege = $MembersOut}
                    if ($URAName -eq "SeSyncAgentPrivilege") {$SeSyncAgentPrivilege = $MembersOut}
                    if ($URAName -eq "SeTakeOwnershipPrivilege") {$SeTakeOwnershipPrivilege = $MembersOut}
                }

                $IsLinked = $true
                $LinkedTo = $OU.DistinguishedName
                $OUName = $OU.Name

                foreach ($Link in $CurGPO.GPO.LinksTo) {
                    $LinkTo = $Link.SOMPath
                    if ($LinkTo.Contains("/") -eq $true)
                    {
                        If ($LinkTo.Contains("/"+ $OUName) -eq $true) {
                            $LinkEnabled = $Link.Enabled
                            $LinkEnforced = $Link.NoOverride
                            $LinkToOut = $Link.SOMPath
                        }
                    } else {
                        If ($LinkTo.Contains($OUName) -eq $true) {
                            $LinkEnabled = $Link.Enabled
                            $LinkEnforced = $Link.NoOverride
                            $LinkToOut = $Link.SOMPath
                        }
                    }
                }

                $LineOut = '"' + $LinkOrder + '",'`
                        + '"' + $DisplayName  + '",'`
                        + '"' + $IsLinked  + '",'`
                        + '"' + $LinkEnabled  + '",'`
                        + '"' + $LinkEnforced  + '",'`
                        + '"' + $LinkToOut  + '",'`
                        + '"' + $SeTrustedCredManAccessPrivilege  + '",'`
                        + '"' + $SeNetworkLogonRight  + '",'`
                        + '"' + $SeTcbPrivilege  + '",'`
                        + '"' + $SeMachineAccountPrivilege  + '",'`
                        + '"' + $SeIncreaseQuotaPrivilege  + '",'`
                        + '"' + $SeInteractiveLogonRight  + '",'`
                        + '"' + $SeRemoteInteractiveLogonRight  + '",'`
                        + '"' + $SeBackupPrivilege  + '",'`
                        + '"' + $SeChangeNotifyPrivilege  + '",'`
                        + '"' + $SeSystemtimePrivilege  + '",'`
                        + '"' + $SeTimeZonePrivilege  + '",'`
                        + '"' + $SeCreatePagefilePrivilege  + '",'`
                        + '"' + $SeCreateTokenPrivilege  + '",'`
                        + '"' + $SeCreateGlobalPrivilege  + '",'`
                        + '"' + $SeCreatePermanentPrivilege  + '",'`
                        + '"' + $SeCreateSymbolicLinkPrivilege  + '",'`
                        + '"' + $SeDebugPrivilege  + '",'`
                        + '"' + $SeDenyNetworkLogonRight  + '",'`
                        + '"' + $SeDenyBatchLogonRight  + '",'`
                        + '"' + $SeDenyServiceLogonRight  + '",'`
                        + '"' + $SeDenyInteractiveLogonRight  + '",'`
                        + '"' + $SeDenyRemoteInteractiveLogonRight  + '",'`
                        + '"' + $SeEnableDelegationPrivilege  + '",'`
                        + '"' + $SeRemoteShutdownPrivilege  + '",'`
                        + '"' + $SeAuditPrivilege  + '",'`
                        + '"' + $SeImpersonatePrivilege  + '",'`
                        + '"' + $SeIncreaseWorkingSetPrivilege  + '",'`
                        + '"' + $SeIncreaseBasePriorityPrivilege  + '",'`
                        + '"' + $SeLoadDriverPrivilege  + '",'`
                        + '"' + $SeLockMemoryPrivilege  + '",'`
                        + '"' + $SeBatchLogonRight  + '",'`
                        + '"' + $SeServiceLogonRight  + '",'`
                        + '"' + $SeSecurityPrivilege  + '",'`
                        + '"' + $SeRelabelPrivilege  + '",'`
                        + '"' + $SeSystemEnvironmentPrivilege  + '",'`
                        + '"' + $SeDelegateSessionUserImpersonatePrivilege  + '",'`
                        + '"' + $SeManageVolumePrivilege  + '",'`
                        + '"' + $SeProfileSingleProcessPrivilege  + '",'`
                        + '"' + $SeSystemProfilePrivilege  + '",'`
                        + '"' + $SeUndockPrivilege  + '",'`
                        + '"' + $SeAssignPrimaryTokenPrivilege  + '",'`
                        + '"' + $SeRestorePrivilege  + '",'`
                        + '"' + $SeShutdownPrivilege  + '",'`
                        + '"' + $SeSyncAgentPrivilege  + '",'`
                        + '"' + $SeTakeOwnershipPrivilege  + '",'`
                        + '"' + $ID  + '",'`
                        + '"' + $DomainName  + '",'`
                        + '"' + $Owner  + '",'`
                        + '"' + $GpoStatus  + '",'`
                        + '"' + $CreationTime  + '",'`
                        + '"' + $ModificationTime  + '",'`
                        + '"' + $UserVersion  + '",'`
                        + '"' + $ComputerVersion  + '"'

                Add-Content -Path $DcUraOutputFile -Value $LineOut -Encoding Unicode

                foreach ($SO in $CurGPO.GPO.Computer.ExtensionData.Extension.SecurityOptions) 
                {
                    $KeyName = $SO.KeyName
                    $SettingNumber = $SO.SettingNumber
                    $SettingString = $SO.SettingString
                    if ($SettingString -ne $null) {$SettingString = $SettingString.replace('"','')}
                    $GPODisplayName = $SO.Display.Name

                    If ($SettingNumber -eq $null) {
                        $SettingNumber = $SettingString
                    }

                    If ($GPODisplayName -eq "LSAAnonymousNameLookup")
                    {
                        $GPODisplayName = "Network access: Allow anonymous SID/Name translation"
                    }


                    $OUName = $OU.Name

                    foreach ($Link in $CurGPO.GPO.LinksTo) {
                        $LinkTo = $Link.SOMPath
                        if ($LinkTo.Contains("/") -eq $true)
                        {
                            If ($LinkTo.Contains("/"+ $OUName) -eq $true) {
                                $LinkEnabled = $Link.Enabled
                                $LinkEnforced = $Link.NoOverride
                                $LinkToOut = $Link.SOMPath
                            }
                        } else {
                            If ($LinkTo.Contains($OUName) -eq $true) {
                                $LinkEnabled = $Link.Enabled
                                $LinkEnforced = $Link.NoOverride
                                $LinkToOut = $Link.SOMPath
                            }
                        }
                    }

                
                    if ($KeyName -ne $null) {

                        $LineOut = '"' + $LinkOrder + '",'`
                                    + '"' + $DisplayName  + '",'`
                                    + '"' + $IsLinked  + '",'`
                                    + '"' + $LinkEnabled  + '",'`
                                    + '"' + $LinkEnforced  + '",'`
                                    + '"' + $LinkToOut  + '",'`
                                    + '"' + $KeyName  + '",'`
                                    + '"' + $SettingNumber  + '",'`
                                    + '"' + $GPODisplayName  + '",'`
                                    + '"' + $ID  + '",'`
                                    + '"' + $DomainName  + '",'`
                                    + '"' + $Owner  + '",'`
                                    + '"' + $GpoStatus  + '",'`
                                    + '"' + $CreationTime  + '",'`
                                    + '"' + $ModificationTime  + '",'`
                                    + '"' + $UserVersion  + '",'`
                                    + '"' + $ComputerVersion  + '"'

                        Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                    } else {
                        $KeyName = $SO.SystemAccessPolicyName
                        $SettingNumber = $SO.SettingNumber
                        $GPODisplayName = $KeyName

                        If ($GPODisplayName -eq "LSAAnonymousNameLookup")
                        {
                            $GPODisplayName = "Network access: Allow anonymous SID/Name translation"
                        }

                    
                        if ($KeyName -ne $null) {
                            $LineOut = '"' + $LinkOrder + '",'`
                                        + '"' + $DisplayName  + '",'`
                                        + '"' + $IsLinked  + '",'`
                                        + '"' + $LinkEnabled  + '",'`
                                        + '"' + $LinkEnforced  + '",'`
                                        + '"' + $LinkToOut  + '",'`
                                        + '"' + $KeyName  + '",'`
                                        + '"' + $SettingNumber  + '",'`
                                        + '"' + $GPODisplayName  + '",'`
                                        + '"' + $ID  + '",'`
                                        + '"' + $DomainName  + '",'`
                                        + '"' + $Owner  + '",'`
                                        + '"' + $GpoStatus  + '",'`
                                        + '"' + $CreationTime  + '",'`
                                        + '"' + $ModificationTime  + '",'`
                                        + '"' + $UserVersion  + '",'`
                                        + '"' + $ComputerVersion  + '"'

                            Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                        }
                    }

                }

                #### Get Auditing Data ###
                foreach ($SO in $CurGPO.GPO.Computer.ExtensionData.Extension.AuditSetting) 
                {

                    $PolicyTarget = $SO.PolicyTarget
                    $SubcategoryName = $SO.SubcategoryName
                    $SubcategoryGuid = $SO.SubcategoryGuid
                    $SettingValue = $SO.SettingValue

                    if ($PolicyTarget -ne $null)
                    {

                        $OUName = $OU.Name

                        foreach ($Link in $CurGPO.GPO.LinksTo) 
                        {
                            $LinkTo = $Link.SOMPath
                            if ($LinkTo.Contains("/") -eq $true)
                            {
                                If ($LinkTo.Contains("/"+ $OUName) -eq $true) {
                                    $LinkEnabled = $Link.Enabled
                                    $LinkEnforced = $Link.NoOverride
                                    $LinkToOut = $Link.SOMPath
                                }
                            } else {
                                If ($LinkTo.Contains($OUName) -eq $true) {
                                    $LinkEnabled = $Link.Enabled
                                    $LinkEnforced = $Link.NoOverride
                                    $LinkToOut = $Link.SOMPath
                                }
                            }
                        }

                        $LineOut = '"' + $LinkOrder + '",'`
                                    + '"' + $DisplayName  + '",'`
                                    + '"' + $IsLinked  + '",'`
                                    + '"' + $LinkEnabled  + '",'`
                                    + '"' + $LinkEnforced  + '",'`
                                    + '"' + $LinkToOut  + '",'`
                                    + '"' + $PolicyTarget  + '",'`
                                    + '"' + $SubcategoryName  + '",'`
                                    + '"' + $SubcategoryGuid  + '",'`
                                    + '"' + $SettingValue  + '",'`
                                    + '"' + $ID  + '",'`
                                    + '"' + $DomainName  + '",'`
                                    + '"' + $Owner  + '",'`
                                    + '"' + $GpoStatus  + '",'`
                                    + '"' + $CreationTime  + '",'`
                                    + '"' + $ModificationTime  + '",'`
                                    + '"' + $UserVersion  + '",'`
                                    + '"' + $ComputerVersion  + '"'

                        Add-Content -Path $GPOAuditingFilename -Value $LineOut -Encoding Unicode
                    }

                }

                ### Get Administrative Template Settings ###

                foreach ($SO in $CurGPO.GPO.Computer.ExtensionData.Extension.Policy) 
                {

                    $Name2=""
                    $State2=""
                    $Name3=""

                    $Name = $SO.Name
                    $State = $SO.State
                    $Supported = $SO.Supported
                    $Category = $SO.Category


                    if ($Name -eq "KDC support for claims, compound authentication and Kerberos armoring")
                    {
                        $Name2 = $So.DropDownList.Name
                        $State2 = $SO.DropDownList.State
                        $Name3 = $SO.DropDownList.Value.Name

                    }

                    if ($Name -NE "" -and $Name -NE $null)
                    {

                        $OUName = $OU.Name

                        foreach ($Link in $CurGPO.GPO.LinksTo) 
                        {
                            $LinkTo = $Link.SOMPath
                            if ($LinkTo.Contains("/") -eq $true)
                            {
                                If ($LinkTo.Contains("/"+ $OUName) -eq $true) {
                                    $LinkEnabled = $Link.Enabled
                                    $LinkEnforced = $Link.NoOverride
                                    $LinkToOut = $Link.SOMPath
                                }
                            } else {
                                If ($LinkTo.Contains($OUName) -eq $true) {
                                    $LinkEnabled = $Link.Enabled
                                    $LinkEnforced = $Link.NoOverride
                                    $LinkToOut = $Link.SOMPath
                                }
                            }
                        }

                        $LineOut = '"' + $LinkOrder + '",'`
                                    + '"' + $DisplayName  + '",'`
                                    + '"' + $IsLinked  + '",'`
                                    + '"' + $LinkEnabled  + '",'`
                                    + '"' + $LinkEnforced  + '",'`
                                    + '"' + $LinkToOut  + '",'`
                                    + '"' + $ID  + '",'`
                                    + '"' + $DomainName  + '",'`
                                    + '"' + $Owner  + '",'`
                                    + '"' + $GpoStatus  + '",'`
                                    + '"' + $CreationTime  + '",'`
                                    + '"' + $ModificationTime  + '",'`
                                    + '"' + $UserVersion  + '",'`
                                    + '"' + $ComputerVersion  + '",'`
                                    + '"' + $Name  + '",'`
                                    + '"' + $State  + '",'`
                                    + '"' + $Supported  + '",'`
                                    + '"' + $Category  + '",'`
                                    + '"' + $Name2  + '",'`
                                    + '"' + $State2  + '",'`
                                    + '"' + $Name3  + '"'

                        Add-Content -Path $GPOAdministrativeTemplateValuesFilename -Value $LineOut -Encoding Unicode
                    }

                }

                ### Get Restricted Group Settings ###

                foreach ($SO in $CurGPO.GPO.Computer.ExtensionData.Extension.RestrictedGroups) 
                {

                    $GroupName = $SO.GroupName.Name.innerxml
                    $GroupSID = $SO.GroupName.SID.innerxml

                    foreach ($Member in $SO.Member)
                    {
                     
                        $MemberName = $Member.Name.innerxml
                        $MemberSID = $Member.SID.innerxml
                       
                        foreach ($Link in $CurGPO.GPO.LinksTo) 
                        {
                            $LinkTo = $Link.SOMPath
                            if ($LinkTo.Contains("/") -eq $true)
                            {
                                If ($LinkTo.Contains("/"+ $OUName) -eq $true) {
                                    $LinkEnabled = $Link.Enabled
                                    $LinkEnforced = $Link.NoOverride
                                    $LinkToOut = $Link.SOMPath
                                }
                            } else {
                                If ($LinkTo.Contains($OUName) -eq $true) {
                                    $LinkEnabled = $Link.Enabled
                                    $LinkEnforced = $Link.NoOverride
                                    $LinkToOut = $Link.SOMPath
                                }
                            }
                        }


                        $LineOut = '"' + $LinkOrder + '",'`
                                    + '"' + $DisplayName  + '",'`
                                    + '"' + $IsLinked  + '",'`
                                    + '"' + $LinkEnabled  + '",'`
                                    + '"' + $LinkEnforced  + '",'`
                                    + '"' + $LinkToOut  + '",'`
                                    + '"' + $ID  + '",'`
                                    + '"' + $DomainName  + '",'`
                                    + '"' + $Owner  + '",'`
                                    + '"' + $GpoStatus  + '",'`
                                    + '"' + $CreationTime  + '",'`
                                    + '"' + $ModificationTime  + '",'`
                                    + '"' + $UserVersion  + '",'`
                                    + '"' + $ComputerVersion  + '",'`
                                    + '"' + $GroupName  + '",'`
                                    + '"' + $GroupSID  + '",'`
                                    + '"' + $MemberName  + '",'`
                                    + '"' + $MemberSID  + '"'

                        Add-Content -Path $GPORestrictedGroupsFilename -Value $LineOut -Encoding Unicode


                    }
                }
            

                ### Get GP Preferences ###

                foreach ($SO in $CurGPO.GPO.Computer.ExtensionData.Extension.LocalUsersAndGroups) 
                {

                    foreach ($Group in $SO.Group)
                    {

                        $GroupName = $Group.Properties.groupName
                        $Action = $Group.Properties.Action
                        $newName = $Group.Properties.newName
                        $description = $Group.Properties.description
                        $deleteAllUsers = $Group.Properties.deleteAllUsers
                        $deleteAllGroups = $Group.Properties.deleteAllGroups
                        $removeAccounts = $Group.Properties.removeAccount

                        foreach ($Member in $Group.Properties.Members.Member)
                        {
                            $MemberName = $Member.name
                            $MemberAction = $Member.action
                            $MemberSID = $Member.sid

                            $LineOut = '"' + $LinkOrder + '",'`
                                        + '"' + $DisplayName  + '",'`
                                        + '"' + $IsLinked  + '",'`
                                        + '"' + $LinkEnabled  + '",'`
                                        + '"' + $LinkEnforced  + '",'`
                                        + '"' + $LinkToOut  + '",'`
                                        + '"' + $ID  + '",'`
                                        + '"' + $DomainName  + '",'`
                                        + '"' + $Owner  + '",'`
                                        + '"' + $GpoStatus  + '",'`
                                        + '"' + $CreationTime  + '",'`
                                        + '"' + $ModificationTime  + '",'`
                                        + '"' + $UserVersion  + '",'`
                                        + '"' + $ComputerVersion  + '",'`
                                        + '"' + $GroupName  + '",'`
                                        + '"' + $Action  + '",'`
                                        + '"' + $newName  + '",'`
                                        + '"' + $description  + '",'`
                                        + '"' + $deleteAllUsers  + '",'`
                                        + '"' + $deleteAllGroups  + '",'`
                                        + '"' + $removeAccounts  + '",'`
                                        + '"' + $MemberName  + '",'`
                                        + '"' + $MemberAction  + '",'`
                                        + '"' + $MemberSID  + '"'

                            Add-Content -Path $GPOPreferencesFilename -Value $LineOut -Encoding Unicode




                        }
                    }
                }
            }
        }
    }
}




##########################################
### Get GPOs linked to the domain root ###
##########################################
Function GetGPOsLinkedToTheDomainRoot
{
    $OUs = Get-ADDomain -identity $DomainLdap -server $Server

    foreach ($OU in $OUs) {

        $Gpos = $OU.LinkedGroupPolicyObjects
        $LinkCount = $Gpos.Count
        Foreach ($Gpo in $Gpos) {
            $LinkOrder = $LinkCount

            $LinkCount = $LinkCount - 1

            $GpoParts = $Gpo -split '\}'
            $GpoParts2 = $GpoParts[0] -split '\{'
            $GpoGuid = $GpoParts2[1]

            $AllGPOs = get-GPO -Guid $GpoGuid -Domain $Domain

            foreach ($GPO in $allGpOs) {

                $ID = $GPO.ID
                $DisplayName = $GPO.DisplayName
                $DomainName = $GPO.DomainName
                $Owner = $GPO.Owner
                $GpoStatus = $GPO.GpoStatus
                $CreationTime = $GPO.CreationTime
                $ModificationTime = $GPO.ModificationTime
                $UserVersion = "AD Version: " + $GPO.User.DSVersion + ", Sysvol Version: " + $GPO.User.SysvolVersion
                $ComputerVersion = "AD Version: " + $GPO.Computer.DSVersion + ", Sysvol Version: " + $GPO.Computer.SysvolVersion
                $WmiFilter = $GPO.WmiFilter
                $Description = $GPO.Description

                WriteLog "-->Processing: $ID $DisplayName" $true "Yellow"

                get-gporeport -guid $ID -ReportType xml -path $CurXml -Domain $Domain
                [xml]$CurGPO = Get-Content -Path $CurXml

                $SeTrustedCredManAccessPrivilege = "<not set>"              #Access Credential Manager as a trusted caller
                $SeNetworkLogonRight = "<not set>"                          #Access this computer from the network
                $SeTcbPrivilege = "<not set>"                               #Act as part of the operating system
                $SeMachineAccountPrivilege = "<not set>"                    #Add workstations to the domain
                $SeIncreaseQuotaPrivilege = "<not set>"                     #Adjust memory quotas for a process
                $SeInteractiveLogonRight = "<not set>"                      #Allow log on locally
                $SeRemoteInteractiveLogonRight = "<not set>"                #Allow log on through Remote Desktop Services
                $SeBackupPrivilege = "<not set>"                            #Backup up files and directories
                $SeChangeNotifyPrivilege = "<not set>"                      #Bypass traverse checking
                $SeSystemTimePrivilege = "<not set>"                        #Change the system time        
                $SeTimeZonePrivilege = "<not set>"                          #Change the time zone
                $SeCreatePagefilePrivilege = "<not set>"                    #Create a pagefile
                $SeCreateTokenPrivilege = "<not set>"                       #Create a token object
                $SeCreateGlobalPrivilege = "<not set>"                      #Create global objects
                $SeCreatePermanentPrivilege = "<not set>"                   #Create permanent shared objects
                $SeCreateSymbolicLinkPrivilege = "<not set>"                #Create symbolic links
                $SeDebugPrivilege = "<not set>"                             #Debug programs
                $SeDenyNetworkLogonRight = "<not set>"                      #Deny access to this computer from the network
                $SeDenyBatchLogonRight = "<not set>"                        #Deny log on as a batch job
                $SeDenyServiceLogonRight = "<not set>"                      #Deny log on as a service
                $SeDenyInteractiveLogonRight = "<not set>"                  #Deny log on locally
                $SeDenyRemoteInteractiveLogonRight = "<not set>"            #Deny log on through Remote Desktop Services
                $SeEnableDelegationPrivilege = "<not set>"                  #Enable computer and user accounts to be trusted for delegation
                $SeRemoteShutdownPrivilege = "<not set>"                    #Force shutdown from a remote system
                $SeAuditPrivilege = "<not set>"                             #Generate Security Audits
                $SeImpersonatePrivilege = "<not set>"                       #Impersonate a client after authentication
                $SeIncreaseWorkingSetPrivilege = "<not set>"                #Increase a process working set
                $SeIncreaseBasePriorityPrivilege = "<not set>"              #Increase scheduling priority
                $SeLoadDriverPrivilege = "<not set>"                        #Load and unload device drivers
                $SeLockMemoryPrivilege = "<not set>"                        #Lock pages in memory
                $SeBatchLogonRight = "<not set>"                            #Log on as a batch job
                $SeServiceLogonRight = "<not set>"                          #Log on as a service
                $SeSecurityPrivilege = "<not set>"                          #Manage auditing and security log
                $SeRelabelPrivilege = "<not set>"                           #Modify an object label
                $SeSystemEnvironmentPrivilege = "<not set>"                 #Modify firmware environment values
                $SeDelegateSessionUserImpersonatePrivilege = "<not set>"    #Obtain an impersonation token for another user in the same session
                $SeManageVolumePrivilege = "<not set>"                      #Perform volume maintenance tasks
                $SeProfileSingleProcessPrivilege = "<not set>"              #Profile single process
                $SeSystemProfilePrivilege = "<not set>"                     #Profile system performance
                $SeUndockPrivilege = "<not set>"                            #Remove computer from docking station
                $SeAssignPrimaryTokenPrivilege = "<not set>"                #Replace a process Level Token
                $SeRestorePrivilege = "<not set>"                           #Restore files and directories
                $SeShutdownPrivilege = "<not set>"                          #Shut down the system
                $SeSyncAgentPrivilege = "<not set>"                         #Synchronize directory service data
                $SeTakeOwnershipPrivilege = "<not set>"                     #Take ownership of files or other objects

                $HasDenyUra = "FALSE"

                foreach ($URA in $CurGPO.GPO.Computer.ExtensionData.Extension.UserRightsAssignment) {
    
                    $URAName = $URA.Name

                    $Members = ""

                    foreach ($Member in $URA.Member.Name) {
                        If ($Members -eq "") {
                            $Members = $Member.InnerXML
                        } else {
                            $Members = $Members + ", " + $Member.InnerXML
                        }
                    }

                    $SortedMembers = $Members -split '\, ' | Sort-Object
                    $MembersOut = ""
                    foreach ($Member in $SortedMembers) {
                        If ($MembersOut -eq "") {
                            $MembersOut = $Member
                        } else {
                            $MembersOut = $MembersOut + ", " + $Member
                        }
                    }

                    if ($URAName -eq "SeTrustedCredManAccessPrivilege") {$SeTrustedCredManAccessPrivilege = $MembersOut}
                    if ($URAName -eq "SeNetworkLogonRight") {$SeNetworkLogonRight = $MembersOut}
                    if ($URAName -eq "SeTcbPrivilege") {$SeTcbPrivilege = $MembersOut}
                    if ($URAName -eq "SeMachineAccountPrivilege") {$SeMachineAccountPrivilege = $MembersOut}
                    if ($URAName -eq "SeIncreaseQuotaPrivilege") {$SeIncreaseQuotaPrivilege = $MembersOut}
                    if ($URAName -eq "SeInteractiveLogonRight") {$SeInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeRemoteInteractiveLogonRight") {$SeRemoteInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeBackupPrivilege") {$SeBackupPrivilege = $MembersOut}
                    if ($URAName -eq "SeChangeNotifyPrivilege") {$SeChangeNotifyPrivilege = $MembersOut}
                    if ($URAName -eq "SeSystemtimePrivilege") {$SeSystemtimePrivilege = $MembersOut}
                    if ($URAName -eq "SeTimeZonePrivilege") {$SeTimeZonePrivilege = $MembersOut}
                    if ($URAName -eq "SeCreatePagefilePrivilege") {$SeCreatePagefilePrivilege = $MembersOut}
                    if ($URAName -eq "SeCreateTokenPrivilege") {$SeCreateTokenPrivilege = $MembersOut}
                    if ($URAName -eq "SeCreateGlobalPrivilege") {$SeCreateGlobalPrivilege = $MembersOut}
                    if ($URAName -eq "SeCreatePermanentPrivilege") {$SeCreatePermanentPrivilege = $MembersOut}
                    if ($URAName -eq "SeCreateSymbolicLinkPrivilege") {$SeCreateSymbolicLinkPrivilege = $MembersOut}
                    if ($URAName -eq "SeDebugPrivilege") {$SeDebugPrivilege = $MembersOut}
                    if ($URAName -eq "SeDenyNetworkLogonRight") {$SeDenyNetworkLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyBatchLogonRight") {$SeDenyBatchLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyServiceLogonRight") {$SeDenyServiceLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyInteractiveLogonRight") {$SeDenyInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeDenyRemoteInteractiveLogonRight") {$SeDenyRemoteInteractiveLogonRight = $MembersOut}
                    if ($URAName -eq "SeEnableDelegationPrivilege") {$SeEnableDelegationPrivilege = $MembersOut}
                    if ($URAName -eq "SeRemoteShutdownPrivilege") {$SeRemoteShutdownPrivilege = $MembersOut}
                    if ($URAName -eq "SeAuditPrivilege") {$SeAuditPrivilege = $MembersOut}
                    if ($URAName -eq "SeImpersonatePrivilege") {$SeImpersonatePrivilege = $MembersOut}
                    if ($URAName -eq "SeIncreaseWorkingSetPrivilege") {$SeIncreaseWorkingSetPrivilege = $MembersOut}
                    if ($URAName -eq "SeIncreaseBasePriorityPrivilege") {$SeIncreaseBasePriorityPrivilege = $MembersOut}
                    if ($URAName -eq "SeLoadDriverPrivilege") {$SeLoadDriverPrivilege = $MembersOut}
                    if ($URAName -eq "SeLockMemoryPrivilege") {$SeLockMemoryPrivilege = $MembersOut}
                    if ($URAName -eq "SeBatchLogonRight") {$SeBatchLogonRight = $MembersOut}
                    if ($URAName -eq "SeServiceLogonRight") {$SeServiceLogonRight = $MembersOut}
                    if ($URAName -eq "SeSecurityPrivilege") {$SeSecurityPrivilege = $MembersOut}
                    if ($URAName -eq "SeRelabelPrivilege") {$SeRelabelPrivilege = $MembersOut}
                    if ($URAName -eq "SeSystemEnvironmentPrivilege") {$SeSystemEnvironmentPrivilege = $MembersOut}
                    if ($URAName -eq "SeDelegateSessionUserImpersonatePrivilege") {$SeDelegateSessionUserImpersonatePrivilege = $MembersOut}
                    if ($URAName -eq "SeManageVolumePrivilege") {$SeManageVolumePrivilege = $MembersOut}
                    if ($URAName -eq "SeProfileSingleProcessPrivilege") {$SeProfileSingleProcessPrivilege = $MembersOut}
                    if ($URAName -eq "SeSystemProfilePrivilege") {$SeSystemProfilePrivilege = $MembersOut}
                    if ($URAName -eq "SeUndockPrivilege") {$SeUndockPrivilege = $MembersOut}
                    if ($URAName -eq "SeAssignPrimaryTokenPrivilege") {$SeAssignPrimaryTokenPrivilege = $MembersOut}
                    if ($URAName -eq "SeRestorePrivilege") {$SeRestorePrivilege = $MembersOut}
                    if ($URAName -eq "SeShutdownPrivilege") {$SeShutdownPrivilege = $MembersOut}
                    if ($URAName -eq "SeSyncAgentPrivilege") {$SeSyncAgentPrivilege = $MembersOut}
                    if ($URAName -eq "SeTakeOwnershipPrivilege") {$SeTakeOwnershipPrivilege = $MembersOut}
                }

                $IsLinked = $true
                $LinkedTo = $OU.DistinguishedName
                $OUName = $OU.Name

                foreach ($Link in $CurGPO.GPO.LinksTo) {
                    $LinkTo = $Link.SOMPath
                    if ($LinkTo.Contains("/") -eq $true)
                    {
                        If ($LinkTo.Contains("/"+ $OUName) -eq $true) {
                            $LinkEnabled = $Link.Enabled
                            $LinkEnforced = $Link.NoOverride
                            $LinkToOut = $Link.SOMPath
                        }
                    } else {
                        If ($LinkTo.Contains($OUName) -eq $true) {
                            $LinkEnabled = $Link.Enabled
                            $LinkEnforced = $Link.NoOverride
                            $LinkToOut = $Link.SOMPath
                        }
                    }
                }

                $LineOut = '"' + $LinkOrder + '",'`
                        + '"' + $DisplayName  + '",'`
                        + '"' + $IsLinked  + '",'`
                        + '"' + $LinkEnabled  + '",'`
                        + '"' + $LinkEnforced  + '",'`
                        + '"' + $LinkToOut  + '",'`
                        + '"' + $SeTrustedCredManAccessPrivilege  + '",'`
                        + '"' + $SeNetworkLogonRight  + '",'`
                        + '"' + $SeTcbPrivilege  + '",'`
                        + '"' + $SeMachineAccountPrivilege  + '",'`
                        + '"' + $SeIncreaseQuotaPrivilege  + '",'`
                        + '"' + $SeInteractiveLogonRight  + '",'`
                        + '"' + $SeRemoteInteractiveLogonRight  + '",'`
                        + '"' + $SeBackupPrivilege  + '",'`
                        + '"' + $SeChangeNotifyPrivilege  + '",'`
                        + '"' + $SeSystemtimePrivilege  + '",'`
                        + '"' + $SeTimeZonePrivilege  + '",'`
                        + '"' + $SeCreatePagefilePrivilege  + '",'`
                        + '"' + $SeCreateTokenPrivilege  + '",'`
                        + '"' + $SeCreateGlobalPrivilege  + '",'`
                        + '"' + $SeCreatePermanentPrivilege  + '",'`
                        + '"' + $SeCreateSymbolicLinkPrivilege  + '",'`
                        + '"' + $SeDebugPrivilege  + '",'`
                        + '"' + $SeDenyNetworkLogonRight  + '",'`
                        + '"' + $SeDenyBatchLogonRight  + '",'`
                        + '"' + $SeDenyServiceLogonRight  + '",'`
                        + '"' + $SeDenyInteractiveLogonRight  + '",'`
                        + '"' + $SeDenyRemoteInteractiveLogonRight  + '",'`
                        + '"' + $SeEnableDelegationPrivilege  + '",'`
                        + '"' + $SeRemoteShutdownPrivilege  + '",'`
                        + '"' + $SeAuditPrivilege  + '",'`
                        + '"' + $SeImpersonatePrivilege  + '",'`
                        + '"' + $SeIncreaseWorkingSetPrivilege  + '",'`
                        + '"' + $SeIncreaseBasePriorityPrivilege  + '",'`
                        + '"' + $SeLoadDriverPrivilege  + '",'`
                        + '"' + $SeLockMemoryPrivilege  + '",'`
                        + '"' + $SeBatchLogonRight  + '",'`
                        + '"' + $SeServiceLogonRight  + '",'`
                        + '"' + $SeSecurityPrivilege  + '",'`
                        + '"' + $SeRelabelPrivilege  + '",'`
                        + '"' + $SeSystemEnvironmentPrivilege  + '",'`
                        + '"' + $SeDelegateSessionUserImpersonatePrivilege  + '",'`
                        + '"' + $SeManageVolumePrivilege  + '",'`
                        + '"' + $SeProfileSingleProcessPrivilege  + '",'`
                        + '"' + $SeSystemProfilePrivilege  + '",'`
                        + '"' + $SeUndockPrivilege  + '",'`
                        + '"' + $SeAssignPrimaryTokenPrivilege  + '",'`
                        + '"' + $SeRestorePrivilege  + '",'`
                        + '"' + $SeShutdownPrivilege  + '",'`
                        + '"' + $SeSyncAgentPrivilege  + '",'`
                        + '"' + $SeTakeOwnershipPrivilege  + '",'`
                        + '"' + $ID  + '",'`
                        + '"' + $DomainName  + '",'`
                        + '"' + $Owner  + '",'`
                        + '"' + $GpoStatus  + '",'`
                        + '"' + $CreationTime  + '",'`
                        + '"' + $ModificationTime  + '",'`
                        + '"' + $UserVersion  + '",'`
                        + '"' + $ComputerVersion  + '"'

                Add-Content -Path $DcUraOutputFile -Value $LineOut -Encoding Unicode

                foreach ($SO in $CurGPO.GPO.Computer.ExtensionData.Extension.SecurityOptions) {
                    $KeyName = $SO.KeyName
                    $SettingNumber = $SO.SettingNumber
                    $SettingString = $SO.SettingString
                    if ($SettingString -ne $null) {$SettingString = $SettingString.replace('"','')}
                    $GPODisplayName = $SO.Display.Name

                    If ($SettingNumber -eq $null) {
                        $SettingNumber = $SettingString
                    }
                
                    if ($KeyName -ne $null) {

                        $LineOut = '"' + $LinkOrder + '",'`
                                    + '"' + $DisplayName  + '",'`
                                    + '"' + $IsLinked  + '",'`
                                    + '"' + $LinkEnabled  + '",'`
                                    + '"' + $LinkEnforced  + '",'`
                                    + '"' + $LinkToOut  + '",'`
                                    + '"' + $KeyName  + '",'`
                                    + '"' + $SettingNumber  + '",'`
                                    + '"' + $GPODisplayName  + '",'`
                                    + '"' + $ID  + '",'`
                                    + '"' + $DomainName  + '",'`
                                    + '"' + $Owner  + '",'`
                                    + '"' + $GpoStatus  + '",'`
                                    + '"' + $CreationTime  + '",'`
                                    + '"' + $ModificationTime  + '",'`
                                    + '"' + $UserVersion  + '",'`
                                    + '"' + $ComputerVersion  + '"'

                        Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                    } else {
                        $KeyName = $SO.SystemAccessPolicyName
                        $SettingNumber = $SO.SettingNumber
                        $GPODisplayName = $KeyName
                    
                        if ($KeyName -ne $null) {
                            $LineOut = '"' + $LinkOrder + '",'`
                                        + '"' + $DisplayName  + '",'`
                                        + '"' + $IsLinked  + '",'`
                                        + '"' + $LinkEnabled  + '",'`
                                        + '"' + $LinkEnforced  + '",'`
                                        + '"' + $LinkToOut  + '",'`
                                        + '"' + $KeyName  + '",'`
                                        + '"' + $SettingNumber  + '",'`
                                        + '"' + $GPODisplayName  + '",'`
                                        + '"' + $ID  + '",'`
                                        + '"' + $DomainName  + '",'`
                                        + '"' + $Owner  + '",'`
                                        + '"' + $GpoStatus  + '",'`
                                        + '"' + $CreationTime  + '",'`
                                        + '"' + $ModificationTime  + '",'`
                                        + '"' + $UserVersion  + '",'`
                                        + '"' + $ComputerVersion  + '"'

                            Add-Content -Path $SecurityOptionsOutputFile -Value $LineOut -Encoding Unicode
                        }
                    }
                }
            }
        }
    }

    WriteLog "-->GPO Output file written to $DcUraOutputFile" $True "Yellow"
    WriteLog "-->GPO Output file written to $SecurityOptionsOutputFile" $True "Yellow"
}


####################################
### Produce GPO Pattern Map file ###
####################################
Function ProduceGPOPattermMapFile
{
    WriteLog "Analyzing GPOs for unique URA patterns." $True "Green"

    $PatternCount = 0

    $GPOs = Import-Csv -Path $GPOOutputFile
    foreach ($GPO in $GPOs) {

        if ($GPO.Has_Deny_URA -eq $True -and $GPO.Linked -eq $True -and $GPO.Link_Enabled -eq $True) {

            $URA1 = $GPO.Deny_access_to_this_computer_from_the_network
            $URA2 = $GPO.Deny_log_on_as_a_batch_job
            $URA3 = $GPO.Deny_Log_on_as_a_service
            $URA4 = $GPO.Deny_log_on_locally
            $URA5 = $GPO.Deny_log_on_through_terminal_services
            $Pattern = $URA1 + ";" + $URA2 + ";" + $URA3 + ";" + $URA4 + ";" + $URA5
            $GPOGuid = $GPO.GPO_GUID
            $GPOName = $GPO.GPO_Name

            if ($dic_Patterns.ContainsKey($Pattern) -eq $True) {

                if ($dic_GPOGUID.ContainsKey($GPOGuid) -eq $False) {
                    $dic_Patterns[$Pattern] = $dic_Patterns[$Pattern] + ", " + $GPOGuid
                    $PatternCount2 = $($dic_PatternCount[$Pattern])
                    $LinkedGPOName = "*- Tier 0 Account Restrictions" + $PatternCount2
                    $dic_GPOGUID.Add($GPOGuid,$LinkedGPOName)
                }

            } else {

                $PatternCount = $PatternCount + 1

                $dic_Patterns.Add($Pattern,$GPOGuid)
                $dic_PatternCount.Add($Pattern,$PatternCount)
                $LinkedGPOName = "*- Tier 0 Account Restrictions" + $PatternCount
                if ($dic_GPOGUID.ContainsKey($GPOGuid) -eq $False) {
                    $dic_GPOGUID.Add($GPOGuid,$LinkedGPOName)
                }
            }
        }
    }

    if ($IncludeMSFTRecommendations.IsPresent -eq $true) {

        $LineOut = '"Microsoft Recommendations for Tier 0 Account Restrictions",'`
                + '"<not set>",'`
                + '"<Domain>\Tier0Admins, <Domain>\Tier0ServerOperators",'`
                + '"<Domain>\Tier0Admins, <Domain>\Tier0ServerOperators",'`
                + '"<Domain>\Tier0Admins, <Domain>\Tier0ServerOperators, <Domain>\Tier0ServiceAccounts",'`
                + '"<Domain>\Tier0Admins, <Domain>\Tier0ServerOperators, <Domain>\Tier0ServiceAccounts",'`
                + '"n/a"'

        Add-Content -Path $GPOPatternMapOutputFile -Value $LineOut -Encoding Unicode
    
    }
    foreach ($Key in $dic_Patterns.Keys) {

        $PatternCount = $($dic_PatternCount[$Key])
        $Pattern = $Key
        $GUIDs = $($dic_Patterns[$Key])
        $GPONameOut = "*- Tier 0 Account Restrictions" + $PatternCount

        $PatternParts = $Pattern -split '\;'
        $URA1 = $PatternParts[0]
        $URA2 = $PatternParts[1]
        $URA3 = $PatternParts[2]
        $URA4 = $PatternParts[3]
        $URA5 = $PatternParts[4]

        $LineOut = '"' + $GPONameOut + '",'`
                + '"' + $URA1  + '",'`
                + '"' + $URA2  + '",'`
                + '"' + $URA3  + '",'`
                + '"' + $URA4  + '",'`
                + '"' + $URA5  + '",'`
                + '"' + $GUIDs + '"'

        Add-Content -Path $GPOPatternMapOutputFile -Value $LineOut -Encoding Unicode
    }
    WriteLog "-->GPO Pattern Map written to $GPOPatternMapOutputFile" $True "Yellow"
}

########################################
### Produce GPO Master Plan CSV File ###
########################################
Function ProduceGPOMasterPlanCSVFile
{
    WriteLog "Producing GPO Master Plan CSV File." $true "Green"

    $GPOs = Import-Csv -Path $GPOOutputFile
    foreach ($GPO in $GPOs) {

        $DisplayName = $GPO.GPO_Name
        $HasDenyUra = $GPO.Has_Deny_URA
        $IsLinked = $GPO.Linked
        $LinkEnabled = $GPO.Link_Enabled
        $LinkEnforced = $GPO.Link_Enforced
        $LinkedTo = $GPO.Linked_To
        $URA1 = $GPO.Deny_access_to_this_computer_from_the_network
        $URA2 = $GPO.Deny_log_on_as_a_batch_job
        $URA3 = $GPO.Deny_Log_on_as_a_service
        $URA4 = $GPO.Deny_log_on_locally
        $URA5 = $GPO.Deny_log_on_through_terminal_services
        $ID = $GPO.GPO_GUID
        $DomainName = $GPO.Domain
        $Owner = $GPO.Owner
        $GpoStatus = $GPO.Gpo_Status
        $CreationTime = $GPO.Creation_Time
        $ModificationTime = $GPO.Modification_Time
        $UserVersion = $GPO.User_Version
        $ComputerVersion = $GPO.Computer_Version


        if ($GPO.Has_Deny_URA -eq $True -and $GPO.Linked -eq $True -and $GPO.Link_Enabled -eq $True) {

            if ($dic_GPOGUID.ContainsKey($ID) -eq $True) {
                $GPOPattern = $dic_GPOGUID[$ID]
            }

            $LineOut = '"' + $DisplayName + '",'`
                        + '"' + $HasDenyUra  + '",'`
                        + '"' + $IsLinked  + '",'`
                        + '"' + $LinkEnabled  + '",'`
                        + '"' + $LinkEnforced  + '",'`
                        + '"' + $LinkedTo  + '",'`
                        + '"' + $URA1  + '",'`
                        + '"' + $URA2  + '",'`
                        + '"' + $URA3  + '",'`
                        + '"' + $URA4  + '",'`
                        + '"' + $URA5  + '",'`
                        + '"' + $GPOPattern + '",'`
                        + '"' + $ID  + '",'`
                        + '"' + $DomainName  + '",'`
                        + '"' + $Owner  + '",'`
                        + '"' + $GpoStatus  + '",'`
                        + '"' + $CreationTime  + '",'`
                        + '"' + $ModificationTime  + '",'`
                        + '"' + $UserVersion  + '",'`
                        + '"' + $ComputerVersion  + '"'

        } else {

            $LineOut = '"' + $DisplayName + '",'`
                       + '"' + $HasDenyUra  + '",'`
                       + '"' + $IsLinked  + '",'`
                       + '"' + $LinkEnabled  + '",'`
                       + '"' + $LinkEnforced  + '",'`
                       + '"' + $LinkedTo  + '",'`
                       + '"' + $URA1  + '",'`
                       + '"' + $URA2  + '",'`
                       + '"' + $URA3  + '",'`
                       + '"' + $URA4  + '",'`
                       + '"' + $URA5  + '",'`
                       + '"n/a'  + '",'`
                       + '"' + $ID  + '",'`
                       + '"' + $DomainName  + '",'`
                       + '"' + $Owner  + '",'`
                       + '"' + $GpoStatus  + '",'`
                       + '"' + $CreationTime  + '",'`
                       + '"' + $ModificationTime  + '",'`
                       + '"' + $UserVersion  + '",'`
                       + '"' + $ComputerVersion  + '"'

        }
        Add-Content -Path $GPOMasterOutputFile -Value $LineOut -Encoding Unicode        
    }
    remove-item $CurXml
    WriteLog "-->GPO Master Plan written to $GPOMasterOutputFile" $true "Yellow"
}

###################################
### Produce OU Permissions File ###
###################################
Function ProduceOUPermissionsFile
{
    WriteLog "Producing OU Permissions CSV File." $true "Green"

    $RootDSE = Get-ADRootDSE -Server $Server
    $RootDomain = $RootDSE.rootDomainNamingContext

    ###

    

    $GUIDs = Get-ADObject -SearchBase (Get-ADRootDSE).schemaNamingContext -LDAPFilter '(schemaIDGUID=*)' -Properties name, schemaIDGUID
    Foreach ($GUID in $GUIDs)
    {
        $name = $GUID.name
        $schemaGUID = [System.GUID]$GUID.schemaIDGUID
        $schemaIDGUID.Add($SchemaGUID,$name)
    }

    $AccessRights = Get-ADObject -SearchBase "CN=Extended-Rights,$((Get-ADRootDSE).configurationNamingContext)" -LDAPFilter '(objectClass=controlAccessRight)' -Properties name, rightsGUID
    foreach ($Right in $AccessRights)
    {
        $RightName = $Right.name
        $RightGUID = [System.GUID]$Right.rightsGUID
        if ($schemaIDGUID.ContainsKey($RightGUID) -eq $false)
        {
            $schemaIDGUID.Add($RightGUID,$RightName)
        }
    }
    $AllGUID = [System.GUID]"00000000-0000-0000-0000-000000000000"
    $schemaIDGUID.Add($AllGUID,"All")

    $GUIDCount = $schemaIDGUID.Count
    WriteLog "GUIDCount: $GUIDCount" $true "Yellow"

    $OUs = Get-ADOrganizationalUnit -Filter * -Server $Server | Select-Object -ExpandProperty DistinguishedName
    $AD2 = New-PSDrive -Name AD2 -PSProvider ActiveDirectory -Server $Server -root "//RootDSE/" 

    ForEach ($OU in $OUs) {

        $Error.clear()
        Try 
        { 
            $ACL = Get-Acl -Path "AD2:\$OU" -ErrorAction SilentlyContinue 
        } Catch 
        {}

        if ($Error)
        {
            $Error.Clear()
            $ACL = Get-Acl -Path "Microsoft.ActiveDirectory.Management.dll\ActiveDirectory:://RootDSE/$OU" -ErrorAction SilentlyContinue
        }
        $Report += $ACL | select-Object -ExpandProperty Access | `
        Select-Object @{name='organizationalUnit';expression={$OU}}, `
        @{name='objectTypeName';expression={$schemaIDGUID.Item($_.objectType)}}, `
        @{name='inheritedObjectTypeName';expression={$schemaIDGUID.Item($_.inheritedObjectType)}}, *
    }
    $report | Export-Csv -Path $OUPermissionFile -NoTypeInformation -Encoding Unicode

    $OUs = Get-ADDomain -identity $DomainLdap -server $Server | Select-Object -ExpandProperty DistinguishedName
    ForEach ($OU in $OUs) {
        $Error.clear()
        Try 
        { 
            $ACL = Get-Acl -Path "AD2:\$OU" -ErrorAction SilentlyContinue 
        } Catch 
        {}

        if ($Error)
        {
            $Error.Clear()
            $ACL = Get-Acl -Path "Microsoft.ActiveDirectory.Management.dll\ActiveDirectory:://RootDSE/$OU" -ErrorAction SilentlyContinue
        }
        $Report += $ACL | select-Object -ExpandProperty Access | `
        Select-Object @{name='organizationalUnit';expression={$OU}}, `
        @{name='objectTypeName';expression={$schemaIDGUID.Item($_.objectType)}}, `
        @{name='inheritedObjectTypeName';expression={$schemaIDGUID.Item($_.inheritedObjectType)}}, *

    }
    $report | Export-Csv -Path $OUPermissionFile -NoTypeInformation -Encoding Unicode

    WriteLog "-->OU Permissions File written to $OUPermissionFile" $true "Yellow"
}

###########################
### Get GPO Permissions ###
###########################
Function GetGPOPermissions
{
    write-host "Getting GPO Permissions." -ForegroundColor Green

    $ldapPath = "LDAP://CN=Policies,CN=System," + $DomainLDAP

    $searcher = New-Object System.DirectoryServices.DirectorySearcher
    $searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry($ldapPath)
    $searcher.Filter = "(objectClass=groupPolicyContainer)"
    $searcher.PageSize = 1000

    $GPOs = $searcher.FindAll()

    $GPOs = get-adobject -filter 'ObjectClass -eq "groupPolicyContainer"' -properties distinguishedName,DisplayName -server $server

    foreach ($GPO in $GPOs) 
    {

        $GPODN = $GPO.DistinguishedName
        $GPOName = $GPO.DisplayName

        write-host "$GPODN" -ForegroundColor Yellow

        # Check permissions
        $entry = [ADSI]"LDAP://$($GPO.DistinguishedName)"
        $acl = $entry.psbase.ObjectSecurity.Access

        foreach ($ace in $acl) 
        {

                $IdentityReference = $ace.IdentityReference
                $ActiveDirectoryRights = $ace.ActiveDirectoryRights

                $LineOut = '"' + $GPOName + '",'`
                            + '"' + $IdentityReference  + '",'`
                            + '"' + $ActiveDirectoryRights  + '",'`
                            + '"' + $GPODN  + '"'

                Add-Content -Path $GPOPermissionsFilename -Value $LineOut -Encoding Unicode

        }
    }
}

###################################
### Check For Passwords In GPOs ###
###################################
Function CheckForPasswordsInGPOs
{
    Write-host "Scanning GPOs for embedded passwords." -ForegroundColor Green
    $gpos = Get-GPO -All

    foreach ($gpo in $gpos) {
        $gpoName = $gpo.DisplayName
        $gpoId = $gpo.Id
        $gpoPath = "\\$DomainFQDN\SYSVOL\$DomainFQDN\Policies\{$gpoId}"

        write-host "Scanning: $gpoName" -ForegroundColor Yellow

        # Search for XML files in the GPO folder
        $xmlFiles = Get-ChildItem -Path $gpoPath -Recurse -Include *.xml -ErrorAction SilentlyContinue

        foreach ($file in $xmlFiles) {
            $content = Get-Content $file.FullName -Raw
            if ($content -match 'cpassword="[^"]+"') {

                $Filename = $file.FullName
                $Matches = $($matches[0])


                $LineOut = '"' + $gpoName + '",'`
                            + '"' + $Filename  + '",'`
                            + '"' + $Matches  + '"'

                Add-Content -Path $GPOsWithPasswordsFilename -Value $LineOut -Encoding Unicode


            }
        }
    }

}

############
### Main ###
############

DetermineIfPreferredDCsHaveBeenDefined
$Server = GetClosestDC $DomainFQDN
GetOUsWithGPOBlockInheritance
GetAllGPOs
GetAllURAsAndSecurityOptionsForEveryGPO
GetGPOsLinkedToTheDomainRoot
ProduceGPOPattermMapFile
ProduceGPOMasterPlanCSVFile
ProduceOUPermissionsFile
GetGPOPermissions
CheckForPasswordsInGPOs


# SIG # Begin signature block
# MIIoLAYJKoZIhvcNAQcCoIIoHTCCKBkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAxNM/p5zJNnlhh
# hTeudBSxHDWcNdM46C+qR+BdBGiuBKCCDXYwggX0MIID3KADAgECAhMzAAAEhV6Z
# 7A5ZL83XAAAAAASFMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM3WhcNMjYwNjE3MTgyMTM3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDASkh1cpvuUqfbqxele7LCSHEamVNBfFE4uY1FkGsAdUF/vnjpE1dnAD9vMOqy
# 5ZO49ILhP4jiP/P2Pn9ao+5TDtKmcQ+pZdzbG7t43yRXJC3nXvTGQroodPi9USQi
# 9rI+0gwuXRKBII7L+k3kMkKLmFrsWUjzgXVCLYa6ZH7BCALAcJWZTwWPoiT4HpqQ
# hJcYLB7pfetAVCeBEVZD8itKQ6QA5/LQR+9X6dlSj4Vxta4JnpxvgSrkjXCz+tlJ
# 67ABZ551lw23RWU1uyfgCfEFhBfiyPR2WSjskPl9ap6qrf8fNQ1sGYun2p4JdXxe
# UAKf1hVa/3TQXjvPTiRXCnJPAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuCZyGiCuLYE0aU7j5TFqY05kko0w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwNTM1OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBACjmqAp2Ci4sTHZci+qk
# tEAKsFk5HNVGKyWR2rFGXsd7cggZ04H5U4SV0fAL6fOE9dLvt4I7HBHLhpGdE5Uj
# Ly4NxLTG2bDAkeAVmxmd2uKWVGKym1aarDxXfv3GCN4mRX+Pn4c+py3S/6Kkt5eS
# DAIIsrzKw3Kh2SW1hCwXX/k1v4b+NH1Fjl+i/xPJspXCFuZB4aC5FLT5fgbRKqns
# WeAdn8DsrYQhT3QXLt6Nv3/dMzv7G/Cdpbdcoul8FYl+t3dmXM+SIClC3l2ae0wO
# lNrQ42yQEycuPU5OoqLT85jsZ7+4CaScfFINlO7l7Y7r/xauqHbSPQ1r3oIC+e71
# 5s2G3ClZa3y99aYx2lnXYe1srcrIx8NAXTViiypXVn9ZGmEkfNcfDiqGQwkml5z9
# nm3pWiBZ69adaBBbAFEjyJG4y0a76bel/4sDCVvaZzLM3TFbxVO9BQrjZRtbJZbk
# C3XArpLqZSfx53SuYdddxPX8pvcqFuEu8wcUeD05t9xNbJ4TtdAECJlEi0vvBxlm
# M5tzFXy2qZeqPMXHSQYqPgZ9jvScZ6NwznFD0+33kbzyhOSz/WuGbAu4cHZG8gKn
# lQVT4uA2Diex9DMs2WHiokNknYlLoUeWXW1QrJLpqO82TLyKTbBM/oZHAdIc0kzo
# STro9b3+vjn2809D0+SOOCVZMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAASFXpnsDlkvzdcAAAAABIUwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICuuXF5ym5Gv0BbNiIs75VyM
# pJwTKD27XNwZQqySNzyvMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEATemv0lV0TbkwnvQIRZvgaBbxCQFn10ApWFTx8Jp3ylesaNL9yMlHbc1b
# kGuOWusQvE+mWz7CL/NrffMDbhbzQr8ffBLNBb+jZ67M2dMBV0u+2bDQ0WORV1er
# NHIuiC57LeF3DZjz9/2LH2irnbrBc8MOLsjiVu8KXxlheZeqxzg8eVP0uk2D5O18
# kW8MbhJTKfKrzCLknXzM/StypkxIbg7EsiTZovAzwuT8ySBB/Dp07ACp5USgN2wj
# 5UmG6cUjcnynEzroU/5+CA84xEufxmJ9VuKk1SKVXhz/uMQxjLMpBHV/CPRjP1rx
# NK9yG1vA65ACSl/k0UQpUbc3ztBUKKGCF5YwgheSBgorBgEEAYI3AwMBMYIXgjCC
# F34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCpm4BsgVARIrwPBJOTmG0QK4/lAiwK+KX9oIt2D7JVjwIGaEsHNNm0
# GBIyMDI1MDcyOTE4MjgxMS42OVowBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjpEQzAwLTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# Ee0wggcgMIIFCKADAgECAhMzAAACA7seXAA4bHTKAAEAAAIDMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI1MDEzMDE5NDI0
# NloXDTI2MDQyMjE5NDI0NlowgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjpEQzAwLTA1RTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAKGXQwfnACc7HxSHxG2J0XQnTJoUMclgdOk+9FHXpfUr
# EYNh9Pw+twaMIsKJo67crUOZQhThFzmiWd2Nqmk246DPBSiPjdVtsnHk8VNj9rVn
# zS2mpU/Q6gomVSR8M9IEsWBdaPpWBrJEIg20uxRqzLTDmDKwPsgs9m6JCNpx7krE
# BKMp/YxVfWp8TNgFtMY0SKNJAIrDDJzR5q+vgWjdf/6wK64C2RNaKyxTriTysrrS
# OwZECmIRJ1+4evTJYCZzuNM4814YDHooIvaS2mcZ6AsN3UiUToG7oFLAAgUevvM7
# AiUWrJC4J7RJAAsJsmGxP3L2LLrVEkBexTS7RMLlhiZNJsQjuDXR1jHxSP6+H0ic
# ugpgLkOkpvfXVthV3RvK1vOV9NGyVFMmCi2d8IAgYwuoSqT3/ZVEa72SUmLWP2dV
# +rJgdisw84FdytBhbSOYo2M4vjsJoQCs3OEMGJrXBd0kA0qoy8nylB7abz9yJvIM
# z7UFVmq40Ci/03i0kXgAK2NfSONc0NQy1JmhUVAf4WRZ189bHW4EiRz3tH7FEu4+
# NTKkdnkDcAAtKR7hNpEG9u9MFjJbYd6c5PudgspM7iPDlCrpzDdn3NMpI9DoPmXK
# Jil6zlFHYx0y8lLh8Jw8kV5pU6+5YVJD8Qa1UFKGGYsH7l7DMXN2l/VS4ma45BNP
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUsilZQH4R55Db2xZ7RV3PFZAYkn0wHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBAJAQxt6wPpMLTxHShgJ1ILjnYBCsZ/87z0ZD
# ngK2ASxvHPAYNVRyaNcVydolJM150EpVeQGBrBGic/UuDEfhvPNWPZ5Y2bMYjA7U
# WWGV0A84cDMsEQdGhJnil10W1pDGhptT83W9bIgKI3rQi3zmCcXkkPgwxfJ3qlLx
# 4AMiLpO2N+Ao+i6ZZrQEVD9oTONSt883Wvtysr6qSYvO3D8Q1LvN6Z/LHiQZGDBj
# VYF8Wqb+cWUkM9AGJyp5Td06n2GPtaoPRFz7/hVnrBCN6wjIKS/m6FQ3LYuE0OLa
# V5i0CIgWmaN82TgaeAu8LZOP0is4y/bRKvKbkn8WHvJYCI94azfIDdBqmNlO1+vs
# 1/OkEglDjFP+JzhYZaqEaVGVUEjm7o6PDdnFJkIuDe9ELgpjKmSHwV0hagqKuOJ0
# QaVew06j5Q/9gbkqF5uK51MHEZ5x8kK65Sykh1GFK0cBCyO/90CpYEuWGiurY4Jo
# /7AWETdY+CefHml+W+W6Ohw+Cw3bj7510euXc7UUVptbybRSQMdIoKHxBPBORg7C
# 732ITEFVaVthlHPao4gGMv+jMSG0IHRq4qF9Mst640YFRoHP6hln5f1QAQKgyGQR
# ONvph81ojVPu9UBqK6EGhX8kI5BP5FhmuDKTI+nOmbAw0UEPW91b/b2r2eRNagSF
# wQ47Qv03MIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA1Aw
# ggI4AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046REMwMC0wNUUwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAM2v
# FFf+LPqyzWUEJcbw/UsXEPR7oIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDsM3gMMCIYDzIwMjUwNzI5MTY0MDQ0
# WhgPMjAyNTA3MzAxNjQwNDRaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOwzeAwC
# AQAwCgIBAAICA1QCAf8wBwIBAAICEhAwCgIFAOw0yYwCAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQsFAAOCAQEAdEUSktYG+UrzkgiCSvIAtnY3DD/iZ6ioUBuZ1VngDr02
# 8CwFRyw7OaeWsxdfQMlKYx4sco5eaxgP8vB2UgvKn/4lzC7gsFg/iexGvMQ280k6
# aACh/gvYRBPRGli+67JTxYBeKRbYCAOo3MjgmgwdJcvlUvJZ7DCnnsh8lp4SFhgq
# 2xqyKsishfKxD8Mlzh03+X0nsvrLej7X58ep3JzRRB5Z66Sxwn/Z0R9GZzn9JIu7
# +SIqeGjpvnjA3dOo8RXbCqxrhQOi2GRPhDjXNeDRWEzxKw+jx37U86OWz90KV7ho
# dUyEOI0t2LJERVLyKrEpJsSpaC5dRwjP5HtI1f96RzGCBA0wggQJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAACA7seXAA4bHTKAAEAAAID
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEIAWO+bNK+4ggJTFQWSGA4Zlv4bgr/R07Bx5RdYI206r7
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgSwPdG3GW9pPEU5lmelDDQOSw
# +ZV26jlLIr2H3D76Ey0wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAgO7HlwAOGx0ygABAAACAzAiBCAWViROTwTQ82vmEYT09Vg0dR8J
# Js4bbxOXiApagNv4OTANBgkqhkiG9w0BAQsFAASCAgB/OBV+iNFZ+DX1fop0Wer6
# G4TtJLwRVinFwYTAY2rL9zXd1AWV9LX7fsSDjZyUxa6RRJTPFfSngvz7Z8LZokYk
# U8ZlLhJwCfbPbx42buXsEcCvMzNBev4x1/XSp8lHcNEqoR3OKYLms1fEx42XN5TN
# +vVVtpRMVeYlIimI4srPCb+avZZR3L0hXvgipT5VSXn7h8lnt8xSlXqaVIfb9I1I
# btAftt2oD9NMhC1hugq+NwQpxMe+O5Ri/qVuKb/H2LMsoOzuveSzN6+YyJZznf+7
# tbU/zxho8/GTm3+2LZiNhhLnY1DLULGTj6gDkjQZ9YDrpPqNezlemPTBClqmhGyu
# OgGPxPA0yF7vJEjrtkEOt/JUSLqx9K3NYorgZiL+kMzvuHDjZu48IS7NUZ+B94ts
# /tCBKH/UBv4LtlbX86mKwY6H4qq9S2K4UF2Mbk0GnkIQSw5rZoQl60ZB1f8l8MI2
# BNDw37XNtaLLY3zQcxrIbwn60M4TsHQZ32RST3ch4aHfx3lFJwHmHpyhhCNVQn/Z
# tmxPrLNtLzs76yugnRrO0RWKl5rHz1X+iWclivxekf0T9dvfjfF07tYZy9JaXZrL
# 8x9NPI54dB4wVtHZyy27ikdmcKkjn2GtCgKw5xBgmBZkccUOOyIYuYX/W4W07N+e
# XAoVaCA4dhyeKtYwm6t9SQ==
# SIG # End signature block
